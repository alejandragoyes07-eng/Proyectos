FMK Grados - version lista para Netlify

Subida recomendada:
1. Entra a Netlify.
2. Arrastra esta carpeta completa al area de despliegue manual.
3. La pagina principal es index.html y no requiere instalacion.

Notas importantes:
- Los datos se guardan en el navegador mediante localStorage.
- Para una demo, crea primero una cuenta de administrador, luego una cuenta de aspirante.
- Desde Administrador > Convocatorias puedes crear una convocatoria, asignar aspirantes y enviarles la notificacion interna.
- Si el aspirante aun no esta admitido o tiene documentos/cuota pendientes, el sistema lo muestra como alerta sin bloquear la convocatoria.

Cuentas demo rapidas:
- En la pantalla de inicio puedes usar los botones Admin demo, Aspirante demo y Juez demo.
- Tambien puedes entrar manualmente con:
  admin@demo.fmk / demo123
  aspirante@demo.fmk / demo123
  juez@demo.fmk / demo123
- Las cuentas demo crean un aspirante admitido, una convocatoria asignada, un tribunal y notificaciones internas.
- Para ensenar la creacion de convocatoria, entra como Admin demo y usa el aspirante "Aspirante Listo": ya esta admitido, con documentos completos y cuota pagada, pero no tiene convocatoria asignada.
