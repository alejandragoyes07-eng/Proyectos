const STORE_KEY = 'fmk_grados_state_v8_roles';
const SESSION_KEY = 'fmk_grados_session_v8_roles';

const gradeRules = [
  { grade: 'Cinto Negro', minAge: 12, minYears: 1, from: 'cinto marrón', cons: 4, alt: 5, practice: 0 },
  { grade: '1º DAN', minAge: 16, minYears: 1, from: 'cinto marrón', cons: 3, alt: 4, practice: 0 },
  { grade: '2º DAN', minAge: 18, minYears: 2, from: '1º DAN', cons: 2, alt: 3, practice: 0 },
  { grade: '3º DAN', minAge: 21, minYears: 3, from: '2º DAN', cons: 3, alt: 4, practice: 0 },
  { grade: '4º DAN', minAge: 25, minYears: 4, from: '3º DAN', cons: 4, alt: 5, practice: 0 },
  { grade: '5º DAN', minAge: 30, minYears: 5, from: '4º DAN', cons: 5, alt: 6, practice: 14 },
  { grade: '6º DAN', minAge: 36, minYears: 6, from: '5º DAN', cons: 6, alt: 7, practice: 20 },
  { grade: '7º DAN', minAge: 43, minYears: 7, from: '6º DAN', cons: 7, alt: 8, practice: 27 },
  { grade: '8º DAN', minAge: 51, minYears: 8, from: '7º DAN', cons: 8, alt: 9, practice: 35 },
  { grade: '9º DAN', minAge: 60, minYears: 9, from: '8º DAN', cons: 9, alt: 10, practice: 44 },
  { grade: '10º DAN', minAge: 70, minYears: 10, from: '9º DAN', cons: 10, alt: 11, practice: 54 }
];

const stylesCatalog = [
  ['Gensei Ryu', 'Variación, giros y trabajo dinámico.', 'Taikyoku · Ten-I · Sansai'],
  ['Goju Ryu', 'Dureza y suavidad con énfasis respiratorio.', 'Sanchin · Tensho · Saifa'],
  ['Kyokushin Kai', 'Fortaleza física y espíritu de combate.', 'Taikyoku · Pinan · Yantsu'],
  ['Renbu Kai', 'Enfoque técnico, control y disciplina.', 'Heian · Tekki · Jion'],
  ['Shito Ryu', 'Gran riqueza técnica y amplia variedad de katas.', 'Pinan · Bassai Dai · Seienchin'],
  ['Shoto Kai', 'Fluidez, relajación y continuidad.', 'Heian · Tekki · Kanku Dai'],
  ['Shotokan', 'Posiciones sólidas y líneas largas.', 'Heian · Tekki · Bassai Dai'],
  ['Uechi Ryu', 'Corta distancia, manos abiertas y cuerpo fuerte.', 'Sanchin · Seisan · Sanseiryu'],
  ['Wado Ryu', 'Esquiva, economía de movimiento y jujutsu.', 'Pinan · Kushanku · Chinto']
];

const glossaryCatalog = [
  ['Karate', 'Camino de la mano vacía.'],
  ['Kata', 'Secuencia técnica preestablecida contra adversarios imaginarios.'],
  ['Kumite', 'Combate o enfrentamiento técnico.'],
  ['Kihon', 'Fundamentos o técnica base.'],
  ['Dan', 'Grado avanzado de progresión técnica.'],
  ['Dojo', 'Lugar de práctica.'],
  ['Sensei', 'Instructor o maestro.'],
  ['Obi', 'Cinturón.'],
  ['Zanshin', 'Alerta continua.'],
  ['Chakugan', 'Mirada o foco visual.'],
  ['Kime', 'Concentración de energía en el impacto.'],
  ['Kiai', 'Grito que expresa energía interna.'],
  ['Rei', 'Saludo marcial.'],
  ['Budo', 'Camino marcial.'],
  ['Jodan', 'Nivel alto.'],
  ['Chudan', 'Nivel medio.'],
  ['Gedan', 'Nivel bajo.'],
  ['Bunkai', 'Aplicación práctica del kata.'],
  ['Oyo Waza', 'Aplicación técnica.'],
  ['Shiai Kumite', 'Combate deportivo reglamentado.'],
  ['Jyu Kumite', 'Combate libre controlado.'],
  ['Enbusen', 'Línea de realización del kata.']
];

const documentChecklist = [
  'Edad reglamentaria',
  'Tiempo desde el grado anterior',
  'Fotocopia del carnet de grados',
  'Licencia del año en curso',
  'Fotocopia de cédula o DNI',
  'Tres fotografías tamaño carnet',
  'Solicitud oficial de examen',
  'Aval de entrenador hasta 3º DAN',
  'Curriculum deportivo desde 4º DAN',
  'Trabajo escrito desde 5º DAN',
  'Cuota de examen',
  'Documentación con 35 días de antelación'
];

const appSections = [
  { id: 'dashboard', label: 'Inicio', icon: '🏠', roles: ['admin', 'aspirante', 'juez'] },
  { id: 'notificaciones', label: 'Notificaciones', icon: '🔔', roles: ['admin', 'aspirante', 'juez'] },
  { id: 'normativa', label: 'Normativa', icon: '📘', roles: ['admin', 'aspirante', 'juez'] },
  { id: 'reglas', label: 'Reglas por grado', icon: '📋', roles: ['admin', 'aspirante', 'juez'] },
  { id: 'usuarios', label: 'Usuarios', icon: '🧑‍💼', roles: ['admin'] },
  { id: 'aspirantes', label: 'Aspirantes', icon: '👤', roles: ['admin', 'aspirante', 'juez'] },
  { id: 'documentacion', label: 'Documentos', icon: '🗂️', roles: ['admin', 'aspirante'] },
  { id: 'cuotas', label: 'Cuota de examen', icon: '💳', roles: ['admin', 'aspirante'] },
  { id: 'convocatorias', label: 'Convocatorias', icon: '🗓️', roles: ['admin', 'aspirante', 'juez'] },
  { id: 'tribunales', label: 'Tribunales', icon: '⚖️', roles: ['admin', 'juez'] },
  { id: 'evaluacion', label: 'Evaluación', icon: '✅', roles: ['admin', 'juez'] },
  { id: 'actas', label: 'Resultados y actas', icon: '🧾', roles: ['admin', 'juez', 'aspirante'] },
  { id: 'especiales', label: 'Situaciones especiales', icon: '🛡️', roles: ['admin', 'aspirante'] },
  { id: 'estilos', label: 'Estilos', icon: '🥋', roles: ['admin', 'aspirante'] },
  { id: 'glosario', label: 'Glosario', icon: '🔎', roles: ['admin', 'aspirante'] },
  { id: 'perfil', label: 'Mi perfil', icon: '⚙️', roles: ['admin', 'aspirante', 'juez'] }
];

let activeSection = 'dashboard';
const DEMO_PASSWORD = 'demo123';
const DEMO_IDS = {
  admin: 'demo-admin',
  juez: 'demo-juez',
  aspiranteUser: 'demo-aspirante-user',
  aspirante: 'demo-aspirante',
  aspiranteListoUser: 'demo-aspirante-listo-user',
  aspiranteListo: 'demo-aspirante-listo',
  call: 'demo-call',
  tribunal: 'demo-tribunal'
};

const $ = (selector, scope = document) => scope.querySelector(selector);
const $$ = (selector, scope = document) => [...scope.querySelectorAll(selector)];

function uid() {
  return Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
}

function today() {
  return new Date().toISOString().slice(0, 10);
}

function normalize(value) {
  return String(value || '').trim();
}

function escapeHtml(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

function hashPassword(raw) {
  return btoa(unescape(encodeURIComponent(raw))).split('').reverse().join('');
}

function defaultState() {
  return {
    users: [],
    aspirants: [],
    calls: [],
    tribunals: [],
    evaluations: [],
    notifications: [],
    settings: { lastUpdated: today() }
  };
}

function loadState() {
  let state = defaultState();
  try {
    const raw = localStorage.getItem(STORE_KEY);
    if (raw) state = { ...state, ...JSON.parse(raw) };
  } catch (_) {}
  state.users ||= [];
  state.aspirants ||= [];
  state.calls ||= [];
  state.tribunals ||= [];
  state.evaluations ||= [];
  state.notifications ||= [];
  state.settings ||= { lastUpdated: today() };
  return state;
}

function saveState(state) {
  state.settings.lastUpdated = today();
  localStorage.setItem(STORE_KEY, JSON.stringify(state));
}

function getSessionUserId() {
  return sessionStorage.getItem(SESSION_KEY) || localStorage.getItem(SESSION_KEY);
}

function setSession(userId) {
  sessionStorage.setItem(SESSION_KEY, userId);
  localStorage.setItem(SESSION_KEY, userId);
}

function clearSession() {
  sessionStorage.removeItem(SESSION_KEY);
  localStorage.removeItem(SESSION_KEY);
}

function currentUser() {
  const state = loadState();
  const userId = getSessionUserId();
  return state.users.find(user => user.id === userId) || null;
}


function addNotification(state, notification) {
  state.notifications ||= [];
  state.notifications.unshift({
    id: uid(),
    createdAt: new Date().toLocaleString('es-ES'),
    read: false,
    role: notification.role || '',
    userId: notification.userId || '',
    title: notification.title || 'Notificación',
    message: notification.message || '',
    type: notification.type || 'general'
  });
}

function notificationsFor(user) {
  const state = loadState();
  return (state.notifications || []).filter(item => item.userId === user.id || item.role === user.role || item.role === 'all');
}

function unreadNotifications(user) {
  return notificationsFor(user).filter(item => !item.read).length;
}

function unreadNotificationsCount(user) {
  return unreadNotifications(user);
}

function markNotificationsReadFor(user) {
  if (!user) return false;
  const state = loadState();
  let changed = false;
  state.notifications.forEach(item => {
    if (!item.read && (item.userId === user.id || item.role === user.role || item.role === 'all')) {
      item.read = true;
      changed = true;
    }
  });
  if (changed) saveState(state);
  return changed;
}

function roleLabel(role) {
  return ({ admin: 'Administrador', aspirante: 'Aspirante', juez: 'Juez' }[role] || role);
}

function fullName(user) {
  return `${user.names || ''} ${user.lastnames || ''}`.trim();
}

function feeIsCleared(aspirant) {
  return ['Pagada', 'Exenta', 'Reducción 50%'].includes(aspirant?.feeStatus);
}

function aspirantReadiness(aspirant) {
  const missing = [];
  if (aspirant.status !== 'Admitido') missing.push('Admisión pendiente');
  if (aspirant.docStatus !== 'Completa') missing.push('Documentación pendiente');
  if (!feeIsCleared(aspirant)) missing.push('Cuota pendiente');
  return {
    ready: missing.length === 0,
    missing,
    label: missing.length ? missing.join(' · ') : 'Listo para examen'
  };
}

function callForAspirant(state, aspirantId) {
  return state.calls.find(call => (call.aspirantIds || []).includes(aspirantId));
}

function hasAdmin() {
  return loadState().users.some(user => user.role === 'admin');
}

function validateEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function validateIdentifier(identifier) {
  if (!identifier) return { ok: false, msg: 'Ingresa correo o cédula.' };
  if (/^\d+$/.test(identifier) && identifier.length > 10) return { ok: false, msg: 'La cédula no debe pasar de 10 números.' };
  if (!/^\d+$/.test(identifier) && !validateEmail(identifier)) return { ok: false, msg: 'Ingresa un correo válido o una cédula numérica.' };
  return { ok: true };
}

function gradeOptions(selected = '') {
  return gradeRules.map(rule => `<option value="${rule.grade}" ${rule.grade === selected ? 'selected' : ''}>${rule.grade}</option>`).join('');
}

function styleOptions(selected = '') {
  return stylesCatalog.map(([name]) => `<option value="${name}" ${name === selected ? 'selected' : ''}>${name}</option>`).join('');
}

function toast(message) {
  const box = $('#toast');
  box.textContent = message;
  box.classList.remove('hidden');
  clearTimeout(box._timer);
  box._timer = setTimeout(() => box.classList.add('hidden'), 2600);
}

function openModal(title, content) {
  $('#modalRoot').innerHTML = `
    <div class="modal-backdrop">
      <div class="modal">
        <div class="modal-head">
          <h3>${title}</h3>
          <button class="btn btn-secondary" type="button" data-close-modal>Cerrar</button>
        </div>
        ${content}
      </div>
    </div>`;
  $('[data-close-modal]')?.addEventListener('click', closeModal);
  $$('.eye-btn', $('#modalRoot')).forEach(btn => btn.addEventListener('click', () => togglePassword(btn)));
}

function closeModal() {
  $('#modalRoot').innerHTML = '';
}

function togglePassword(btn) {
  const input = btn.parentElement.querySelector('input');
  if (!input) return;
  input.type = input.type === 'password' ? 'text' : 'password';
}

function userCan(sectionId) {
  const user = currentUser();
  const section = appSections.find(item => item.id === sectionId);
  return user && section && section.roles.includes(user.role);
}

function renderAuth(mode = 'login') {
  $('#appView').classList.add('hidden');
  const authView = $('#authView');
  authView.classList.remove('hidden');

  authView.innerHTML = `
    <section class="auth-shell">
      <div class="auth-brand compact-brand">
        <div>
          <div class="hero-mark">空</div>
          <h1>FMK<br/>Grados</h1>
          <p>Sistema para la gestión de exámenes de grado, expedientes y resultados.</p>
        </div>
        <div class="auth-summary">
          <h3>Seleccione su tipo de cuenta</h3>
          <p>Puede registrarse como administrador, juez o aspirante. Al iniciar sesión, el sistema mostrará únicamente el panel correspondiente a su rol.</p>
        </div>
      </div>

      <div class="auth-card">
        <div class="auth-tabs">
          ${authTab('login', 'Iniciar sesión', mode)}
          ${authTab('register', 'Crear cuenta', mode)}
          ${authTab('forgot', 'Recuperar contraseña', mode)}
        </div>
        <div id="authPanel"></div>
      </div>
    </section>`;

  $$('.tab-btn', authView).forEach(btn => btn.addEventListener('click', () => renderAuth(btn.dataset.tab)));
  renderAuthPanel(mode);
}

function authTab(id, label, current) {
  return `<button type="button" class="tab-btn ${id === current ? 'active' : ''}" data-tab="${id}">${label}</button>`;
}

function renderAuthPanel(mode) {
  const panel = $('#authPanel');
  const templates = {
    login: `
      <span class="eyebrow">Acceso</span>
      <h2>Iniciar sesión</h2>
      <p class="helper">Ingrese con el correo o la cédula de su cuenta registrada.</p>
      <form id="authForm" class="form-grid one">
        <div class="field"><label>Correo o cédula</label><input id="identifier" autocomplete="username" /></div>
        <div class="field"><label>Contraseña</label><div class="password-wrap"><input id="password" type="password" autocomplete="current-password" /><button type="button" class="eye-btn">👁</button></div></div>
        <div class="field full"><button class="btn btn-primary btn-block" type="submit">Entrar</button></div>
        <p id="authError" class="form-error"></p>
      </form>
      <section class="demo-panel">
        <div>
          <strong>Entrar con cuentas demo</strong>
          <span>Datos precargados para probar convocatorias, notificaciones y evaluación.</span>
        </div>
        <div class="demo-buttons">
          <button class="btn btn-secondary" type="button" data-demo-role="admin">Admin demo</button>
          <button class="btn btn-secondary" type="button" data-demo-role="aspirante">Aspirante demo</button>
          <button class="btn btn-secondary" type="button" data-demo-role="juez">Juez demo</button>
        </div>
        <small>Contraseña de referencia: demo123</small>
      </section>
      <p class="form-note">¿Olvidaste tu contraseña? <button type="button" class="link-btn" id="goForgot">Recupérala aquí</button></p>`,
    register: `
      <span class="eyebrow">Registro</span>
      <h2>Crear cuenta</h2>
      <p class="helper">Elija el tipo de cuenta. Cada rol tendrá un panel distinto después de iniciar sesión.</p>
      <form id="authForm" class="form-grid">
        <div class="field full"><label>Tipo de cuenta</label><select id="roleSelect"><option value="aspirante">Aspirante</option><option value="juez">Juez</option><option value="admin">Administrador</option></select></div>
        ${basicUserFields()}
        <div id="aspirantFields" class="field full">
          <div class="form-grid">
            <div class="field"><label>Teléfono</label><input id="phone" /></div>
            <div class="field"><label>Fecha de nacimiento</label><input id="birthDate" type="date" /></div>
            <div class="field"><label>Club o dojo</label><input id="club" /></div>
            <div class="field"><label>Estilo</label><select id="style">${styleOptions()}</select></div>
            <div class="field"><label>Grado actual</label><select id="currentGrade">${gradeOptions('Cinto Negro')}</select></div>
            <div class="field"><label>Grado solicitado</label><select id="requestedGrade">${gradeOptions('1º DAN')}</select></div>
          </div>
        </div>
        ${passwordFields()}
        <div class="field full"><button class="btn btn-primary btn-block" type="submit">Crear cuenta</button></div>
        <p id="authError" class="form-error field full"></p>
      </form>`,
    forgot: `
      <span class="eyebrow">Recuperación</span>
      <h2>Actualizar contraseña</h2>
      <p class="helper">Busque su cuenta con correo o cédula y defina una nueva contraseña.</p>
      <form id="authForm" class="form-grid one">
        <div class="field"><label>Correo o cédula</label><input id="identifier" /></div>
        <div class="field"><label>Nueva contraseña</label><div class="password-wrap"><input id="password" type="password" /><button type="button" class="eye-btn">👁</button></div></div>
        <div class="field"><label>Confirmar nueva contraseña</label><div class="password-wrap"><input id="confirmPassword" type="password" /><button type="button" class="eye-btn">👁</button></div></div>
        <div class="field full"><button class="btn btn-primary btn-block" type="submit">Actualizar contraseña</button></div>
        <p id="authError" class="form-error"></p>
      </form>`
  };

  panel.innerHTML = templates[mode] || templates.login;
  $('#goForgot')?.addEventListener('click', () => renderAuth('forgot'));
  $$('.eye-btn', panel).forEach(btn => btn.addEventListener('click', () => togglePassword(btn)));
  $$('[data-demo-role]', panel).forEach(btn => btn.addEventListener('click', () => loginAsDemo(btn.dataset.demoRole)));
  $('#cedula')?.addEventListener('input', event => event.target.value = event.target.value.replace(/\D/g, '').slice(0, 10));
  $('#identifier')?.addEventListener('input', event => {
    if (/^\d/.test(event.target.value)) event.target.value = event.target.value.replace(/\D/g, '').slice(0, 10);
  });
  $('#roleSelect')?.addEventListener('change', updateRegisterRoleFields);
  updateRegisterRoleFields();
  $('#authForm')?.addEventListener('submit', event => handleAuthSubmit(event, mode));
}

function updateRegisterRoleFields() {
  const role = $('#roleSelect')?.value;
  const aspirantFields = $('#aspirantFields');
  if (!aspirantFields) return;
  aspirantFields.classList.toggle('hidden', role !== 'aspirante');
}

function basicUserFields() {
  return `
    <div class="field"><label>Nombres</label><input id="names" /></div>
    <div class="field"><label>Apellidos</label><input id="lastnames" /></div>
    <div class="field"><label>Cédula</label><input id="cedula" inputmode="numeric" maxlength="10" /></div>
    <div class="field"><label>Correo</label><input id="email" type="email" /></div>`;
}

function passwordFields() {
  return `
    <div class="field"><label>Contraseña</label><div class="password-wrap"><input id="password" type="password" /><button type="button" class="eye-btn">👁</button></div></div>
    <div class="field"><label>Confirmar contraseña</label><div class="password-wrap"><input id="confirmPassword" type="password" /><button type="button" class="eye-btn">👁</button></div></div>`;
}

function handleAuthSubmit(event, mode) {
  event.preventDefault();
  const state = loadState();
  const error = $('#authError');
  if (error) error.textContent = '';

  if (mode === 'login') {
    const identifier = normalize($('#identifier').value);
    const validation = validateIdentifier(identifier);
    if (!validation.ok) return error.textContent = validation.msg;
    const password = normalize($('#password').value);
    if (!password) return error.textContent = 'La contraseña es obligatoria.';
    const user = state.users.find(item => item.cedula === identifier || item.email.toLowerCase() === identifier.toLowerCase());
    if (!user) return error.textContent = 'No existe una cuenta con esos datos.';
    if (user.password !== hashPassword(password)) return error.textContent = 'Contraseña incorrecta.';
    setSession(user.id);
    toast('Sesión iniciada correctamente.');
    return renderApp();
  }

  if (mode === 'forgot') {
    const identifier = normalize($('#identifier').value);
    const validation = validateIdentifier(identifier);
    if (!validation.ok) return error.textContent = validation.msg;
    const password = normalize($('#password').value);
    const confirm = normalize($('#confirmPassword').value);
    if (password.length < 6) return error.textContent = 'La contraseña debe tener mínimo 6 caracteres.';
    if (password !== confirm) return error.textContent = 'Las contraseñas no coinciden.';
    const user = state.users.find(item => item.cedula === identifier || item.email.toLowerCase() === identifier.toLowerCase());
    if (!user) return error.textContent = 'No existe una cuenta con esos datos.';
    user.password = hashPassword(password);
    saveState(state);
    toast('Contraseña actualizada correctamente.');
    return renderAuth('login');
  }

  const names = normalize($('#names').value);
  const lastnames = normalize($('#lastnames').value);
  const cedula = normalize($('#cedula').value).replace(/\D/g, '').slice(0, 10);
  const email = normalize($('#email').value).toLowerCase();
  const password = normalize($('#password').value);
  const confirm = normalize($('#confirmPassword').value);

  if (!names || !lastnames || !cedula || !email) return error.textContent = 'Completa todos los campos obligatorios.';
  if (cedula.length < 5 || cedula.length > 10) return error.textContent = 'La cédula debe tener hasta 10 números.';
  if (!validateEmail(email)) return error.textContent = 'Correo inválido.';
  if (state.users.some(item => item.cedula === cedula)) return error.textContent = 'Ya existe una cuenta con esa cédula.';
  if (state.users.some(item => item.email.toLowerCase() === email)) return error.textContent = 'Ya existe una cuenta con ese correo.';
  if (password.length < 6) return error.textContent = 'La contraseña debe tener mínimo 6 caracteres.';
  if (password !== confirm) return error.textContent = 'Las contraseñas no coinciden.';

  const role = normalize($('#roleSelect')?.value || 'aspirante');
  if (!['admin', 'juez', 'aspirante'].includes(role)) return error.textContent = 'Selecciona un tipo de cuenta válido.';
  const user = {
    id: uid(), role, names, lastnames, cedula, email, password: hashPassword(password),
    phone: role === 'aspirante' ? normalize($('#phone')?.value || '') : '',
    birthDate: role === 'aspirante' ? normalize($('#birthDate')?.value || '') : '',
    club: role === 'aspirante' ? normalize($('#club')?.value || '') : '',
    style: role === 'aspirante' ? normalize($('#style')?.value || '') : '',
    currentGrade: role === 'aspirante' ? normalize($('#currentGrade')?.value || '') : '',
    requestedGrade: role === 'aspirante' ? normalize($('#requestedGrade')?.value || '') : '',
    createdAt: today()
  };
  state.users.push(user);
  if (role === 'aspirante') {
    state.aspirants.push(buildAspirantFromUser(user));
    addNotification(state, {
      userId: user.id,
      title: 'Inscripción registrada',
      message: 'Tu cuenta de aspirante fue creada. Completa y revisa tu ficha, documentación y cuota de examen.',
      type: 'registro'
    });
    addNotification(state, {
      role: 'admin',
      title: 'Nuevo aspirante inscrito',
      message: `${fullName(user)} se registró como aspirante y tiene documentación pendiente de revisión.`,
      type: 'registro'
    });
  } else {
    addNotification(state, {
      userId: user.id,
      title: 'Cuenta creada',
      message: `Tu cuenta de ${roleLabel(role).toLowerCase()} fue creada correctamente.`,
      type: 'registro'
    });
    if (role === 'juez') {
      addNotification(state, {
        role: 'admin',
        title: 'Nuevo juez registrado',
        message: `${fullName(user)} se registró como juez.`,
        type: 'usuario'
      });
    }
  }
  saveState(state);

  toast(`Cuenta de ${roleLabel(role).toLowerCase()} creada correctamente. Ahora puedes iniciar sesión.`);
  renderAuth('login');
}

function buildAspirantFromUser(user) {
  return {
    id: uid(),
    userId: user.id,
    names: user.names,
    lastnames: user.lastnames,
    cedula: user.cedula,
    email: user.email,
    phone: user.phone || '',
    birthDate: user.birthDate || '',
    club: user.club || '',
    style: user.style || '',
    currentGrade: user.currentGrade || 'Cinto Negro',
    requestedGrade: user.requestedGrade || '1º DAN',
    prevGradeDate: '',
    consecutiveLicenses: 0,
    alternateLicenses: 0,
    practiceYearsSinceFirstDan: 0,
    coachEndorsement: '',
    status: 'Pendiente',
    docStatus: 'Pendiente',
    feeStatus: 'Pendiente',
    feeReason: '',
    specialSituation: '',
    observations: '',
    documents: documentChecklist.reduce((acc, label) => ({ ...acc, [label]: { status: 'Pendiente', note: '' } }), {}),
    uploads: {},
    examSubmission: null,
    createdAt: today()
  };
}

function ensureDemoData() {
  const state = loadState();
  const usersById = new Map(state.users.map(user => [user.id, user]));
  const demoUsers = [
    {
      id: DEMO_IDS.admin,
      role: 'admin',
      names: 'Admin',
      lastnames: 'Demo',
      cedula: '0100000001',
      email: 'admin@demo.fmk',
      password: hashPassword(DEMO_PASSWORD),
      createdAt: today()
    },
    {
      id: DEMO_IDS.juez,
      role: 'juez',
      names: 'Juez',
      lastnames: 'Demo',
      cedula: '0100000002',
      email: 'juez@demo.fmk',
      password: hashPassword(DEMO_PASSWORD),
      createdAt: today()
    },
    {
      id: DEMO_IDS.aspiranteUser,
      role: 'aspirante',
      names: 'Estudiante',
      lastnames: 'Demo',
      cedula: '0100000003',
      email: 'aspirante@demo.fmk',
      password: hashPassword(DEMO_PASSWORD),
      phone: '0999999999',
      birthDate: '2002-05-18',
      club: 'Dojo Central',
      style: 'Shotokan',
      currentGrade: 'Cinto Negro',
      requestedGrade: '1º DAN',
      createdAt: today()
    },
    {
      id: DEMO_IDS.aspiranteListoUser,
      role: 'aspirante',
      names: 'Aspirante',
      lastnames: 'Listo',
      cedula: '0100000004',
      email: 'listo@demo.fmk',
      password: hashPassword(DEMO_PASSWORD),
      phone: '0988888888',
      birthDate: '2001-09-12',
      club: 'Dojo Central',
      style: 'Shotokan',
      currentGrade: 'Cinto Negro',
      requestedGrade: '1º DAN',
      createdAt: today()
    }
  ];

  demoUsers.forEach(demo => {
    const existing = usersById.get(demo.id) || state.users.find(user => user.email === demo.email || user.cedula === demo.cedula);
    if (existing) {
      Object.assign(existing, demo);
      usersById.set(existing.id, existing);
    } else {
      state.users.push(demo);
      usersById.set(demo.id, demo);
    }
  });

  let aspirant = state.aspirants.find(item => item.id === DEMO_IDS.aspirante || item.userId === DEMO_IDS.aspiranteUser);
  if (!aspirant) {
    aspirant = buildAspirantFromUser(usersById.get(DEMO_IDS.aspiranteUser));
    aspirant.id = DEMO_IDS.aspirante;
    state.aspirants.push(aspirant);
  }
  Object.assign(aspirant, {
    id: DEMO_IDS.aspirante,
    userId: DEMO_IDS.aspiranteUser,
    names: 'Estudiante',
    lastnames: 'Demo',
    cedula: '0100000003',
    email: 'aspirante@demo.fmk',
    phone: '0999999999',
    birthDate: '2002-05-18',
    club: 'Dojo Central',
    style: 'Shotokan',
    currentGrade: 'Cinto Negro',
    requestedGrade: '1º DAN',
    prevGradeDate: '2025-06-15',
    consecutiveLicenses: 4,
    alternateLicenses: 4,
    practiceYearsSinceFirstDan: 0,
    coachEndorsement: 'Sensei Demo',
    status: 'Admitido',
    docStatus: 'Completa',
    feeStatus: 'Pagada',
    feeReason: 'Pago demo registrado',
    specialSituation: 'Ninguna',
    observations: 'Expediente demo listo para examen.',
    documents: documentChecklist.reduce((acc, label) => ({ ...acc, [label]: { status: 'Completa', note: 'Aprobado para demo.' } }), {}),
    uploads: documentChecklist.reduce((acc, label) => ({ ...acc, [label]: { fileName: `${label}.pdf`, uploadedAt: new Date().toLocaleString('es-ES') } }), {}),
    examSubmission: {
      callId: DEMO_IDS.call,
      sentAt: new Date().toLocaleString('es-ES'),
      answers: {
        q1: 'Camino de la mano vacía.',
        q2: 'Saludo y respeto.',
        q3: 'Secuencia técnica preestablecida.',
        q4: 'Combate o enfrentamiento técnico.',
        q5: 'Examen enviado desde la cuenta demo.'
      }
    },
    createdAt: today()
  });

  let readyAspirant = state.aspirants.find(item => item.id === DEMO_IDS.aspiranteListo || item.userId === DEMO_IDS.aspiranteListoUser);
  if (!readyAspirant) {
    readyAspirant = buildAspirantFromUser(usersById.get(DEMO_IDS.aspiranteListoUser));
    readyAspirant.id = DEMO_IDS.aspiranteListo;
    state.aspirants.push(readyAspirant);
  }
  Object.assign(readyAspirant, {
    id: DEMO_IDS.aspiranteListo,
    userId: DEMO_IDS.aspiranteListoUser,
    names: 'Aspirante',
    lastnames: 'Listo',
    cedula: '0100000004',
    email: 'listo@demo.fmk',
    phone: '0988888888',
    birthDate: '2001-09-12',
    club: 'Dojo Central',
    style: 'Shotokan',
    currentGrade: 'Cinto Negro',
    requestedGrade: '1º DAN',
    prevGradeDate: '2025-05-01',
    consecutiveLicenses: 4,
    alternateLicenses: 4,
    practiceYearsSinceFirstDan: 0,
    coachEndorsement: 'Sensei Demo',
    status: 'Admitido',
    docStatus: 'Completa',
    feeStatus: 'Pagada',
    feeReason: 'Pago demo registrado',
    specialSituation: 'Ninguna',
    observations: 'Aspirante listo para que el administrador lo convoque en vivo.',
    documents: documentChecklist.reduce((acc, label) => ({ ...acc, [label]: { status: 'Completa', note: 'Aprobado para demo.' } }), {}),
    uploads: documentChecklist.reduce((acc, label) => ({ ...acc, [label]: { fileName: `${label}.pdf`, uploadedAt: new Date().toLocaleString('es-ES') } }), {}),
    examSubmission: null,
    createdAt: today()
  });

  let call = state.calls.find(item => item.id === DEMO_IDS.call);
  if (!call) {
    call = { id: DEMO_IDS.call, aspirantIds: [] };
    state.calls.push(call);
  }
  Object.assign(call, {
    id: DEMO_IDS.call,
    name: 'Convocatoria Demo FMK',
    date: '2026-07-20',
    place: 'Dojo Central',
    type: 'Examen ordinario',
    status: 'Abierta',
    note: 'Convocatoria de ejemplo lista para presentación.',
    aspirantIds: [DEMO_IDS.aspirante]
  });

  let tribunal = state.tribunals.find(item => item.id === DEMO_IDS.tribunal);
  if (!tribunal) {
    tribunal = { id: DEMO_IDS.tribunal };
    state.tribunals.push(tribunal);
  }
  Object.assign(tribunal, {
    id: DEMO_IDS.tribunal,
    name: 'Tribunal Demo',
    date: '2026-07-20',
    judges: '3 jueces',
    director: 'Director Demo',
    aux: 'Mesa técnica',
    note: 'Tribunal de ejemplo.'
  });

  upsertDemoNotification(state, {
    id: 'demo-notice-aspirante-call',
    userId: DEMO_IDS.aspiranteUser,
    title: 'Examen asignado',
    message: 'Tu examen fue asignado para el 2026-07-20 en Dojo Central.',
    type: 'convocatoria'
  });
  upsertDemoNotification(state, {
    id: 'demo-notice-admin-ready',
    role: 'admin',
    title: 'Aspirante listo para convocar',
    message: 'Aspirante Listo está admitido, con documentos completos y cuota pagada. Aún no tiene convocatoria para que puedas asignarla en vivo.',
    type: 'demo'
  });
  upsertDemoNotification(state, {
    id: 'demo-notice-juez-call',
    role: 'juez',
    title: 'Convocatoria asignada',
    message: 'Convocatoria Demo FMK tiene 1 aspirante asignado.',
    type: 'convocatoria'
  });

  saveState(state);
  return state;
}

function upsertDemoNotification(state, notification) {
  const existing = state.notifications.find(item => item.id === notification.id);
  const payload = {
    createdAt: new Date().toLocaleString('es-ES'),
    read: false,
    role: notification.role || '',
    userId: notification.userId || '',
    title: notification.title,
    message: notification.message,
    type: notification.type || 'demo'
  };
  if (existing) {
    Object.assign(existing, payload);
  } else {
    state.notifications.unshift({ id: notification.id, ...payload });
  }
}

function loginAsDemo(role) {
  const state = ensureDemoData();
  const idByRole = {
    admin: DEMO_IDS.admin,
    juez: DEMO_IDS.juez,
    aspirante: DEMO_IDS.aspiranteUser
  };
  const user = state.users.find(item => item.id === idByRole[role]);
  if (!user) return toast('No se pudo cargar la cuenta demo.');
  setSession(user.id);
  activeSection = 'dashboard';
  toast(`Entraste como ${roleLabel(user.role)} demo.`);
  renderApp();
}

function renderApp() {
  const user = currentUser();
  if (!user) return renderAuth('login');
  $('#authView').classList.add('hidden');
  $('#appView').classList.remove('hidden');
  if (!userCan(activeSection)) activeSection = 'dashboard';
  renderSidebar();
  renderTopUser(user);
  renderSection(activeSection);
}

function renderSidebar() {
  const user = currentUser();
  const nav = $('#sideNav');
  const unread = unreadNotificationsCount(user);
  nav.innerHTML = appSections
    .filter(section => section.roles.includes(user.role))
    .map(section => {
      const badge = section.id === 'notificaciones' && unread > 0 ? `<em class="nav-badge">${unread > 99 ? '99+' : unread}</em>` : '';
      return `<button type="button" data-section="${section.id}" class="${activeSection === section.id ? 'active' : ''}"><span>${section.icon}</span><strong>${section.label}</strong>${badge}</button>`;
    })
    .join('');

  $$('#sideNav button').forEach(button => button.addEventListener('click', () => {
    activeSection = button.dataset.section;
    renderSidebar();
    renderSection(activeSection);
    document.body.classList.remove('menu-open');
  }));
}

function renderTopUser(user) {
  const unread = unreadNotificationsCount(user);
  $('#topUser').innerHTML = `<div class="avatar">${escapeHtml((user.names || 'U')[0].toUpperCase())}</div><div>${escapeHtml(fullName(user))}<br><span class="muted">${escapeHtml(roleLabel(user.role))}</span></div>${unread > 0 ? `<span class="top-notice-badge">${unread > 99 ? '99+' : unread}</span>` : ''}`;
}

function setPageTitle(sectionId) {
  const section = appSections.find(item => item.id === sectionId);
  $('#pageTitle').textContent = section ? section.label : 'Inicio';
}

function sectionIntro(title, text) {
  return `<div class="section-intro"><h3>${title}</h3><p>${text}</p></div>`;
}

function renderSection(sectionId) {
  setPageTitle(sectionId);
  const content = $('#pageContent');
  const user = currentUser();
  if (!userCan(sectionId)) {
    content.innerHTML = sectionIntro('Sin permisos', 'No tienes permisos para esta sección.');
    return;
  }
  const notificationsWereRead = sectionId === 'notificaciones' ? markNotificationsReadFor(user) : false;
  const routes = {
    dashboard: renderDashboard,
    notificaciones: renderNotifications,
    normativa: renderNormativa,
    reglas: renderRules,
    usuarios: renderUsers,
    aspirantes: renderAspirants,
    documentacion: renderDocuments,
    cuotas: renderFees,
    convocatorias: renderCalls,
    tribunales: renderTribunals,
    evaluacion: renderEvaluation,
    actas: renderRecords,
    especiales: renderSpecialCases,
    estilos: renderStyles,
    glosario: renderGlossary,
    perfil: renderProfile
  };
  content.innerHTML = routes[sectionId] ? routes[sectionId]() : '';
  bindSectionActions(sectionId);
  if (notificationsWereRead) {
    renderSidebar();
    renderTopUser(user);
  }
}

function getOwnAspirant() {
  const user = currentUser();
  const state = loadState();
  return state.aspirants.find(item => item.userId === user.id) || null;
}

function renderDashboard() {
  const state = loadState();
  const user = currentUser();
  const ownAspirant = getOwnAspirant();
  const allAspirants = state.aspirants;
  const ownEvaluations = state.evaluations.filter(item => item.userId === user.id);
  const ownAssignedCalls = ownAspirant ? state.calls.filter(call => (call.aspirantIds || []).includes(ownAspirant.id)) : [];
  const latestRows = allAspirants.slice(-5).reverse().map(item => `
    <tr>
      <td>${escapeHtml(item.names)} ${escapeHtml(item.lastnames)}</td>
      <td>${escapeHtml(item.requestedGrade)}</td>
      <td>${badgeForStatus(item.docStatus)}</td>
      <td>${badgeForStatus(item.status)}</td>
    </tr>`).join('');

  if (user.role === 'admin') {
    const readyToCall = allAspirants.filter(item => aspirantReadiness(item).ready && !callForAspirant(state, item.id)).length;
    const assignedAspirants = new Set(state.calls.flatMap(call => call.aspirantIds || []));
    const actions = [
      { label: 'Notificaciones', section: 'notificaciones', text: 'Revisar avisos del sistema.' },
      { label: 'Usuarios', section: 'usuarios', text: 'Crear jueces y otros administradores.' },
      { label: 'Aspirantes', section: 'aspirantes', text: 'Revisar expedientes y solicitudes.' },
      { label: 'Documentos', section: 'documentacion', text: 'Controlar requisitos administrativos.' },
      { label: 'Convocatorias', section: 'convocatorias', text: 'Crear llamados y avisar a aspirantes.' },
      { label: 'Tribunales', section: 'tribunales', text: 'Organizar jueces y tribunal.' },
      { label: 'Actas', section: 'actas', text: 'Consultar e imprimir resultados.' }
    ];

    return `
      <div class="grid four">
        ${statCard('Aspirantes registrados', allAspirants.length)}
        ${statCard('Jueces registrados', state.users.filter(item => item.role === 'juez').length)}
        ${statCard('Listos para convocar', readyToCall)}
        ${statCard('Notificaciones', unreadNotifications(user))}
      </div>

      <section class="callout-card" style="margin-top:18px">
        <div>
          <span class="eyebrow">Flujo recomendado</span>
          <h3>Convoca desde administración sin perder control</h3>
          <p>Ahora puedes asignar una convocatoria aunque falte un requisito. El sistema avisa al aspirante y mantiene visible qué queda pendiente antes del examen.</p>
        </div>
        <button type="button" class="btn btn-primary" data-go-section="convocatorias">Ir a convocatorias</button>
      </section>

      <section class="table-card" style="margin-top:18px">
        <div class="table-head">
          <div>
            <span class="eyebrow">Panel del administrador</span>
            <h3>Operaciones principales</h3>
          </div>
          <span class="badge gold">Admin</span>
        </div>
        <div class="quick-action-grid">
          ${actions.map(item => `
            <button type="button" class="quick-action" data-go-section="${item.section}">
              <strong>${item.label}</strong>
              <span>${item.text}</span>
            </button>`).join('')}
        </div>
      </section>

      <div class="grid two" style="margin-top:18px">
        <section class="card">
          <span class="eyebrow">Estado general</span>
          <div class="kv"><strong>Convocatorias creadas</strong><span>${state.calls.length}</span></div>
          <div class="kv"><strong>Aspirantes convocados</strong><span>${assignedAspirants.size}</span></div>
          <div class="kv"><strong>Tribunales registrados</strong><span>${state.tribunals.length}</span></div>
          <div class="kv"><strong>Documentación incompleta</strong><span>${allAspirants.filter(item => item.docStatus !== 'Completa').length}</span></div>
          <div class="kv"><strong>Última actualización</strong><span>${escapeHtml(state.settings.lastUpdated || today())}</span></div>
        </section>
        <section class="card">
          <span class="eyebrow">Seguimiento de resultados</span>
          <div class="kv"><strong>Aptos</strong><span>${state.evaluations.filter(item => item.finalResult === 'Apto').length}</span></div>
          <div class="kv"><strong>No aptos</strong><span>${state.evaluations.filter(item => item.finalResult === 'No apto').length}</span></div>
          <div class="kv"><strong>Pendientes</strong><span>${state.evaluations.filter(item => item.finalResult === 'Pendiente').length}</span></div>
          <div class="kv"><strong>Usuarios internos</strong><span>${state.users.filter(item => item.role !== 'aspirante').length}</span></div>
        </section>
      </div>

      <section class="table-card" style="margin-top:18px">
        <div class="table-head">
          <h3>Solicitudes recientes</h3>
          <span class="badge gold">Seguimiento</span>
        </div>
        <div class="table-wrap">
          ${allAspirants.length ? `<table class="table"><thead><tr><th>Aspirante</th><th>Grado solicitado</th><th>Documentación</th><th>Estado</th></tr></thead><tbody>${latestRows}</tbody></table>` : `<div class="empty">Todavía no hay aspirantes registrados.</div>`}
        </div>
      </section>`;
  }

  if (user.role === 'juez') {
    const judgeActions = [
      { label: 'Notificaciones', section: 'notificaciones', text: 'Ver asignaciones y avisos.' },
      { label: 'Aspirantes', section: 'aspirantes', text: 'Consultar aspirantes admitidos.' },
      { label: 'Convocatorias', section: 'convocatorias', text: 'Revisar fechas y llamados vigentes.' },
      { label: 'Tribunales', section: 'tribunales', text: 'Consultar composición del tribunal.' },
      { label: 'Evaluación', section: 'evaluacion', text: 'Registrar el resultado del examen.' },
      { label: 'Actas', section: 'actas', text: 'Ver resultados emitidos.' }
    ];

    return `
      <div class="grid four">
        ${statCard('Convocatorias', state.calls.length)}
        ${statCard('Tribunales', state.tribunals.length)}
        ${statCard('Evaluaciones registradas', state.evaluations.length)}
        ${statCard('Notificaciones', unreadNotifications(user))}
      </div>

      <section class="table-card" style="margin-top:18px">
        <div class="table-head">
          <div>
            <span class="eyebrow">Panel del juez</span>
            <h3>Acciones de evaluación</h3>
          </div>
          <span class="badge teal">Juez</span>
        </div>
        <div class="quick-action-grid">
          ${judgeActions.map(item => `
            <button type="button" class="quick-action" data-go-section="${item.section}">
              <strong>${item.label}</strong>
              <span>${item.text}</span>
            </button>`).join('')}
        </div>
      </section>

      <div class="grid two" style="margin-top:18px">
        <section class="card">
          <span class="eyebrow">Criterios del examen</span>
          <div class="kv"><strong>Bloque común</strong><span>Kihon Waza, Kata, Kihon Kumite, Oyo-Waza y temario específico.</span></div>
          <div class="kv"><strong>Bloque específico</strong><span>Vía kumite, campeonatos o técnica.</span></div>
          <div class="kv"><strong>Evaluación</strong><span>Presentación, actitud, técnica, control y conocimiento.</span></div>
        </section>
        <section class="card">
          <span class="eyebrow">Resultados</span>
          <div class="kv"><strong>Aptos</strong><span>${state.evaluations.filter(item => item.finalResult === 'Apto').length}</span></div>
          <div class="kv"><strong>No aptos</strong><span>${state.evaluations.filter(item => item.finalResult === 'No apto').length}</span></div>
          <div class="kv"><strong>Pendientes</strong><span>${state.evaluations.filter(item => item.finalResult === 'Pendiente').length}</span></div>
        </section>
      </div>`;
  }

  return `
    <div class="grid four">
      ${statCard('Notificaciones', unreadNotifications(user))}
      ${statCard('Documentos', ownAspirant ? (ownAspirant.docStatus || 'Pendiente') : 'Pendiente')}
      ${statCard('Cuota', ownAspirant ? (ownAspirant.feeStatus || 'Pendiente') : 'Pendiente')}
      ${statCard('Examen asignado', ownAssignedCalls[0]?.date || 'Pendiente')}
    </div>

    <section class="table-card" style="margin-top:18px">
      <div class="table-head">
        <div>
          <span class="eyebrow">Panel del aspirante</span>
          <h3>Mi proceso de grado</h3>
        </div>
        <span class="badge gold">Aspirante</span>
      </div>
      <div class="quick-action-grid">
        ${[
          { label: 'Notificaciones', section: 'notificaciones', text: 'Ver avisos sobre tu proceso.' },
          { label: 'Mi ficha', section: 'aspirantes', text: 'Consultar tus datos personales y deportivos.' },
          { label: 'Documentos', section: 'documentacion', text: 'Verificar el estado de tus requisitos.' },
          { label: 'Cuota', section: 'cuotas', text: 'Consultar el estado de la cuota de examen.' },
          { label: 'Convocatorias', section: 'convocatorias', text: 'Revisar fechas de examen disponibles.' },
          { label: 'Resultados', section: 'actas', text: 'Consultar el resultado final del proceso.' }
        ].map(item => `
          <button type="button" class="quick-action" data-go-section="${item.section}">
            <strong>${item.label}</strong>
            <span>${item.text}</span>
          </button>`).join('')}
      </div>
    </section>

    <div class="grid two" style="margin-top:18px">
      <section class="card">
        <span class="eyebrow">Estado actual</span>
        <div class="kv"><strong>Grado solicitado</strong><span>${escapeHtml(ownAspirant?.requestedGrade || 'No definido')}</span></div>
        <div class="kv"><strong>Estado de la solicitud</strong><span>${badgeForStatus(ownAspirant?.status || 'Pendiente')}</span></div>
        <div class="kv"><strong>Documentación</strong><span>${badgeForStatus(ownAspirant?.docStatus || 'Pendiente')}</span></div>
        <div class="kv"><strong>Cuota</strong><span>${badgeForStatus(ownAspirant?.feeStatus || 'Pendiente')}</span></div>
        <div class="kv"><strong>Fecha de examen</strong><span>${escapeHtml(ownAssignedCalls[0]?.date || 'Sin asignar')}</span></div>
      </section>
      <section class="card">
        <span class="eyebrow">Resultado del examen</span>
        <div class="kv"><strong>Bloque común</strong><span>${escapeHtml(ownEvaluations[0]?.commonBlock || 'Pendiente')}</span></div>
        <div class="kv"><strong>Bloque específico</strong><span>${escapeHtml(ownEvaluations[0]?.specificBlock || 'Pendiente')}</span></div>
        <div class="kv"><strong>Resultado final</strong><span>${badgeForStatus(ownEvaluations[0]?.finalResult || 'Pendiente')}</span></div>
        <div class="kv"><strong>Examen teórico</strong><span>${escapeHtml(ownAspirant?.examSubmission ? 'Enviado' : 'Pendiente')}</span></div>
        <div class="kv"><strong>Observación</strong><span>${escapeHtml(ownEvaluations[0]?.note || 'Aún no existe un resultado registrado.')}</span></div>
      </section>
    </div>`;
}

function statCard(label, value) {
  return `<article class="stat-card"><span>${label}</span><strong>${value}</strong></article>`;
}

function badgeForStatus(status) {
  const map = {
    Pendiente: 'gray',
    'En revisión': 'teal',
    Admitido: 'green',
    'No admitido': 'red',
    Apto: 'green',
    'No apto': 'red',
    Completa: 'green',
    Incompleta: 'orange',
    Pagada: 'green',
    Exenta: 'teal',
    'Reducción 50%': 'gold'
  };
  const cls = map[status] || 'gray';
  return `<span class="badge ${cls}">${escapeHtml(status)}</span>`;
}


function renderNotifications() {
  const user = currentUser();
  const notices = notificationsFor(user);
  return `
    ${sectionIntro('Notificaciones', 'Aquí aparecen avisos internos del sistema para dar seguimiento a asignaciones, cambios y resultados.')}
    <section class="table-card">
      <div class="table-head">
        <h3>Avisos recibidos</h3>
        <button class="btn btn-secondary no-print" type="button" id="markNoticesRead">Marcar como leídas</button>
      </div>
      <div class="table-wrap">
        ${notices.length ? `<table class="table"><thead><tr><th>Fecha</th><th>Asunto</th><th>Mensaje</th><th>Estado</th></tr></thead><tbody>${notices.map(item => `<tr><td>${escapeHtml(item.createdAt)}</td><td>${escapeHtml(item.title)}</td><td>${escapeHtml(item.message)}</td><td>${item.read ? '<span class="badge gray">Leída</span>' : '<span class="badge gold">Nueva</span>'}</td></tr>`).join('')}</tbody></table>` : `<div class="empty">No tienes notificaciones por ahora.</div>`}
      </div>
    </section>`;
}

function renderNormativa() {
  return `
    ${sectionIntro('Normativa aplicada', 'Esta sección resume la lógica principal usada por el sistema. Está pensada para que se entienda rápido qué valida cada módulo.')}
    <div class="accordion">
      ${accordionItem('Departamento de grados', 'Vela por el nivel del karate y reconoce el esfuerzo físico-técnico y la actitud del aspirante.')}
      ${accordionItem('Tribunal, jueces y árbitros', 'El tribunal califica. Los jueces valoran el examen y el departamento puede auxiliarse de árbitros de shiai kumite.')}
      ${accordionItem('Aspirante', 'Debe presentarse correctamente, respetar la ceremonia, conocer la normativa y demostrar preparación técnico-física.')}
      ${accordionItem('Exámenes y resultados', 'Los resultados se comunican al final o por escrito, pero se consideran definitivos con el acta oficial.')}
      ${accordionItem('Criterios de valoración', 'Se evalúa presentación, actitud, ejecución técnica, aseo, concentración, control, coordinación y conocimientos.')}
      ${accordionItem('Requisitos administrativos', 'Edad, tiempo reglamentario, licencias, carnet de grados, documentación, cuota y plazos de entrega.')}
      ${accordionItem('Bloques de examen', 'Hasta tercer DAN existen bloque común y bloque específico. El bloque común debe aprobarse para pasar al específico.')}
      ${accordionItem('Situaciones especiales', 'Dispensa médica, convalidación, campeonatos, selección nacional y reconocimiento de méritos.')}
    </div>`;
}

function accordionItem(title, text) {
  return `<details><summary>${title}</summary><p>${text}</p></details>`;
}

function renderRules() {
  const rows = gradeRules.map(rule => `
    <tr>
      <td>${escapeHtml(rule.grade)}</td>
      <td>${rule.minAge} años</td>
      <td>${rule.minYears} año(s) desde ${escapeHtml(rule.from)}</td>
      <td>${rule.cons} consecutivas o ${rule.alt} alternas</td>
      <td>${rule.practice ? `${rule.practice} años desde 1º DAN` : 'No aplica'}</td>
    </tr>`).join('');
  return `
    ${sectionIntro('Reglas por grado', 'Aquí se consultan edad mínima, permanencia, licencias y práctica requerida para cada grado.')}
    <section class="table-card">
      <div class="table-head"><h3>Tabla de requisitos</h3></div>
      <div class="table-wrap">
        <table class="table">
          <thead><tr><th>Grado</th><th>Edad mínima</th><th>Permanencia</th><th>Licencias</th><th>Práctica adicional</th></tr></thead>
          <tbody>${rows}</tbody>
        </table>
      </div>
    </section>`;
}


function renderUsers() {
  const state = loadState();
  const internalUsers = state.users.filter(item => item.role !== 'aspirante');
  return `
    ${sectionIntro('Usuarios internos', 'Desde aquí el administrador crea cuentas para jueces y otros administradores. Los aspirantes se registran desde el login público.')}
    <div class="btn-row no-print"><button class="btn btn-primary" type="button" id="newUserBtn">Nuevo usuario interno</button></div>
    <section class="table-card" style="margin-top:16px">
      <div class="table-head"><h3>Listado de usuarios</h3><span class="badge gold">${internalUsers.length} registro(s)</span></div>
      <div class="table-wrap">
        ${internalUsers.length ? `<table class="table"><thead><tr><th>Nombre</th><th>Cédula</th><th>Correo</th><th>Rol</th><th>Acción</th></tr></thead><tbody>${internalUsers.map(item => `<tr><td>${escapeHtml(fullName(item))}</td><td>${escapeHtml(item.cedula)}</td><td>${escapeHtml(item.email)}</td><td>${escapeHtml(roleLabel(item.role))}</td><td><button class="btn btn-secondary" type="button" data-edit-user="${item.id}">Editar</button></td></tr>`).join('')}</tbody></table>` : `<div class="empty">Todavía no hay jueces ni administradores adicionales.</div>`}
      </div>
    </section>`;
}

function renderAspirants() {
  const state = loadState();
  const user = currentUser();
  const aspirants = user.role === 'aspirante'
    ? state.aspirants.filter(item => item.userId === user.id)
    : user.role === 'juez'
      ? state.aspirants.filter(item => item.status === 'Admitido')
      : state.aspirants;
  const canEdit = ['admin'].includes(user.role);
  const rows = aspirants.map(item => `
    <tr>
      <td>${escapeHtml(item.names)} ${escapeHtml(item.lastnames)}</td>
      <td>${escapeHtml(item.cedula)}</td>
      <td>${escapeHtml(item.requestedGrade)}</td>
      <td>${escapeHtml(item.style || '—')}</td>
      <td>${badgeForStatus(item.status)}</td>
      <td>${badgeForStatus(item.docStatus)}</td>
      <td>${badgeForStatus(item.feeStatus)}</td>
      <td>${readinessBadge(item)}</td>
      <td>${canEdit ? `<button class="btn btn-secondary" type="button" data-edit-aspirant="${item.id}">Editar</button>` : `<button class="btn btn-secondary" type="button" data-view-aspirant="${item.id}">Ver</button>`}</td>
    </tr>`).join('');

  return `
    ${sectionIntro('Aspirantes', user.role === 'juez' ? 'El juez consulta aspirantes admitidos para examen. No puede editar documentación, cuota ni datos administrativos.' : 'Aquí se registran y actualizan los datos deportivos y personales. Si eres aspirante, verás solamente tu ficha.')}
    ${canEdit ? `<div class="btn-row no-print"><button class="btn btn-primary" type="button" id="newAspirantBtn">Nuevo aspirante</button></div>` : ''}
    <section class="table-card" style="margin-top:16px">
      <div class="table-head"><h3>Listado de aspirantes</h3><span class="badge teal">${aspirants.length} registro(s)</span></div>
      <div class="table-wrap">
        ${aspirants.length ? `<table class="table"><thead><tr><th>Nombre</th><th>Cédula</th><th>Grado solicitado</th><th>Estilo</th><th>Estado</th><th>Documentos</th><th>Cuota</th><th>Preparación</th><th>Acción</th></tr></thead><tbody>${rows}</tbody></table>` : `<div class="empty">Aún no hay aspirantes registrados.</div>`}
      </div>
    </section>`;
}

function readinessBadge(aspirant) {
  const readiness = aspirantReadiness(aspirant);
  return readiness.ready
    ? '<span class="badge green">Listo</span>'
    : `<span class="badge orange" title="${escapeHtml(readiness.label)}">Revisar</span>`;
}

function renderDocuments() {
  const user = currentUser();
  const state = loadState();

  if (user.role === 'aspirante') {
    const aspirant = getOwnAspirant();
    return `
      ${sectionIntro('Mis documentos', 'Sube tus documentos para que el administrador revise tu expediente y consulta el estado de cada requisito.')}
      ${aspirant ? aspirantUploadPanel(aspirant) : '<div class="empty">No se encontró tu expediente de aspirante.</div>'}`;
  }

  const aspirants = state.aspirants;
  const selectedId = aspirants[0]?.id || '';
  const summary = selectedId ? documentEditor(selectedId, false) : '<div class="empty">No hay aspirantes disponibles.</div>';
  return `
    ${sectionIntro('Revisión documental', 'El administrador revisa los documentos enviados por el aspirante y decide si el expediente queda admitido o no admitido para examen.')}
    <div class="toolbar">
      <select id="docAspirantSelect">${aspirants.map(item => `<option value="${item.id}">${escapeHtml(item.names)} ${escapeHtml(item.lastnames)}</option>`).join('')}</select>
    </div>
    <div id="docEditor">${summary}</div>`;
}

function aspirantUploadPanel(aspirant) {
  const uploads = aspirant.uploads || {};
  const rows = documentChecklist.map(label => {
    const upload = uploads[label] || {};
    const review = aspirant.documents?.[label] || { status: 'Pendiente', note: '' };
    return `<div class="check-row">
      <div>
        <strong>${escapeHtml(label)}</strong><br>
        <span class="muted">${upload.fileName ? `Archivo enviado: ${escapeHtml(upload.fileName)}` : 'Aún no has enviado este documento.'}</span>
      </div>
      <input type="file" data-upload-doc="${escapeHtml(label)}" />
      <div>
        ${badgeForStatus(review.status || 'Pendiente')}
        <br><span class="muted">${escapeHtml(review.note || 'Sin observación del administrador.')}</span>
      </div>
    </div>`;
  }).join('');

  return `
    <section class="card">
      <div class="kv"><strong>Aspirante</strong><span>${escapeHtml(aspirant.names)} ${escapeHtml(aspirant.lastnames)}</span></div>
      <div class="kv"><strong>Estado documental</strong><span>${badgeForStatus(aspirant.docStatus)}</span></div>
      <div class="check-list" style="margin-top:16px">${rows}</div>
      <div class="btn-row no-print">
        <button class="btn btn-primary" type="button" id="saveUploadsBtn" data-aspirant="${aspirant.id}">Enviar documentos</button>
      </div>
    </section>`;
}

function documentEditor(aspirantId, readOnly = false) {
  const aspirant = loadState().aspirants.find(item => item.id === aspirantId);
  if (!aspirant) return '<div class="empty">No se encontró el aspirante.</div>';
  const uploads = aspirant.uploads || {};
  const rows = documentChecklist.map(label => {
    const data = aspirant.documents?.[label] || { status: 'Pendiente', note: '' };
    const upload = uploads[label] || {};
    const disabled = readOnly ? 'disabled' : '';
    return `<div class="check-row">
      <div>
        <strong>${escapeHtml(label)}</strong><br>
        <span class="muted">${upload.fileName ? `Enviado: ${escapeHtml(upload.fileName)} · ${escapeHtml(upload.uploadedAt || '')}` : 'Sin archivo enviado'}</span>
      </div>
      <select data-doc-status="${escapeHtml(label)}" ${disabled}>
        <option ${data.status === 'Completa' ? 'selected' : ''}>Completa</option>
        <option ${data.status === 'Pendiente' ? 'selected' : ''}>Pendiente</option>
        <option ${data.status === 'No cumple' ? 'selected' : ''}>No cumple</option>
      </select>
      <input data-doc-note="${escapeHtml(label)}" value="${escapeHtml(data.note)}" placeholder="Observación para el aspirante" ${disabled}/>
    </div>`;
  }).join('');

  return `
    <section class="card">
      <div class="kv"><strong>Aspirante</strong><span>${escapeHtml(aspirant.names)} ${escapeHtml(aspirant.lastnames)}</span></div>
      <div class="kv"><strong>Estado documental</strong><span>${badgeForStatus(aspirant.docStatus)}</span></div>
      <div class="kv"><strong>Estado de solicitud</strong><span>${badgeForStatus(aspirant.status)}</span></div>
      <div class="check-list" style="margin-top:16px">${rows}</div>
      ${readOnly ? '' : `<div class="btn-row no-print">
        <button class="btn btn-primary" type="button" id="saveDocumentsBtn" data-aspirant="${aspirant.id}">Guardar revisión</button>
        <button class="btn btn-secondary" type="button" data-admit-aspirant="${aspirant.id}">Admitir</button>
        <button class="btn btn-danger" type="button" data-reject-aspirant="${aspirant.id}">No admitir</button>
      </div>`}
    </section>`;
}

function renderFees() {
  const user = currentUser();
  const state = loadState();

  if (user.role === 'aspirante') {
    const aspirant = getOwnAspirant();
    if (!aspirant) return `${sectionIntro('Cuota de examen', 'No se encontró tu expediente de aspirante.')}`;
    const canPay = aspirant.feeStatus === 'Pendiente';
    return `
      ${sectionIntro('Mi cuota de examen', 'Consulta y registra el estado de tu cuota. El administrador podrá verificar o cambiar el estado si corresponde.')}
      <section class="card">
        <div class="kv"><strong>Aspirante</strong><span>${escapeHtml(aspirant.names)} ${escapeHtml(aspirant.lastnames)}</span></div>
        <div class="kv"><strong>Estado de cuota</strong><span>${badgeForStatus(aspirant.feeStatus)}</span></div>
        <div class="kv"><strong>Motivo / referencia</strong><span>${escapeHtml(aspirant.feeReason || 'Sin registro')}</span></div>
        <div class="btn-row no-print">
          ${canPay ? `<button class="btn btn-primary" type="button" id="payFeeBtn" data-aspirant="${aspirant.id}">Pagar cuota</button>` : '<span class="badge green">Cuota registrada</span>'}
          <button class="btn btn-secondary" type="button" id="requestExemptionBtn" data-aspirant="${aspirant.id}">Solicitar exención</button>
        </div>
      </section>`;
  }

  const aspirants = state.aspirants;
  return `
    ${sectionIntro('Control de cuotas', 'El administrador verifica el estado de la cuota de examen de cada aspirante: pendiente, pagada, exenta o reducción del 50%.')}
    <section class="table-card">
      <div class="table-head"><h3>Control de cuotas</h3></div>
      <div class="table-wrap">
        ${aspirants.length ? `<table class="table"><thead><tr><th>Aspirante</th><th>Estado</th><th>Motivo</th><th>Acción</th></tr></thead><tbody>${aspirants.map(item => `
          <tr>
            <td>${escapeHtml(item.names)} ${escapeHtml(item.lastnames)}</td>
            <td>${badgeForStatus(item.feeStatus)}</td>
            <td>${escapeHtml(item.feeReason || '—')}</td>
            <td><button class="btn btn-secondary" type="button" data-edit-fee="${item.id}">Actualizar</button></td>
          </tr>`).join('')}</tbody></table>` : `<div class="empty">No hay aspirantes para controlar cuotas.</div>`}
      </div>
    </section>`;
}


function renderAspirantExamPanel() {
  const state = loadState();
  const aspirant = getOwnAspirant();
  const assigned = aspirant ? state.calls.filter(call => (call.aspirantIds || []).includes(aspirant.id)) : [];
  const alreadySent = aspirant?.examSubmission;
  return `
    ${sectionIntro('Mi evaluación', 'Aquí el aspirante consulta su fecha de examen y, cuando esté admitido y asignado a una convocatoria, puede ingresar al examen teórico.')}
    <div class="grid two">
      <section class="card">
        <span class="eyebrow">Estado para rendir examen</span>
        <div class="kv"><strong>Estado de solicitud</strong><span>${badgeForStatus(aspirant?.status || 'Pendiente')}</span></div>
        <div class="kv"><strong>Documentación</strong><span>${badgeForStatus(aspirant?.docStatus || 'Pendiente')}</span></div>
        <div class="kv"><strong>Cuota</strong><span>${badgeForStatus(aspirant?.feeStatus || 'Pendiente')}</span></div>
        <div class="kv"><strong>Examen enviado</strong><span>${alreadySent ? '<span class="badge green">Enviado</span>' : '<span class="badge gray">Pendiente</span>'}</span></div>
      </section>
      <section class="card">
        <span class="eyebrow">Condiciones</span>
        <p class="muted">La convocatoria puede llegar antes de completar todo el expediente. Para rendir el examen, administración debe dejar tu solicitud admitida.</p>
      </section>
    </div>
    ${assigned.length ? `<div class="grid two" style="margin-top:18px">${assigned.map(call => `
      <section class="card">
        <span class="eyebrow">Convocatoria asignada</span>
        <h3>${escapeHtml(call.name)}</h3>
        <div class="kv"><strong>Fecha</strong><span>${escapeHtml(call.date || 'Sin fecha')}</span></div>
        <div class="kv"><strong>Lugar</strong><span>${escapeHtml(call.place || 'Sin lugar')}</span></div>
        <div class="kv"><strong>Tipo</strong><span>${escapeHtml(call.type || 'Examen')}</span></div>
        <div class="kv"><strong>Estado</strong><span>${badgeForStatus(call.status)}</span></div>
        <div class="btn-row no-print">
          ${aspirant.status === 'Admitido' ? `<button class="btn btn-primary" type="button" data-take-exam="${call.id}">${alreadySent?.callId === call.id ? 'Ver examen enviado' : 'Dar examen'}</button>` : '<span class="badge orange">Disponible cuando seas admitido</span>'}
        </div>
      </section>`).join('')}</div>` : `<section class="card" style="margin-top:18px"><h3>Aún no tienes convocatoria asignada</h3><p class="muted">Cuando el administrador asigne tu examen, aparecerá aquí la fecha, lugar y acceso para dar el examen.</p></section>`}
  `;
}

function renderCalls() {
  const state = loadState();
  const user = currentUser();

  if (user.role === 'aspirante') {
    const aspirant = getOwnAspirant();
    const assigned = aspirant ? state.calls.filter(call => (call.aspirantIds || []).includes(aspirant.id)) : [];
    return `
      ${sectionIntro('Mis convocatorias', 'Aquí ves la fecha, lugar y estado de la convocatoria asignada por administración.')}
      ${assigned.length ? `<div class="grid two">${assigned.map(call => `
        <section class="card">
          <span class="eyebrow">Convocatoria asignada</span>
          <h3>${escapeHtml(call.name)}</h3>
          <div class="kv"><strong>Fecha</strong><span>${escapeHtml(call.date || 'Sin fecha')}</span></div>
          <div class="kv"><strong>Lugar</strong><span>${escapeHtml(call.place || 'Sin lugar')}</span></div>
          <div class="kv"><strong>Tipo</strong><span>${escapeHtml(call.type || 'Examen')}</span></div>
          <div class="kv"><strong>Estado</strong><span>${badgeForStatus(call.status)}</span></div>
        </section>`).join('')}</div>` : `<section class="card"><h3>Aún no tienes convocatoria asignada</h3><p class="muted">Cuando el administrador asigne tu examen, aparecerá aquí la fecha y el lugar.</p></section>`}
    `;
  }

  return `
    ${sectionIntro('Convocatorias', user.role === 'juez' ? 'El juez consulta las fechas de examen y aspirantes asignados.' : 'El administrador crea convocatorias y asigna aspirantes. Si falta documentación o cuota, el sistema lo muestra como alerta sin bloquear la convocatoria.')}
    ${['admin'].includes(user.role) ? `<div class="btn-row no-print"><button class="btn btn-primary" type="button" id="newCallBtn">Crear convocatoria</button></div>` : ''}
    ${user.role === 'admin' ? renderCallReadinessPanel(state) : ''}
    <section class="table-card" style="margin-top:16px">
      <div class="table-head"><h3>Listado de convocatorias</h3></div>
      <div class="table-wrap">
        ${state.calls.length ? `<table class="table"><thead><tr><th>Nombre</th><th>Fecha</th><th>Lugar</th><th>Tipo</th><th>Asignados</th><th>Estado</th><th>Acción</th></tr></thead><tbody>${state.calls.map(item => `<tr><td>${escapeHtml(item.name)}</td><td>${escapeHtml(item.date)}</td><td>${escapeHtml(item.place)}</td><td>${escapeHtml(item.type)}</td><td>${(item.aspirantIds || []).length}</td><td>${badgeForStatus(item.status)}</td><td>${user.role === 'admin' ? `<button class="btn btn-secondary" type="button" data-assign-call="${item.id}">Asignar</button>` : 'Consulta'}</td></tr>`).join('')}</tbody></table>` : `<div class="empty">Aún no hay convocatorias creadas.</div>`}
      </div>
    </section>`;
}

function renderCallReadinessPanel(state) {
  const rows = state.aspirants.map(aspirant => {
    const readiness = aspirantReadiness(aspirant);
    const assigned = callForAspirant(state, aspirant.id);
    return `
      <tr>
        <td>${escapeHtml(aspirant.names)} ${escapeHtml(aspirant.lastnames)}</td>
        <td>${escapeHtml(aspirant.requestedGrade)}</td>
        <td>${readiness.ready ? '<span class="badge green">Listo</span>' : `<span class="badge orange">${escapeHtml(readiness.label)}</span>`}</td>
        <td>${assigned ? escapeHtml(`${assigned.name} · ${assigned.date}`) : '<span class="muted">Sin convocatoria</span>'}</td>
      </tr>`;
  }).join('');

  return `
    <section class="table-card" style="margin-top:16px">
      <div class="table-head">
        <h3>Preparación para convocar</h3>
        <span class="badge gold">Seguimiento</span>
      </div>
      <div class="table-wrap">
        ${state.aspirants.length ? `<table class="table"><thead><tr><th>Aspirante</th><th>Grado</th><th>Estado para examen</th><th>Convocatoria</th></tr></thead><tbody>${rows}</tbody></table>` : `<div class="empty">Crea o registra aspirantes para poder convocarlos.</div>`}
      </div>
    </section>`;
}

function renderTribunals() {
  const state = loadState();
  return `
    ${sectionIntro('Tribunales', 'Aquí se registra el tribunal responsable del examen: jueces, director y árbitros auxiliares. Si el número de jueces es par, el sistema lo advierte.')}
    ${['admin'].includes(currentUser().role) ? `<div class="btn-row no-print"><button class="btn btn-primary" type="button" id="newTribunalBtn">Crear tribunal</button></div>` : ''}
    <section class="table-card" style="margin-top:16px">
      <div class="table-head"><h3>Tribunales registrados</h3></div>
      <div class="table-wrap">
        ${state.tribunals.length ? `<table class="table"><thead><tr><th>Nombre</th><th>Fecha</th><th>Jueces</th><th>Director</th><th>Observación</th></tr></thead><tbody>${state.tribunals.map(item => `<tr><td>${escapeHtml(item.name)}</td><td>${escapeHtml(item.date)}</td><td>${escapeHtml(item.judges)}</td><td>${escapeHtml(item.director)}</td><td>${escapeHtml(item.note || '—')}</td></tr>`).join('')}</tbody></table>` : `<div class="empty">No hay tribunales creados.</div>`}
      </div>
    </section>`;
}

function renderEvaluation() {
  const state = loadState();
  const user = currentUser();

  if (user.role === 'aspirante') {
    return renderAspirantExamPanel();
  }

  const evaluableAspirants = user.role === 'juez' ? state.aspirants.filter(item => item.status === 'Admitido') : state.aspirants;
  return `
    ${sectionIntro('Evaluación', user.role === 'juez' ? 'El juez registra el resultado técnico del examen para aspirantes admitidos. No administra documentos ni cuotas.' : 'Se registra el resultado del bloque común y del bloque específico. El sistema marca la decisión final y deja observaciones.')}
    ${evaluableAspirants.length ? `<div class="toolbar"><select id="evaluationAspirantSelect">${evaluableAspirants.map(item => `<option value="${item.id}">${escapeHtml(item.names)} ${escapeHtml(item.lastnames)} · ${escapeHtml(item.requestedGrade)}</option>`).join('')}</select><button class="btn btn-primary" type="button" id="openEvaluationBtn">Evaluar</button></div>` : '<div class="empty">No hay aspirantes admitidos para evaluar.</div>'}
    <section class="card" style="margin-top:16px">
      <h3>Cómo funciona</h3>
      <div class="info-list">
        <div class="info-item"><h4>Bloque común</h4><p>Kihon Waza, Kata, Kihon Kumite, Oyo-Waza y temario específico.</p></div>
        <div class="info-item"><h4>Bloque específico</h4><p>Puede seguir vía kumite, campeonatos o técnica.</p></div>
        <div class="info-item"><h4>Resultado final</h4><p>Solo se considera apto si supera los criterios necesarios y el bloque común está aprobado.</p></div>
      </div>
    </section>`;
}

function renderRecords() {
  const user = currentUser();
  const state = loadState();
  const records = user.role === 'aspirante'
    ? state.evaluations.filter(ev => ev.userId === user.id)
    : state.evaluations;

  if (user.role === 'aspirante') {
    const record = records[0];
    return `
      ${sectionIntro('Mi resultado', 'Aquí consultas tu resultado final cuando el juez registre la evaluación del examen.')}
      ${record ? `<section class="card">
        <span class="eyebrow">Resultado publicado</span>
        <h3>${badgeForStatus(record.finalResult)}</h3>
        <div class="kv"><strong>Grado solicitado</strong><span>${escapeHtml(record.requestedGrade)}</span></div>
        <div class="kv"><strong>Bloque común</strong><span>${badgeForStatus(record.commonBlock)}</span></div>
        <div class="kv"><strong>Bloque específico</strong><span>${badgeForStatus(record.specificBlock)}</span></div>
        <div class="kv"><strong>Convocatoria</strong><span>${escapeHtml(record.call || '—')}</span></div>
        <div class="kv"><strong>Tribunal</strong><span>${escapeHtml(record.tribunal || '—')}</span></div>
        <div class="kv"><strong>Observaciones</strong><span>${escapeHtml(record.note || 'Sin observaciones.')}</span></div>
        <div class="btn-row no-print"><button class="btn btn-secondary" type="button" data-print-record="${record.id}">Ver acta</button></div>
      </section>` : `<section class="card"><h3>Resultado pendiente</h3><p class="muted">Aún no existe una evaluación registrada para tu expediente.</p></section>`}`;
  }

  return `
    ${sectionIntro('Resultados y actas', 'Esta sección muestra los resultados registrados y permite imprimir el acta.')}
    <section class="table-card">
      <div class="table-head"><h3>Actas registradas</h3></div>
      <div class="table-wrap">
        ${records.length ? `<table class="table"><thead><tr><th>Aspirante</th><th>Grado</th><th>Bloque común</th><th>Bloque específico</th><th>Resultado final</th><th>Acción</th></tr></thead><tbody>${records.map(item => `<tr><td>${escapeHtml(item.fullName)}</td><td>${escapeHtml(item.requestedGrade)}</td><td>${badgeForStatus(item.commonBlock)}</td><td>${badgeForStatus(item.specificBlock)}</td><td>${badgeForStatus(item.finalResult)}</td><td><button class="btn btn-secondary" type="button" data-print-record="${item.id}">Ver / imprimir</button></td></tr>`).join('')}</tbody></table>` : `<div class="empty">Todavía no hay actas registradas.</div>`}
      </div>
    </section>`;
}

function renderSpecialCases() {
  const user = currentUser();
  const aspirants = user.role === 'aspirante' ? [getOwnAspirant()].filter(Boolean) : loadState().aspirants;
  return `
    ${sectionIntro('Situaciones especiales', 'Sirve para registrar si el aspirante tiene dispensa médica, convalidación, campeonatos, selección nacional u otro mérito reconocido.')}
    <section class="table-card">
      <div class="table-head"><h3>Control de casos especiales</h3></div>
      <div class="table-wrap">
        ${aspirants.length ? `<table class="table"><thead><tr><th>Aspirante</th><th>Situación</th><th>Observación</th><th>Acción</th></tr></thead><tbody>${aspirants.map(item => `<tr><td>${escapeHtml(item.names)} ${escapeHtml(item.lastnames)}</td><td>${escapeHtml(item.specialSituation || 'Ninguna')}</td><td>${escapeHtml(item.observations || '—')}</td><td>${user.role === 'aspirante' ? 'Solo lectura' : `<button class="btn btn-secondary" type="button" data-edit-special="${item.id}">Actualizar</button>`}</td></tr>`).join('')}</tbody></table>` : `<div class="empty">No hay aspirantes disponibles.</div>`}
      </div>
    </section>`;
}

function renderStyles() {
  return `
    ${sectionIntro('Estilos reconocidos', 'Resumen visual de los estilos de karate reconocidos por la normativa.')}
    <div class="grid three">
      ${stylesCatalog.map(([name, desc, katas]) => `<section class="card"><h3>${escapeHtml(name)}</h3><p>${escapeHtml(desc)}</p><div class="kv"><strong>Katas</strong><span>${escapeHtml(katas)}</span></div></section>`).join('')}
    </div>`;
}

function renderGlossary() {
  return `
    ${sectionIntro('Glosario', 'Busca términos importantes de la normativa y del karate para entender mejor el sistema.')}
    <div class="toolbar"><input id="glossarySearch" placeholder="Buscar término" /></div>
    <div id="glossaryResults" class="grid three">${glossaryCards(glossaryCatalog)}</div>`;
}

function glossaryCards(items) {
  return items.map(([term, meaning]) => `<section class="card"><h3>${escapeHtml(term)}</h3><p>${escapeHtml(meaning)}</p></section>`).join('');
}

function renderProfile() {
  const user = currentUser();
  return `
    ${sectionIntro('Mi perfil', 'Aquí ves tus datos, puedes cambiar tu contraseña y administrar el reinicio del sistema cuando sea necesario.')}
    <section class="card">
      <div class="kv"><strong>Nombre</strong><span>${escapeHtml(fullName(user))}</span></div>
      <div class="kv"><strong>Correo</strong><span>${escapeHtml(user.email)}</span></div>
      <div class="kv"><strong>Cédula</strong><span>${escapeHtml(user.cedula)}</span></div>
      <div class="kv"><strong>Rol</strong><span>${escapeHtml(roleLabel(user.role))}</span></div>
      <div class="btn-row no-print">
        <button class="btn btn-primary" type="button" id="changePasswordBtn">Cambiar contraseña</button>
        ${user.role === 'admin' ? `<button class="btn btn-danger" type="button" id="resetSystemBtn">Restablecer sistema</button>` : ''}
      </div>
    </section>`;
}

function bindSectionActions(sectionId) {
  const state = loadState();
  if (sectionId === 'notificaciones') {
    $('#markNoticesRead')?.addEventListener('click', () => {
      const state = loadState();
      const user = currentUser();
      state.notifications.forEach(item => {
        if (item.userId === user.id || item.role === user.role || item.role === 'all') item.read = true;
      });
      saveState(state);
      toast('Notificaciones marcadas como leídas.');
      renderSidebar();
      renderSection('notificaciones');
    });
  }
  if (sectionId === 'dashboard') {
    $$('[data-go-section]').forEach(btn => btn.addEventListener('click', () => {
      activeSection = btn.dataset.goSection;
      renderSidebar();
      renderSection(activeSection);
    }));
  }
  if (sectionId === 'usuarios') {
    $('#newUserBtn')?.addEventListener('click', () => openUserModal());
    $$('[data-edit-user]').forEach(btn => btn.addEventListener('click', () => openUserModal(btn.dataset.editUser)));
  }
  if (sectionId === 'aspirantes') {
    $('#newAspirantBtn')?.addEventListener('click', () => openAspirantModal());
    $$('[data-edit-aspirant]').forEach(btn => btn.addEventListener('click', () => openAspirantModal(btn.dataset.editAspirant)));
    $$('[data-view-aspirant]').forEach(btn => btn.addEventListener('click', () => openReadOnlyAspirant(btn.dataset.viewAspirant)));
  }

  if (sectionId === 'documentacion') {
    const select = $('#docAspirantSelect');
    if (select) {
      select.addEventListener('change', () => { $('#docEditor').innerHTML = documentEditor(select.value, false); bindSectionActions('documentacion'); });
    }
    $('#saveUploadsBtn')?.addEventListener('click', saveAspirantUploads);
    $('#saveDocumentsBtn')?.addEventListener('click', saveDocumentsForSelected);
    $$('[data-admit-aspirant]').forEach(btn => btn.addEventListener('click', () => setAspirantAdmission(btn.dataset.admitAspirant, 'Admitido')));
    $$('[data-reject-aspirant]').forEach(btn => btn.addEventListener('click', () => setAspirantAdmission(btn.dataset.rejectAspirant, 'No admitido')));
  }

  if (sectionId === 'cuotas') {
    $('#payFeeBtn')?.addEventListener('click', payFeeAsAspirant);
    $('#requestExemptionBtn')?.addEventListener('click', requestFeeExemption);
    $$('[data-edit-fee]').forEach(btn => btn.addEventListener('click', () => openFeeModal(btn.dataset.editFee)));
  }

  if (sectionId === 'convocatorias') {
    $('#newCallBtn')?.addEventListener('click', openCallModal);
    $$('[data-assign-call]').forEach(btn => btn.addEventListener('click', () => openAssignCallModal(btn.dataset.assignCall)));
    $$('[data-take-exam]').forEach(btn => btn.addEventListener('click', () => openTakeExamModal(btn.dataset.takeExam)));
    $$('[data-go-section]').forEach(btn => btn.addEventListener('click', () => { activeSection = btn.dataset.goSection; renderSidebar(); renderSection(activeSection); }));
  }

  if (sectionId === 'tribunales') {
    $('#newTribunalBtn')?.addEventListener('click', openTribunalModal);
  }

  if (sectionId === 'evaluacion') {
    $('#openEvaluationBtn')?.addEventListener('click', () => openEvaluationModal($('#evaluationAspirantSelect').value));
    $$('[data-take-exam]').forEach(btn => btn.addEventListener('click', () => openTakeExamModal(btn.dataset.takeExam)));
  }

  if (sectionId === 'actas') {
    $$('[data-print-record]').forEach(btn => btn.addEventListener('click', () => openRecordModal(btn.dataset.printRecord)));
  }

  if (sectionId === 'especiales') {
    $$('[data-edit-special]').forEach(btn => btn.addEventListener('click', () => openSpecialModal(btn.dataset.editSpecial)));
  }

  if (sectionId === 'glosario') {
    $('#glossarySearch')?.addEventListener('input', event => {
      const term = event.target.value.toLowerCase();
      const filtered = glossaryCatalog.filter(([word, meaning]) => word.toLowerCase().includes(term) || meaning.toLowerCase().includes(term));
      $('#glossaryResults').innerHTML = glossaryCards(filtered);
    });
  }

  if (sectionId === 'perfil') {
    $('#changePasswordBtn')?.addEventListener('click', openChangePasswordModal);
    $('#resetSystemBtn')?.addEventListener('click', resetSystem);
  }
}


function openUserModal(userId = '') {
  const state = loadState();
  const user = state.users.find(item => item.id === userId);
  openModal(user ? 'Editar usuario interno' : 'Nuevo usuario interno', `
    <form id="internalUserForm" class="form-grid">
      <input type="hidden" id="internalUserId" value="${escapeHtml(user?.id || '')}" />
      <div class="field"><label>Nombres</label><input id="internalNames" value="${escapeHtml(user?.names || '')}" /></div>
      <div class="field"><label>Apellidos</label><input id="internalLastnames" value="${escapeHtml(user?.lastnames || '')}" /></div>
      <div class="field"><label>Cédula</label><input id="internalCedula" maxlength="10" value="${escapeHtml(user?.cedula || '')}" /></div>
      <div class="field"><label>Correo</label><input id="internalEmail" type="email" value="${escapeHtml(user?.email || '')}" /></div>
      <div class="field"><label>Rol</label><select id="internalRole"><option value="admin" ${user?.role === 'admin' ? 'selected' : ''}>Administrador</option><option value="juez" ${user?.role === 'juez' ? 'selected' : ''}>Juez</option></select></div>
      <div class="field"><label>Contraseña</label><div class="password-wrap"><input id="internalPassword" type="password" placeholder="${user ? 'Solo llena si deseas cambiarla' : ''}" /><button type="button" class="eye-btn">👁</button></div></div>
      <div class="field"><label>Confirmar contraseña</label><div class="password-wrap"><input id="internalConfirmPassword" type="password" /><button type="button" class="eye-btn">👁</button></div></div>
      <p id="internalUserError" class="form-error field full"></p>
      <div class="field full"><button class="btn btn-primary btn-block" type="submit">Guardar usuario</button></div>
    </form>`);
  $('#internalCedula')?.addEventListener('input', e => e.target.value = e.target.value.replace(/\D/g, '').slice(0, 10));
  $$('.eye-btn', $('#modalRoot')).forEach(btn => btn.addEventListener('click', () => togglePassword(btn)));
  $('#internalUserForm')?.addEventListener('submit', saveInternalUserFromModal);
}

function saveInternalUserFromModal(event) {
  event.preventDefault();
  const state = loadState();
  const id = normalize($('#internalUserId').value);
  const names = normalize($('#internalNames').value);
  const lastnames = normalize($('#internalLastnames').value);
  const cedula = normalize($('#internalCedula').value).replace(/\D/g, '').slice(0, 10);
  const email = normalize($('#internalEmail').value).toLowerCase();
  const role = normalize($('#internalRole').value);
  const password = normalize($('#internalPassword').value);
  const confirm = normalize($('#internalConfirmPassword').value);
  const error = $('#internalUserError');
  error.textContent = '';
  if (!names || !lastnames || !cedula || !email || !role) return error.textContent = 'Completa los datos obligatorios.';
  if (!validateEmail(email)) return error.textContent = 'Correo inválido.';
  if (state.users.some(item => item.cedula === cedula && item.id !== id)) return error.textContent = 'Ya existe una cuenta con esa cédula.';
  if (state.users.some(item => item.email.toLowerCase() === email && item.id !== id)) return error.textContent = 'Ya existe una cuenta con ese correo.';
  if (!id && password.length < 6) return error.textContent = 'La contraseña debe tener mínimo 6 caracteres.';
  if (password && password.length < 6) return error.textContent = 'La contraseña debe tener mínimo 6 caracteres.';
  if (password !== confirm) return error.textContent = 'Las contraseñas no coinciden.';

  if (id) {
    const user = state.users.find(item => item.id === id);
    if (!user) return;
    user.names = names;
    user.lastnames = lastnames;
    user.cedula = cedula;
    user.email = email;
    user.role = role;
    if (password) user.password = hashPassword(password);
  } else {
    state.users.push({ id: uid(), role, names, lastnames, cedula, email, password: hashPassword(password), createdAt: today() });
  }
  saveState(state);
  toast('Usuario guardado correctamente.');
  closeModal();
  renderSection('usuarios');
}

function openAspirantModal(aspirantId = '') {
  const state = loadState();
  const aspirant = state.aspirants.find(item => item.id === aspirantId);
  openModal(aspirant ? 'Editar aspirante' : 'Nuevo aspirante', `
    <form id="aspirantForm" class="form-grid">
      <input type="hidden" id="aspId" value="${escapeHtml(aspirant?.id || '')}" />
      <div class="field"><label>Nombres</label><input id="aspNames" value="${escapeHtml(aspirant?.names || '')}" /></div>
      <div class="field"><label>Apellidos</label><input id="aspLastnames" value="${escapeHtml(aspirant?.lastnames || '')}" /></div>
      <div class="field"><label>Cédula</label><input id="aspCedula" value="${escapeHtml(aspirant?.cedula || '')}" maxlength="10" /></div>
      <div class="field"><label>Correo</label><input id="aspEmail" type="email" value="${escapeHtml(aspirant?.email || '')}" /></div>
      <div class="field"><label>Teléfono</label><input id="aspPhone" value="${escapeHtml(aspirant?.phone || '')}" /></div>
      <div class="field"><label>Fecha de nacimiento</label><input id="aspBirthDate" type="date" value="${escapeHtml(aspirant?.birthDate || '')}" /></div>
      <div class="field"><label>Club o dojo</label><input id="aspClub" value="${escapeHtml(aspirant?.club || '')}" /></div>
      <div class="field"><label>Estilo</label><select id="aspStyle">${styleOptions(aspirant?.style || '')}</select></div>
      <div class="field"><label>Grado actual</label><select id="aspCurrentGrade">${gradeOptions(aspirant?.currentGrade || 'Cinto Negro')}</select></div>
      <div class="field"><label>Grado solicitado</label><select id="aspRequestedGrade">${gradeOptions(aspirant?.requestedGrade || '1º DAN')}</select></div>
      <div class="field"><label>Fecha de grado anterior</label><input id="aspPrevGradeDate" type="date" value="${escapeHtml(aspirant?.prevGradeDate || '')}" /></div>
      <div class="field"><label>Licencias consecutivas</label><input id="aspCons" type="number" min="0" value="${Number(aspirant?.consecutiveLicenses || 0)}" /></div>
      <div class="field"><label>Licencias alternas</label><input id="aspAlt" type="number" min="0" value="${Number(aspirant?.alternateLicenses || 0)}" /></div>
      <div class="field"><label>Años desde 1º DAN</label><input id="aspPractice" type="number" min="0" value="${Number(aspirant?.practiceYearsSinceFirstDan || 0)}" /></div>
      <div class="field"><label>Aval / entrenador</label><input id="aspCoach" value="${escapeHtml(aspirant?.coachEndorsement || '')}" /></div>
      <div class="field"><label>Estado</label><select id="aspStatus"><option ${aspirant?.status === 'Pendiente' ? 'selected' : ''}>Pendiente</option><option ${aspirant?.status === 'En revisión' ? 'selected' : ''}>En revisión</option><option ${aspirant?.status === 'Admitido' ? 'selected' : ''}>Admitido</option><option ${aspirant?.status === 'No admitido' ? 'selected' : ''}>No admitido</option></select></div>
      <div class="field full"><label>Observaciones</label><textarea id="aspObs">${escapeHtml(aspirant?.observations || '')}</textarea></div>
      <p id="aspError" class="form-error field full"></p>
      <div class="field full"><button class="btn btn-primary btn-block" type="submit">Guardar aspirante</button></div>
    </form>`);
  $('#aspCedula')?.addEventListener('input', e => e.target.value = e.target.value.replace(/\D/g, '').slice(0, 10));
  $('#aspirantForm')?.addEventListener('submit', saveAspirantFromModal);
}

function saveAspirantFromModal(event) {
  event.preventDefault();
  const state = loadState();
  const id = normalize($('#aspId').value);
  const names = normalize($('#aspNames').value);
  const lastnames = normalize($('#aspLastnames').value);
  const cedula = normalize($('#aspCedula').value).replace(/\D/g, '').slice(0, 10);
  const email = normalize($('#aspEmail').value).toLowerCase();
  const error = $('#aspError');
  error.textContent = '';

  if (!names || !lastnames || !cedula || !email) return error.textContent = 'Completa los datos obligatorios.';
  if (!validateEmail(email)) return error.textContent = 'Correo inválido.';
  if (cedula.length > 10) return error.textContent = 'La cédula no debe pasar de 10 números.';
  const duplicate = state.aspirants.find(item => item.cedula === cedula && item.id !== id);
  if (duplicate) return error.textContent = 'Ya existe un aspirante con esa cédula.';

  const base = id ? state.aspirants.find(item => item.id === id) : buildAspirantFromUser({ names, lastnames, cedula, email, role: 'aspirante' });
  base.names = names;
  base.lastnames = lastnames;
  base.cedula = cedula;
  base.email = email;
  base.phone = normalize($('#aspPhone').value);
  base.birthDate = normalize($('#aspBirthDate').value);
  base.club = normalize($('#aspClub').value);
  base.style = normalize($('#aspStyle').value);
  base.currentGrade = normalize($('#aspCurrentGrade').value);
  base.requestedGrade = normalize($('#aspRequestedGrade').value);
  base.prevGradeDate = normalize($('#aspPrevGradeDate').value);
  base.consecutiveLicenses = Number($('#aspCons').value || 0);
  base.alternateLicenses = Number($('#aspAlt').value || 0);
  base.practiceYearsSinceFirstDan = Number($('#aspPractice').value || 0);
  base.coachEndorsement = normalize($('#aspCoach').value);
  base.status = normalize($('#aspStatus').value);
  base.observations = normalize($('#aspObs').value);
  if (!id) state.aspirants.push(base);
  saveState(state);
  toast('Aspirante guardado correctamente.');
  closeModal();
  renderSection('aspirantes');
}

function openReadOnlyAspirant(aspirantId) {
  const aspirant = loadState().aspirants.find(item => item.id === aspirantId);
  if (!aspirant) return;
  openModal('Ficha del aspirante', `
    <section class="card">
      ${kv('Nombre', `${aspirant.names} ${aspirant.lastnames}`)}
      ${kv('Cédula', aspirant.cedula)}
      ${kv('Correo', aspirant.email)}
      ${kv('Club', aspirant.club || '—')}
      ${kv('Estilo', aspirant.style || '—')}
      ${kv('Grado actual', aspirant.currentGrade)}
      ${kv('Grado solicitado', aspirant.requestedGrade)}
      ${kv('Estado', aspirant.status)}
      ${kv('Documentación', aspirant.docStatus)}
      ${kv('Cuota', aspirant.feeStatus)}
      ${kv('Observaciones', aspirant.observations || '—')}
    </section>`);
}

function kv(label, value) {
  return `<div class="kv"><strong>${escapeHtml(label)}</strong><span>${escapeHtml(value)}</span></div>`;
}

function saveAspirantUploads() {
  const state = loadState();
  const aspirantId = $('#saveUploadsBtn')?.dataset.aspirant;
  const aspirant = state.aspirants.find(item => item.id === aspirantId);
  if (!aspirant) return;
  aspirant.uploads ||= {};
  let changed = false;
  $$('[data-upload-doc]').forEach(input => {
    const label = input.dataset.uploadDoc;
    const file = input.files && input.files[0];
    if (file) {
      aspirant.uploads[label] = {
        fileName: file.name,
        uploadedAt: new Date().toLocaleString('es-ES')
      };
      aspirant.documents ||= {};
      aspirant.documents[label] ||= { status: 'Pendiente', note: '' };
      aspirant.documents[label].status = 'Pendiente';
      changed = true;
    }
  });
  if (!changed) return toast('Selecciona al menos un archivo para enviar.');
  aspirant.docStatus = 'En revisión';
  addNotification(state, {
    role: 'admin',
    title: 'Documentos enviados',
    message: `${aspirant.names} ${aspirant.lastnames} envió documentos para revisión.`,
    type: 'documentacion'
  });
  addNotification(state, {
    userId: aspirant.userId,
    title: 'Documentos enviados',
    message: 'Tus documentos fueron enviados. El administrador debe revisarlos.',
    type: 'documentacion'
  });
  saveState(state);
  toast('Documentos enviados correctamente.');
  renderSection('documentacion');
}

function saveDocumentsForSelected() {
  const state = loadState();
  const aspirantId = $('#saveDocumentsBtn').dataset.aspirant;
  const aspirant = state.aspirants.find(item => item.id === aspirantId);
  if (!aspirant) return;
  documentChecklist.forEach(label => {
    const status = $(`[data-doc-status="${cssEscape(label)}"]`)?.value || 'Pendiente';
    const note = $(`[data-doc-note="${cssEscape(label)}"]`)?.value || '';
    aspirant.documents ||= {};
    aspirant.documents[label] = { status, note };
  });
  const values = Object.values(aspirant.documents || {});
  aspirant.docStatus = values.length && values.every(item => item.status === 'Completa') ? 'Completa' : 'Incompleta';
  if (aspirant.userId) {
    addNotification(state, {
      userId: aspirant.userId,
      title: 'Documentación revisada',
      message: `Tu documentación quedó en estado: ${aspirant.docStatus}.`,
      type: 'documentacion'
    });
  }
  saveState(state);
  toast('Revisión documental guardada.');
  renderSection('documentacion');
}

function setAspirantAdmission(aspirantId, status) {
  const state = loadState();
  const aspirant = state.aspirants.find(item => item.id === aspirantId);
  if (!aspirant) return;
  aspirant.status = status;
  if (aspirant.userId) {
    addNotification(state, {
      userId: aspirant.userId,
      title: status === 'Admitido' ? 'Solicitud admitida' : 'Solicitud no admitida',
      message: status === 'Admitido' ? 'Tu expediente fue admitido para examen.' : 'Tu expediente no fue admitido. Revisa las observaciones de documentación.',
      type: 'admision'
    });
  }
  saveState(state);
  toast(`Aspirante marcado como ${status}.`);
  renderSection('documentacion');
}

function cssEscape(text) {
  return String(text).replace(/"/g, '\\"');
}

function payFeeAsAspirant() {
  const state = loadState();
  const aspirantId = $('#payFeeBtn')?.dataset.aspirant;
  const aspirant = state.aspirants.find(item => item.id === aspirantId);
  if (!aspirant) return;
  aspirant.feeStatus = 'Pagada';
  aspirant.feeReason = `Cuota registrada el ${new Date().toLocaleString('es-ES')}`;
  addNotification(state, { role: 'admin', title: 'Cuota registrada', message: `${aspirant.names} ${aspirant.lastnames} registró su cuota.`, type: 'cuota' });
  addNotification(state, { userId: aspirant.userId, title: 'Cuota registrada', message: 'Tu cuota fue registrada correctamente.', type: 'cuota' });
  saveState(state);
  toast('Cuota registrada.');
  renderSection('cuotas');
}

function requestFeeExemption() {
  const state = loadState();
  const aspirantId = $('#requestExemptionBtn')?.dataset.aspirant;
  const aspirant = state.aspirants.find(item => item.id === aspirantId);
  if (!aspirant) return;
  aspirant.feeStatus = 'Pendiente';
  aspirant.feeReason = 'Solicitud de exención enviada por aspirante';
  addNotification(state, { role: 'admin', title: 'Solicitud de exención', message: `${aspirant.names} ${aspirant.lastnames} solicitó revisión de exención de cuota.`, type: 'cuota' });
  addNotification(state, { userId: aspirant.userId, title: 'Solicitud enviada', message: 'Tu solicitud de exención de cuota fue enviada al administrador.', type: 'cuota' });
  saveState(state);
  toast('Solicitud de exención enviada.');
  renderSection('cuotas');
}

function openFeeModal(aspirantId) {
  const aspirant = loadState().aspirants.find(item => item.id === aspirantId);
  if (!aspirant) return;
  openModal('Actualizar cuota de examen', `
    <form id="feeForm" class="form-grid one">
      <input type="hidden" id="feeAspirantId" value="${aspirant.id}" />
      <div class="field"><label>Aspirante</label><input value="${escapeHtml(aspirant.names)} ${escapeHtml(aspirant.lastnames)}" disabled /></div>
      <div class="field"><label>Estado de cuota</label><select id="feeStatus"><option ${aspirant.feeStatus === 'Pendiente' ? 'selected' : ''}>Pendiente</option><option ${aspirant.feeStatus === 'Pagada' ? 'selected' : ''}>Pagada</option><option ${aspirant.feeStatus === 'Exenta' ? 'selected' : ''}>Exenta</option><option ${aspirant.feeStatus === 'Reducción 50%' ? 'selected' : ''}>Reducción 50%</option></select></div>
      <div class="field"><label>Motivo</label><input id="feeReason" value="${escapeHtml(aspirant.feeReason || '')}" placeholder="Ejemplo: Campeón de Madrid" /></div>
      <button class="btn btn-primary btn-block" type="submit">Guardar cuota</button>
    </form>`);
  $('#feeForm')?.addEventListener('submit', saveFeeFromModal);
}

function saveFeeFromModal(event) {
  event.preventDefault();
  const state = loadState();
  const aspirant = state.aspirants.find(item => item.id === $('#feeAspirantId').value);
  if (!aspirant) return;
  aspirant.feeStatus = $('#feeStatus').value;
  aspirant.feeReason = normalize($('#feeReason').value);
  if (aspirant.userId) {
    addNotification(state, {
      userId: aspirant.userId,
      title: 'Cuota actualizada',
      message: `Tu cuota de examen quedó en estado: ${aspirant.feeStatus}.`,
      type: 'cuota'
    });
  }
  saveState(state);
  toast('Cuota actualizada.');
  closeModal();
  renderSection('cuotas');
}

function openCallModal() {
  openModal('Crear convocatoria', `
    <form id="callForm" class="form-grid">
      <div class="field"><label>Nombre</label><input id="callName" /></div>
      <div class="field"><label>Fecha</label><input id="callDate" type="date" /></div>
      <div class="field"><label>Lugar</label><input id="callPlace" /></div>
      <div class="field"><label>Tipo</label><input id="callType" placeholder="Examen ordinario" /></div>
      <div class="field"><label>Estado</label><select id="callStatus"><option>Abierta</option><option>Cerrada</option><option>Finalizada</option></select></div>
      <div class="field full"><label>Observaciones</label><textarea id="callNote"></textarea></div>
      <button class="btn btn-primary btn-block field full" type="submit">Guardar convocatoria</button>
    </form>`);
  $('#callForm')?.addEventListener('submit', saveCallFromModal);
}

function saveCallFromModal(event) {
  event.preventDefault();
  const state = loadState();
  const name = normalize($('#callName').value);
  const date = normalize($('#callDate').value);
  if (!name || !date) return toast('Completa nombre y fecha de la convocatoria.');
  state.calls.push({ id: uid(), name, date, place: normalize($('#callPlace').value), type: normalize($('#callType').value), status: $('#callStatus').value, note: normalize($('#callNote').value), aspirantIds: [] });
  addNotification(state, { role: 'juez', title: 'Nueva convocatoria', message: `Se registró la convocatoria ${name} para el ${date}.`, type: 'convocatoria' });
  saveState(state);
  toast('Convocatoria creada correctamente. Ahora puedes asignar aspirantes.');
  closeModal();
  renderSection('convocatorias');
}

function openAssignCallModal(callId) {
  const state = loadState();
  const call = state.calls.find(item => item.id === callId);
  if (!call) return;
  const aspirants = [...state.aspirants].sort((a, b) => {
    const aReady = aspirantReadiness(a).ready ? 0 : 1;
    const bReady = aspirantReadiness(b).ready ? 0 : 1;
    return aReady - bReady || `${a.lastnames} ${a.names}`.localeCompare(`${b.lastnames} ${b.names}`);
  });
  openModal('Asignar aspirantes a convocatoria', `
    <form id="assignCallForm" class="form-grid one">
      <input type="hidden" id="assignCallId" value="${call.id}" />
      <div class="field"><label>Convocatoria</label><input disabled value="${escapeHtml(call.name)} · ${escapeHtml(call.date)}" /></div>
      <div class="notice-box">
        Puedes convocar al aspirante aunque falte un requisito. Esa alerta quedará visible para administración y el estudiante recibirá la notificación de fecha.
      </div>
      <div class="field"><label>Aspirantes registrados</label>
        <div class="check-list">
          ${aspirants.length ? aspirants.map(asp => {
            const readiness = aspirantReadiness(asp);
            return `<label class="check-row call-check-row">
              <input type="checkbox" data-call-aspirant="${asp.id}" ${(call.aspirantIds || []).includes(asp.id) ? 'checked' : ''}/>
              <span><strong>${escapeHtml(asp.names)} ${escapeHtml(asp.lastnames)}</strong><br><span class="muted">${escapeHtml(asp.requestedGrade)} · ${escapeHtml(asp.style || 'Sin estilo')}</span></span>
              <span>${readiness.ready ? '<span class="badge green">Listo</span>' : `<span class="badge orange">${escapeHtml(readiness.label)}</span>`}</span>
            </label>`;
          }).join('') : '<div class="empty">No hay aspirantes registrados para asignar.</div>'}
        </div>
      </div>
      <button class="btn btn-primary btn-block" type="submit">Guardar convocatoria y notificar</button>
    </form>`);
  $('#assignCallForm')?.addEventListener('submit', saveAssignedCall);
}

function saveAssignedCall(event) {
  event.preventDefault();
  const state = loadState();
  const call = state.calls.find(item => item.id === $('#assignCallId').value);
  if (!call) return;
  const previousIds = new Set(call.aspirantIds || []);
  call.aspirantIds = $$('[data-call-aspirant]').filter(input => input.checked).map(input => input.dataset.callAspirant);
  const currentIds = new Set(call.aspirantIds);
  call.aspirantIds.filter(aspirantId => !previousIds.has(aspirantId)).forEach(aspirantId => {
    const aspirant = state.aspirants.find(item => item.id === aspirantId);
    if (aspirant?.userId) {
      addNotification(state, { userId: aspirant.userId, title: 'Examen asignado', message: `Tu examen fue asignado para el ${call.date} en ${call.place || 'lugar por confirmar'}.`, type: 'convocatoria' });
    }
  });
  [...previousIds].filter(aspirantId => !currentIds.has(aspirantId)).forEach(aspirantId => {
    const aspirant = state.aspirants.find(item => item.id === aspirantId);
    if (aspirant?.userId) {
      addNotification(state, { userId: aspirant.userId, title: 'Convocatoria actualizada', message: `Tu asignación a ${call.name} fue retirada o será reprogramada por administración.`, type: 'convocatoria' });
    }
  });
  addNotification(state, { role: 'juez', title: 'Convocatoria actualizada', message: `${call.name} tiene ${call.aspirantIds.length} aspirante(s) asignado(s).`, type: 'convocatoria' });
  saveState(state);
  toast('Convocatoria guardada y notificaciones enviadas.');
  closeModal();
  renderSection('convocatorias');
}

function openTakeExamModal(callId) {
  const state = loadState();
  const aspirant = getOwnAspirant();
  const call = state.calls.find(item => item.id === callId);
  if (!aspirant || !call) return;
  const alreadySent = aspirant.examSubmission?.callId === callId;
  openModal('Dar examen teórico', `
    <form id="takeExamForm" class="form-grid one">
      <input type="hidden" id="examCallId" value="${call.id}" />
      <p class="helper">Convocatoria: <strong>${escapeHtml(call.name)}</strong> · Fecha: <strong>${escapeHtml(call.date)}</strong></p>
      ${alreadySent ? `<div class="badge green">Ya enviaste este examen el ${escapeHtml(aspirant.examSubmission.sentAt)}</div>` : ''}
      <div class="field"><label>1. ¿Qué significa Karate?</label><textarea id="examQ1" ${alreadySent ? 'disabled' : ''}>${escapeHtml(aspirant.examSubmission?.answers?.q1 || '')}</textarea></div>
      <div class="field"><label>2. ¿Qué significa Rei?</label><textarea id="examQ2" ${alreadySent ? 'disabled' : ''}>${escapeHtml(aspirant.examSubmission?.answers?.q2 || '')}</textarea></div>
      <div class="field"><label>3. ¿Qué es Kata?</label><textarea id="examQ3" ${alreadySent ? 'disabled' : ''}>${escapeHtml(aspirant.examSubmission?.answers?.q3 || '')}</textarea></div>
      <div class="field"><label>4. ¿Qué es Kumite?</label><textarea id="examQ4" ${alreadySent ? 'disabled' : ''}>${escapeHtml(aspirant.examSubmission?.answers?.q4 || '')}</textarea></div>
      <div class="field"><label>5. Observación o comentario final</label><textarea id="examQ5" ${alreadySent ? 'disabled' : ''}>${escapeHtml(aspirant.examSubmission?.answers?.q5 || '')}</textarea></div>
      ${alreadySent ? '' : '<button class="btn btn-primary btn-block" type="submit">Enviar examen</button>'}
    </form>`);
  $('#takeExamForm')?.addEventListener('submit', saveTakeExam);
}

function saveTakeExam(event) {
  event.preventDefault();
  const state = loadState();
  const user = currentUser();
  const aspirant = state.aspirants.find(item => item.userId === user.id);
  if (!aspirant) return;
  const callId = $('#examCallId').value;
  aspirant.examSubmission = {
    callId,
    sentAt: new Date().toLocaleString('es-ES'),
    answers: {
      q1: normalize($('#examQ1').value),
      q2: normalize($('#examQ2').value),
      q3: normalize($('#examQ3').value),
      q4: normalize($('#examQ4').value),
      q5: normalize($('#examQ5').value)
    }
  };
  addNotification(state, { role: 'juez', title: 'Examen enviado', message: `${aspirant.names} ${aspirant.lastnames} envió su examen teórico.`, type: 'examen' });
  addNotification(state, { role: 'admin', title: 'Examen enviado', message: `${aspirant.names} ${aspirant.lastnames} envió su examen teórico.`, type: 'examen' });
  saveState(state);
  toast('Examen enviado correctamente.');
  closeModal();
  renderSection('convocatorias');
}

function openTribunalModal() {
  openModal('Crear tribunal', `
    <form id="tribunalForm" class="form-grid">
      <div class="field"><label>Nombre del tribunal</label><input id="tribName" /></div>
      <div class="field"><label>Fecha</label><input id="tribDate" type="date" /></div>
      <div class="field"><label>Jueces asignados</label><input id="tribJudges" placeholder="Ejemplo: 3 jueces" /></div>
      <div class="field"><label>Director responsable</label><input id="tribDirector" /></div>
      <div class="field full"><label>Árbitros auxiliares</label><input id="tribAux" /></div>
      <div class="field full"><label>Observaciones</label><textarea id="tribNote"></textarea></div>
      <button class="btn btn-primary btn-block field full" type="submit">Guardar tribunal</button>
    </form>`);
  $('#tribunalForm')?.addEventListener('submit', saveTribunalFromModal);
}

function saveTribunalFromModal(event) {
  event.preventDefault();
  const state = loadState();
  const judges = normalize($('#tribJudges').value);
  const match = judges.match(/\d+/);
  if (match && Number(match[0]) % 2 === 0) toast('Advertencia: se recomienda un número impar de jueces.');
  const tribunalName = normalize($('#tribName').value);
  const tribunalDate = normalize($('#tribDate').value);
  state.tribunals.push({ id: uid(), name: tribunalName, date: tribunalDate, judges, director: normalize($('#tribDirector').value), aux: normalize($('#tribAux').value), note: normalize($('#tribNote').value) });
  addNotification(state, { role: 'juez', title: 'Tribunal registrado', message: `Se registró el tribunal ${tribunalName || 'sin nombre'} para el ${tribunalDate || 'día indicado'}.`, type: 'tribunal' });
  saveState(state);
  toast('Tribunal registrado correctamente.');
  closeModal();
  renderSection('tribunales');
}

function openEvaluationModal(aspirantId) {
  const state = loadState();
  const aspirant = state.aspirants.find(item => item.id === aspirantId);
  if (!aspirant) return;
  const exam = aspirant.examSubmission;
  const examBox = exam ? `<section class="card"><span class="eyebrow">Examen teórico enviado</span>${kv('Fecha de envío', exam.sentAt)}${kv('Pregunta 1', exam.answers?.q1 || '—')}${kv('Pregunta 2', exam.answers?.q2 || '—')}${kv('Pregunta 3', exam.answers?.q3 || '—')}${kv('Pregunta 4', exam.answers?.q4 || '—')}${kv('Comentario', exam.answers?.q5 || '—')}</section>` : `<section class="card"><span class="eyebrow">Examen teórico</span><p class="muted">El aspirante todavía no ha enviado el examen teórico.</p></section>`;
  openModal('Registrar evaluación', `
    ${examBox}
    <form id="evaluationForm" class="form-grid one" style="margin-top:16px">
      <input type="hidden" id="evAspirantId" value="${aspirant.id}" />
      <div class="field"><label>Aspirante</label><input disabled value="${escapeHtml(aspirant.names)} ${escapeHtml(aspirant.lastnames)} · ${escapeHtml(aspirant.requestedGrade)}" /></div>
      <div class="field"><label>Resultado bloque común</label><select id="evCommon"><option>Apto</option><option>No apto</option></select></div>
      <div class="field"><label>Vía / bloque específico</label><select id="evSpecific"><option>Apto</option><option>No apto</option><option>Pendiente</option></select></div>
      <div class="field"><label>Resultado final</label><select id="evFinal"><option>Apto</option><option>No apto</option><option>Pendiente</option></select></div>
      <div class="field"><label>Convocatoria</label><input id="evCall" /></div>
      <div class="field"><label>Tribunal</label><input id="evTribunal" /></div>
      <div class="field full"><label>Observaciones</label><textarea id="evNote"></textarea></div>
      <button class="btn btn-primary btn-block" type="submit">Guardar evaluación</button>
    </form>`);
  $('#evaluationForm')?.addEventListener('submit', saveEvaluationFromModal);
}

function saveEvaluationFromModal(event) {
  event.preventDefault();
  const state = loadState();
  const aspirant = state.aspirants.find(item => item.id === $('#evAspirantId').value);
  if (!aspirant) return;
  const evaluation = {
    id: uid(),
    aspirantId: aspirant.id,
    userId: aspirant.userId || '',
    fullName: `${aspirant.names} ${aspirant.lastnames}`,
    requestedGrade: aspirant.requestedGrade,
    commonBlock: $('#evCommon').value,
    specificBlock: $('#evSpecific').value,
    finalResult: $('#evFinal').value,
    call: normalize($('#evCall').value),
    tribunal: normalize($('#evTribunal').value),
    note: normalize($('#evNote').value),
    date: today()
  };
  state.evaluations = state.evaluations.filter(item => item.aspirantId !== aspirant.id);
  state.evaluations.push(evaluation);
  aspirant.status = evaluation.finalResult === 'Apto' ? 'Admitido' : evaluation.finalResult === 'No apto' ? 'No admitido' : 'En revisión';
  if (aspirant.userId) {
    addNotification(state, {
      userId: aspirant.userId,
      title: 'Resultado registrado',
      message: `Tu resultado final fue registrado como: ${evaluation.finalResult}.`,
      type: 'resultado'
    });
  }
  addNotification(state, { role: 'admin', title: 'Evaluación registrada', message: `${evaluation.fullName} tiene resultado final: ${evaluation.finalResult}.`, type: 'evaluacion' });
  saveState(state);
  toast('Evaluación registrada.');
  closeModal();
  renderSection('actas');
}

function openRecordModal(recordId) {
  const record = loadState().evaluations.find(item => item.id === recordId);
  if (!record) return;
  openModal('Acta del resultado', `
    <div class="print-sheet" id="printArea">
      <h3>FMK Grados</h3>
      <p><strong>Resultado generado por el sistema. No sustituye el acta oficial federativa.</strong></p>
      ${kv('Aspirante', record.fullName)}
      ${kv('Grado solicitado', record.requestedGrade)}
      ${kv('Convocatoria', record.call || '—')}
      ${kv('Tribunal', record.tribunal || '—')}
      ${kv('Bloque común', record.commonBlock)}
      ${kv('Bloque específico', record.specificBlock)}
      ${kv('Resultado final', record.finalResult)}
      ${kv('Observaciones', record.note || '—')}
      ${kv('Fecha', record.date)}
      <div class="btn-row no-print"><button class="btn btn-primary" type="button" id="printRecordBtn">Imprimir acta</button></div>
    </div>`);
  $('#printRecordBtn')?.addEventListener('click', () => window.print());
}

function openSpecialModal(aspirantId) {
  const aspirant = loadState().aspirants.find(item => item.id === aspirantId);
  if (!aspirant) return;
  openModal('Actualizar situación especial', `
    <form id="specialForm" class="form-grid one">
      <input type="hidden" id="specialId" value="${aspirant.id}" />
      <div class="field"><label>Situación especial</label><select id="specialType"><option ${aspirant.specialSituation === 'Ninguna' ? 'selected' : ''}>Ninguna</option><option ${aspirant.specialSituation === 'Dispensa médica' ? 'selected' : ''}>Dispensa médica</option><option ${aspirant.specialSituation === 'Convalidación' ? 'selected' : ''}>Convalidación</option><option ${aspirant.specialSituation === 'Campeón / mérito' ? 'selected' : ''}>Campeón / mérito</option><option ${aspirant.specialSituation === 'Reconocimiento de méritos' ? 'selected' : ''}>Reconocimiento de méritos</option></select></div>
      <div class="field"><label>Observación</label><textarea id="specialObs">${escapeHtml(aspirant.observations || '')}</textarea></div>
      <button class="btn btn-primary btn-block" type="submit">Guardar</button>
    </form>`);
  $('#specialForm')?.addEventListener('submit', saveSpecialFromModal);
}

function saveSpecialFromModal(event) {
  event.preventDefault();
  const state = loadState();
  const aspirant = state.aspirants.find(item => item.id === $('#specialId').value);
  if (!aspirant) return;
  aspirant.specialSituation = $('#specialType').value;
  aspirant.observations = normalize($('#specialObs').value);
  saveState(state);
  toast('Situación especial actualizada.');
  closeModal();
  renderSection('especiales');
}

function openChangePasswordModal() {
  openModal('Cambiar contraseña', `
    <form id="changePasswordForm" class="form-grid one">
      <div class="field"><label>Nueva contraseña</label><div class="password-wrap"><input id="newPassword" type="password" /><button type="button" class="eye-btn">👁</button></div></div>
      <div class="field"><label>Confirmar nueva contraseña</label><div class="password-wrap"><input id="newPasswordConfirm" type="password" /><button type="button" class="eye-btn">👁</button></div></div>
      <p id="passwordError" class="form-error"></p>
      <button class="btn btn-primary btn-block" type="submit">Actualizar contraseña</button>
    </form>`);
  $$('.eye-btn', $('#modalRoot')).forEach(btn => btn.addEventListener('click', () => togglePassword(btn)));
  $('#changePasswordForm')?.addEventListener('submit', savePasswordFromModal);
}

function savePasswordFromModal(event) {
  event.preventDefault();
  const pass = normalize($('#newPassword').value);
  const confirm = normalize($('#newPasswordConfirm').value);
  const error = $('#passwordError');
  error.textContent = '';
  if (pass.length < 6) return error.textContent = 'La contraseña debe tener mínimo 6 caracteres.';
  if (pass !== confirm) return error.textContent = 'Las contraseñas no coinciden.';
  const state = loadState();
  const user = state.users.find(item => item.id === currentUser().id);
  if (!user) return;
  user.password = hashPassword(pass);
  saveState(state);
  toast('Contraseña actualizada correctamente.');
  closeModal();
}

function resetSystem() {
  const ok = window.confirm('Esto borrará los datos registrados del sistema. ¿Continuar?');
  if (!ok) return;
  localStorage.removeItem(STORE_KEY);
  localStorage.removeItem(SESSION_KEY);
  sessionStorage.removeItem(SESSION_KEY);
  toast('Sistema restablecido.');
  setTimeout(() => renderAuth('login'), 200);
}

function bindGlobalActions() {
  $('#logoutBtn').addEventListener('click', () => {
    clearSession();
    toast('Sesión cerrada.');
    renderAuth('login');
  });
  $('#brandButton').addEventListener('click', () => {
    activeSection = 'dashboard';
    renderSidebar();
    renderSection(activeSection);
  });
  $('#mobileMenuBtn').addEventListener('click', () => document.body.classList.toggle('menu-open'));
}

document.addEventListener('DOMContentLoaded', () => {
  try {
    bindGlobalActions();
    currentUser() ? renderApp() : renderAuth('login');
  } catch (error) {
    console.error('No se pudo iniciar la aplicación:', error);
    clearSession();
    renderAuth('login');
    toast('La sesión anterior no pudo cargarse. Inicia sesión nuevamente.');
  }
});
