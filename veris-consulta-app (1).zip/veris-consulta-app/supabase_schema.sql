-- =====================================================================
-- VERIS CONSULTA — Esquema de base de datos para Supabase
-- Ejecutar completo en el SQL Editor de un proyecto NUEVO y limpio
-- =====================================================================

create extension if not exists "uuid-ossp";

-- ---------------------------------------------------------------------
-- PERFILES (uno por cada usuario de auth.users)
-- ---------------------------------------------------------------------
create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  name text not null,
  email text not null,
  role text not null check (role in ('paciente','medico','administrador')),
  active boolean not null default true,
  created_at timestamptz not null default now()
);

-- ---------------------------------------------------------------------
-- MÉDICOS (catálogo; profile_id es null para médicos sembrados a mano)
-- ---------------------------------------------------------------------
create table doctors (
  id uuid primary key default uuid_generate_v4(),
  profile_id uuid references profiles(id) on delete set null,
  name text not null,
  specialty text not null,
  rate numeric not null default 20,
  verified boolean not null default false,
  availability int[] not null default '{1,1,1,1,1,0,0}',
  created_at timestamptz not null default now()
);

-- ---------------------------------------------------------------------
-- FAMILIARES
-- ---------------------------------------------------------------------
create table family_members (
  id uuid primary key default uuid_generate_v4(),
  owner_id uuid not null references profiles(id) on delete cascade,
  name text not null,
  relation text not null,
  created_at timestamptz not null default now()
);

-- ---------------------------------------------------------------------
-- CITAS
-- ---------------------------------------------------------------------
create table appointments (
  id uuid primary key default uuid_generate_v4(),
  patient_owner_id uuid not null references profiles(id) on delete cascade,
  patient_name text not null,
  doctor_id uuid not null references doctors(id),
  doctor_name text not null,
  specialty text not null,
  date date not null,
  time time not null,
  insurance text,
  payment_method text,
  reason text not null,
  status text not null default 'pending_payment'
    check (status in ('pending_payment','confirmed','approved','completed','rejected','cancelled')),
  amount numeric not null default 0,
  video_call_link text,
  video_call_room_id text,
  created_at timestamptz not null default now()
);

-- ---------------------------------------------------------------------
-- PAGOS
-- ---------------------------------------------------------------------
create table payments (
  id uuid primary key default uuid_generate_v4(),
  appointment_id uuid not null references appointments(id) on delete cascade,
  method text,
  amount numeric not null,
  status text not null default 'completed',
  reference text,
  created_at timestamptz not null default now()
);

-- ---------------------------------------------------------------------
-- DOCUMENTOS CLÍNICOS
-- ---------------------------------------------------------------------
create table medical_records (
  id uuid primary key default uuid_generate_v4(),
  appointment_id uuid not null references appointments(id) on delete cascade,
  patient_owner_id uuid not null references profiles(id) on delete cascade,
  patient_name text not null,
  doctor_id uuid not null references doctors(id),
  doctor_name text not null,
  type text not null check (type in ('prescription','recommendation','certificate')),
  content text not null,
  created_at timestamptz not null default now()
);

-- =====================================================================
-- FUNCIÓN AUXILIAR: rol del usuario autenticado actual
-- =====================================================================
create or replace function current_role_name()
returns text language sql stable as $$
  select role from profiles where id = auth.uid()
$$;

-- =====================================================================
-- ROW LEVEL SECURITY
-- =====================================================================
alter table profiles enable row level security;
alter table doctors enable row level security;
alter table family_members enable row level security;
alter table appointments enable row level security;
alter table payments enable row level security;
alter table medical_records enable row level security;

-- PROFILES: cada quien ve/edita lo suyo; admin ve todo
create policy "profiles_self_select" on profiles for select using (id = auth.uid() or current_role_name() = 'administrador');
create policy "profiles_self_insert" on profiles for insert with check (id = auth.uid());
create policy "profiles_self_update" on profiles for update using (id = auth.uid() or current_role_name() = 'administrador');

-- DOCTORS: catálogo visible para todos los autenticados; solo el propio médico o el admin edita
create policy "doctors_select_all" on doctors for select using (auth.role() = 'authenticated');
create policy "doctors_insert_own" on doctors for insert with check (profile_id = auth.uid() or current_role_name() = 'administrador');
create policy "doctors_update_own_or_admin" on doctors for update using (profile_id = auth.uid() or current_role_name() = 'administrador');

-- FAMILY MEMBERS: solo el dueño
create policy "family_owner_all" on family_members for all using (owner_id = auth.uid()) with check (owner_id = auth.uid());

-- APPOINTMENTS: paciente dueño, médico asignado, o admin
create policy "appt_select" on appointments for select using (
  patient_owner_id = auth.uid()
  or doctor_id in (select id from doctors where profile_id = auth.uid())
  or current_role_name() = 'administrador'
);
create policy "appt_insert_patient" on appointments for insert with check (patient_owner_id = auth.uid());
create policy "appt_update" on appointments for update using (
  patient_owner_id = auth.uid()
  or doctor_id in (select id from doctors where profile_id = auth.uid())
  or current_role_name() = 'administrador'
);

-- PAYMENTS: visibles para el paciente dueño de la cita, su médico, o admin
create policy "pay_select" on payments for select using (
  appointment_id in (select id from appointments where patient_owner_id = auth.uid())
  or appointment_id in (select id from appointments where doctor_id in (select id from doctors where profile_id = auth.uid()))
  or current_role_name() = 'administrador'
);
create policy "pay_insert_patient" on payments for insert with check (
  appointment_id in (select id from appointments where patient_owner_id = auth.uid())
);

-- MEDICAL RECORDS: paciente dueño, médico que lo emitió, o admin
create policy "records_select" on medical_records for select using (
  patient_owner_id = auth.uid()
  or doctor_id in (select id from doctors where profile_id = auth.uid())
  or current_role_name() = 'administrador'
);
create policy "records_insert_doctor" on medical_records for insert with check (
  doctor_id in (select id from doctors where profile_id = auth.uid())
);

-- =====================================================================
-- DATOS SEMILLA: médicos de catálogo (sin cuenta propia todavía)
-- =====================================================================
insert into doctors (name, specialty, rate, verified, availability) values
  ('Dra. Elena Vargas', 'Medicina General', 25, true, '{1,1,1,1,1,0,0}'),
  ('Dr. Carlos Peña',   'Pediatría',        30, true, '{1,0,1,0,1,0,0}'),
  ('Dra. Sofía Reyes',  'Dermatología',     35, true, '{0,1,0,1,0,1,0}'),
  ('Dr. Iván Torres',   'Psicología',       28, false,'{1,1,1,1,1,1,0}');
