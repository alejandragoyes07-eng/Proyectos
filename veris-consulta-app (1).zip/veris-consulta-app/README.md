# Veris Consulta — Documentación del proyecto

Plataforma demo de videoconsultas médicas con acceso diferenciado por rol (Paciente, Médico, Administrador). Funciona completamente en el navegador, sin backend: todo el estado se guarda en `localStorage`.

---

## 1. Alcance de esta versión

Esta es una **demo funcional**, pensada para mostrar el flujo completo de la plataforma sin necesidad de servidor ni base de datos real ni pasarela de pago real. Las videollamadas sí son reales (Jitsi Meet). Sirve para:

- Validar la experiencia de usuario de los 3 roles.
- Probar el flujo de negocio de punta a punta (agendar → pagar → aprobar → consultar → emitir documentos).
- Presentar el producto a interesados antes de invertir en el backend real.

No debe usarse en producción con datos de pacientes reales tal como está: no hay cifrado de datos en reposo, no hay backend que valide nada del lado del servidor, y cualquier persona con acceso al navegador puede ver o alterar los datos guardados en `localStorage`.

---

## 2. Videollamadas reales (Jitsi Meet)

Las videoconsultas son **llamadas de video reales**, no una simulación visual. Se usa el servicio público y gratuito de [Jitsi Meet](https://meet.jit.si) — sin backend, sin API keys, sin costo. Cada cita aprobada genera una sala única (`VerisConsulta-<id de la cita>`) a la que entran paciente y médico desde sus respectivos paneles, con audio, video, chat y compartir pantalla reales.

**Importante:** esto requiere que el sitio se sirva por `http://` o `https://` — no funciona de forma confiable si abres `index.html` con doble clic (protocolo `file://`). Para probarlo localmente usa `npx serve .`, o súbelo directo a Netlify.

## 3. Estructura de archivos

```
veris-consulta-app/
├── index.html          → estructura de la SPA (login/registro + los 3 paneles)
├── styles.css           → sistema visual completo (login y dashboards)
├── app.js                → toda la lógica: auth, routing, y los 3 módulos por rol
└── supabase_schema.sql  → esquema listo para migrar a una base de datos real (opcional)
```

No hay build ni dependencias que instalar. Es HTML/CSS/JS puro; los únicos recursos externos son las tipografías de Google Fonts (Newsreader, Inter, Space Mono), cargadas por CDN.

---

## 4. Cómo correrlo localmente

Al no depender de un servidor, basta con abrir el archivo directamente:

```bash
# Opción 1: abrir directo
open index.html          # macOS
start index.html         # Windows

# Opción 2: servirlo local (recomendado, evita problemas de rutas)
npx serve .
# o
python3 -m http.server 8080
```

---

## 5. Cuentas de acceso

### Cuentas demo (siempre disponibles, cualquier contraseña)
| Rol            | Correo                  |
|----------------|--------------------------|
| Paciente       | `paciente@veris.demo`   |
| Médico         | `medico@veris.demo`     |
| Administrador  | `admin@veris.demo`      |

### Registro manual
Cualquier persona puede crear una cuenta real de **Paciente** o **Médico** desde la pantalla de registro. Los médicos registrados manualmente quedan **sin verificar** hasta que un Administrador los valida desde el panel de Médicos — mientras tanto no aparecen disponibles para agendar.

No existe registro público de Administrador (por diseño); esa cuenta es exclusivamente la demo.

---

## 6. Flujo de negocio

```
PACIENTE                    MÉDICO                      ADMIN
────────                    ──────                      ─────
Buscar médicos
  → filtra por especialidad
  → agenda fecha/hora
  → paga (simulado)
       ↓
  cita en estado "confirmed" ──────→ Pendientes
                                       → aprueba / rechaza
                                            ↓ (al aprobar)
                                       se genera la sala real de videoconsulta
                                       cita pasa a "approved"
  Videoconsulta
  → entra a la sala          Iniciar consulta
                              → entra a la sala
                              → finaliza consulta
                              → emite documento (receta/recomendación/certificado)
                                            ↓
                                       cita pasa a "completed"
  Documentos
  → ve receta/recomendación/certificado

                                                          Panel admin
                                                          → ve métricas globales
                                                          → aprueba, cancela o reasigna
                                                            cualquier cita
                                                          Médicos → valida licencias
                                                          Usuarios → activa/desactiva cuentas
```

### Estados de una cita
| Estado             | Significado                                          |
|---------------------|-------------------------------------------------------|
| `pending_payment`  | Reservada, pago aún no confirmado (estado legado; el flujo actual paga al agendar) |
| `confirmed`        | Pagada, esperando revisión del médico                |
| `approved`         | Aprobada por el médico o admin; sala de videoconsulta generada |
| `completed`        | Consulta finalizada, documentos emitidos             |
| `rejected`         | Rechazada por el médico                              |
| `cancelled`        | Cancelada por el administrador                       |

---

## 7. Funcionalidades por rol

### Paciente
- **Buscar médicos**: galería de especialistas verificados con filtro por especialidad, tarifa y disponibilidad.
- **Agendar y pagar**: modal en 2 pasos (datos de la cita → método de pago).
- **Mis citas**: estado de cada reserva y acceso a la videoconsulta cuando corresponde.
- **Videoconsulta**: llamada de video real (Jitsi Meet) con micrófono, cámara, chat y pantalla compartida.
- **Documentos**: expediente con recetas, recomendaciones y certificados.
- **Mi perfil**: datos de cuenta y gestión del grupo familiar (agendar a nombre de un familiar).

### Médico
- **Pendientes**: citas pagadas a la espera de aprobación.
- **Mi agenda**: consultas aprobadas, ordenadas por fecha.
- **Iniciar consulta**: entra a la sala y finaliza emitiendo un documento clínico.
- **Documentos**: historial de lo emitido + emisión manual.
- **Disponibilidad**: marca los días de atención (filtra su propia visibilidad, informativo en esta versión).

### Administrador
- **Panel admin**: métricas (ingresos, citas por estado, médicos verificados) y gestión centralizada de todas las citas (aprobar, cancelar, reasignar médico).
- **Reportes**: citas por especialidad e ingresos por médico.
- **Usuarios**: activar/desactivar cuentas registradas.
- **Médicos**: validar o retirar la validación de licencias.
- **Ajustes**: reiniciar los datos de la demo.

---

## 8. Cómo desplegarlo en Netlify

1. Descomprime la carpeta del proyecto.
2. En [app.netlify.com](https://app.netlify.com) → **"Add new site" → "Deploy manually"**.
3. Arrastra la carpeta (o su contenido) al recuadro de subida.
4. Netlify entrega una URL pública en segundos. No requiere configuración de build.

Alternativa con Git: conecta el repositorio y define `Build command: (vacío)` y `Publish directory: .`

---

## 9. Migración a producción (siguiente fase)

Esta demo está pensada para evolucionar hacia una arquitectura real. La ruta recomendada:

| Capa               | Elección sugerida                          |
|--------------------|----------------------------------------------|
| Frontend           | Mantener SPA o migrar a React + Vite         |
| Autenticación      | Supabase Auth (o JWT propio)                 |
| Base de datos      | PostgreSQL (Supabase incluye esto)           |
| Videollamadas      | Ya es real con Jitsi Meet; opcional migrar a Zoom Cloud Meeting API si se requiere |
| Pagos              | Stripe / PayPal                              |
| Hosting frontend   | Netlify / Vercel                             |
| Notificaciones     | SendGrid (email), Twilio (SMS)               |

El archivo `supabase_schema.sql` incluido ya define las tablas (`profiles`, `doctors`, `family_members`, `appointments`, `payments`, `medical_records`) con seguridad a nivel de fila (RLS) lista para conectar. El paso pendiente es reescribir `app.js` para que sus funciones llamen a `supabase.auth` y `supabase.from(...)` en vez de `localStorage`.

### Limitaciones conocidas de la demo actual
- Los datos no se comparten entre navegadores ni dispositivos (cada quien tiene su propia copia local).
- No hay validación de contraseña segura (se guarda en texto plano en `localStorage`) — aceptable solo para demo.
- No hay envío real de notificaciones (correo/SMS).

---

## 10. Soporte

Este documento describe el estado del proyecto a julio de 2026. Cualquier cambio de alcance, arquitectura o roadmap debe reflejarse aquí para mantenerlo como fuente de verdad del equipo.
