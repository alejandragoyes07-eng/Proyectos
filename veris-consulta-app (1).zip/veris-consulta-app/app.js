/* =====================================================================
   VERIS CONSULTA — app.js
   Demo funcional sin backend. Todo el estado vive en localStorage.
   ===================================================================== */

/* ---------------------- Claves de almacenamiento ---------------------- */
const K_USERS   = 'veris_users';
const K_SESSION = 'veris_session';
const K_DOCTORS = 'veris_doctors';
const K_FAMILY  = 'veris_family';
const K_APPTS   = 'veris_appointments';
const K_PAYS    = 'veris_payments';
const K_RECORDS = 'veris_records';

const DEMO_ACCOUNTS = {
  paciente: { email:'paciente@veris.demo', name:'Paciente Demo', role:'paciente' },
  medico:   { email:'medico@veris.demo',   name:'Dra. Elena Vargas', role:'medico' },
  admin:    { email:'admin@veris.demo',    name:'Admin Demo',    role:'administrador' }
};

/* ---------------------- Helpers genéricos de storage ---------------------- */
function getData(key, fallback){
  try{ const v = JSON.parse(localStorage.getItem(key)); return v === null || v === undefined ? fallback : v; }
  catch(e){ return fallback; }
}
function setData(key, value){ localStorage.setItem(key, JSON.stringify(value)); }
function uid(prefix){ return prefix + '_' + Math.random().toString(36).slice(2,9); }
function nowISO(){ return new Date().toISOString(); }
function fmtDate(d){
  try{ return new Date(d).toLocaleDateString('es-ES', { day:'2-digit', month:'short', year:'numeric' }); }
  catch(e){ return d; }
}
function money(n){ return '$' + Number(n||0).toFixed(2); }
function hashRating(id){
  let h = 0; for(let i=0;i<id.length;i++) h = (h*31 + id.charCodeAt(i)) % 1000;
  return (4.5 + (h % 5) / 10).toFixed(1); // entre 4.5 y 4.9, estable por doctor
}
function completedCountFor(doctorId){
  return getData(K_APPTS, []).filter(a=>a.doctorId===doctorId && a.status==='completed').length;
}

const STATUS_LABEL = {
  pending_payment:'Pendiente de pago', confirmed:'Confirmada', approved:'Aprobada',
  completed:'Completada', rejected:'Rechazada', cancelled:'Cancelada'
};
const DOC_TYPE_LABEL = { prescription:'Receta', recommendation:'Recomendación', certificate:'Certificado' };
const WEEKDAYS = ['Lun','Mar','Mié','Jue','Vie','Sáb','Dom'];

/* ---------------------- Semilla de datos demo ---------------------- */
function seedIfEmpty(){
  if(getData(K_DOCTORS, null) === null){
    setData(K_DOCTORS, [
      { id:'doc-1', name:'Dra. Elena Vargas', email:'medico@veris.demo', specialty:'Medicina General', rate:25, verified:true, availability:[1,1,1,1,1,0,0] },
      { id:'doc-2', name:'Dr. Carlos Peña',   email:null, specialty:'Pediatría',        rate:30, verified:true, availability:[1,0,1,0,1,0,0] },
      { id:'doc-3', name:'Dra. Sofía Reyes',  email:null, specialty:'Dermatología',     rate:35, verified:true, availability:[0,1,0,1,0,1,0] },
      { id:'doc-4', name:'Dr. Iván Torres',   email:null, specialty:'Psicología',       rate:28, verified:false, availability:[1,1,1,1,1,1,0] }
    ]);
  }
  if(getData(K_USERS, null) === null) setData(K_USERS, []);
  if(getData(K_FAMILY, null) === null) setData(K_FAMILY, []);
  if(getData(K_APPTS, null) === null) setData(K_APPTS, []);
  if(getData(K_PAYS, null) === null) setData(K_PAYS, []);
  if(getData(K_RECORDS, null) === null) setData(K_RECORDS, []);
}

/* ---------------------- Toasts ---------------------- */
function toast(msg, kind){
  const wrap = document.getElementById('toastWrap');
  const el = document.createElement('div');
  el.className = 'toast' + (kind ? ' '+kind : '');
  el.textContent = msg;
  wrap.appendChild(el);
  setTimeout(()=>{ el.remove(); }, 3600);
}

/* ---------------------- Modal ---------------------- */
function openModal(title, bodyHTML){
  document.getElementById('modalTitle').textContent = title;
  document.getElementById('modalBody').innerHTML = bodyHTML;
  document.getElementById('modalOverlay').classList.add('show');
}
function closeModal(){ document.getElementById('modalOverlay').classList.remove('show'); }

/* =====================================================================
   AUTH — login / registro
   ===================================================================== */
function switchTab(tab){
  document.getElementById('loginForm').classList.toggle('active', tab==='login');
  document.getElementById('registerForm').classList.toggle('active', tab==='register');
  document.getElementById('tabLoginBtn').classList.toggle('active', tab==='login');
  document.getElementById('tabRegisterBtn').classList.toggle('active', tab==='register');
  hideBanner();
}
function selectRole(role){
  document.getElementById('rolePatientPill').classList.toggle('selected', role==='paciente');
  document.getElementById('roleDoctorPill').classList.toggle('selected', role==='medico');
  document.getElementById('specialtyField').style.display = role==='medico' ? 'block' : 'none';
}
function toggleEye(inputId){
  const input = document.getElementById(inputId);
  input.type = input.type === 'password' ? 'text' : 'password';
}
function setError(id, msg){
  const el = document.getElementById(id+'Msg');
  const input = document.getElementById(id);
  if(msg){ el.textContent = msg; el.classList.add('show'); if(input) input.classList.add('invalid'); }
  else{ el.textContent=''; el.classList.remove('show'); if(input) input.classList.remove('invalid'); }
}
function isEmail(v){ return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v); }
function showBanner(title, msg){
  document.getElementById('successTitle').textContent = title;
  document.getElementById('successMsg').textContent = msg;
  document.getElementById('successBanner').classList.add('show');
}
function hideBanner(){ document.getElementById('successBanner').classList.remove('show'); }

function handleRegister(e){
  e.preventDefault();
  let ok = true;
  const name = document.getElementById('regName').value.trim();
  const email = document.getElementById('regEmail').value.trim().toLowerCase();
  const pass = document.getElementById('regPass').value;
  const pass2 = document.getElementById('regPass2').value;
  const terms = document.getElementById('regTerms').checked;
  const role = document.querySelector('input[name="regRole"]:checked').value;
  const specialty = document.getElementById('regSpecialty').value;

  setError('regName',''); setError('regEmail',''); setError('regPass',''); setError('regPass2','');
  document.getElementById('regTermsMsg').classList.remove('show');

  const users = getData(K_USERS, []);
  const emailTaken = users.some(u=>u.email===email) || Object.values(DEMO_ACCOUNTS).some(d=>d.email===email);

  if(name.length < 3){ setError('regName','Escribe tu nombre completo.'); ok=false; }
  if(!isEmail(email)){ setError('regEmail','Ese correo no parece válido.'); ok=false; }
  else if(emailTaken){ setError('regEmail','Ese correo ya tiene una cuenta. Inicia sesión en su lugar.'); ok=false; }
  if(pass.length < 6){ setError('regPass','Usa al menos 6 caracteres.'); ok=false; }
  if(pass2 !== pass){ setError('regPass2','Las contraseñas no coinciden.'); ok=false; }
  if(!terms){
    const m = document.getElementById('regTermsMsg');
    m.textContent = 'Debes aceptar los términos para continuar.'; m.classList.add('show'); ok=false;
  }
  if(!ok) return;

  const userId = uid('u');
  users.push({ id:userId, name, email, password:pass, role, active:true, createdAt: nowISO() });
  setData(K_USERS, users);

  if(role === 'medico'){
    const doctors = getData(K_DOCTORS, []);
    doctors.push({ id:uid('doc'), name, email, specialty, rate:20, verified:false, availability:[1,1,1,1,1,0,0] });
    setData(K_DOCTORS, doctors);
  }

  document.getElementById('registerForm').reset();
  selectRole('paciente');
  switchTab('login');
  if(role === 'medico'){
    showBanner('Cuenta creada — pendiente de validación',
      `Un administrador debe validar tu licencia antes de que aparezcas disponible para pacientes. Ya puedes iniciar sesión con ${email}.`);
  } else {
    showBanner('Cuenta creada correctamente', `Ya puedes iniciar sesión como paciente con ${email}.`);
  }
}

function handleLogin(e){
  e.preventDefault();
  let ok = true;
  const email = document.getElementById('loginEmail').value.trim().toLowerCase();
  const pass = document.getElementById('loginPass').value;
  setError('loginEmail',''); setError('loginPass','');

  if(!isEmail(email)){ setError('loginEmail','Ese correo no parece válido.'); ok=false; }
  if(pass.length < 1){ setError('loginPass','Escribe tu contraseña.'); ok=false; }
  if(!ok) return;

  const demo = Object.values(DEMO_ACCOUNTS).find(d=>d.email===email);
  if(demo){ completeLogin({ id:'demo-'+demo.role, name:demo.name, email:demo.email, role:demo.role }); return; }

  const user = getData(K_USERS, []).find(u=>u.email===email);
  if(!user){ setError('loginEmail','No encontramos una cuenta con ese correo.'); return; }
  if(user.password !== pass){ setError('loginPass','La contraseña no coincide.'); return; }
  if(user.active === false){ setError('loginEmail','Esta cuenta está desactivada. Contacta al administrador.'); return; }

  completeLogin(user);
}
function completeLogin(user){
  const roleMap = { paciente:'paciente', medico:'medico', administrador:'administrador' };
  const session = { id:user.id, name:user.name, email:user.email, role: roleMap[user.role] || user.role };
  setData(K_SESSION, session);
  document.getElementById('loginForm').reset();
  renderApp();
}
function logout(){
  localStorage.removeItem(K_SESSION);
  document.getElementById('appView').style.display = 'none';
  document.getElementById('authView').style.display = 'block';
  switchTab('login'); hideBanner();
}

/* =====================================================================
   ROUTER — arma el sidebar y despacha a cada panel
   ===================================================================== */
const NAV_ICONS = {
  home:'<svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M4 11l8-7 8 7M6 9v10h12V9" stroke="currentColor" stroke-width="1.7"/></svg>',
  cal:'<svg width="16" height="16" viewBox="0 0 24 24" fill="none"><rect x="3" y="5" width="18" height="16" rx="2" stroke="currentColor" stroke-width="1.7"/><path d="M3 10h18M8 3v4M16 3v4" stroke="currentColor" stroke-width="1.7"/></svg>',
  video:'<svg width="16" height="16" viewBox="0 0 24 24" fill="none"><rect x="2" y="6" width="14" height="12" rx="2" stroke="currentColor" stroke-width="1.7"/><path d="M16 10l6-3v10l-6-3" stroke="currentColor" stroke-width="1.7"/></svg>',
  doc:'<svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M6 3h9l4 4v14H6z" stroke="currentColor" stroke-width="1.7"/><path d="M9 12h7M9 16h7" stroke="currentColor" stroke-width="1.7"/></svg>',
  user:'<svg width="16" height="16" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="8" r="4" stroke="currentColor" stroke-width="1.7"/><path d="M4 20c1.5-4 5-6 8-6s6.5 2 8 6" stroke="currentColor" stroke-width="1.7"/></svg>',
  inbox:'<svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M3 12h5l2 3h4l2-3h5" stroke="currentColor" stroke-width="1.7"/><path d="M5 5h14l2 7v7H3v-7z" stroke="currentColor" stroke-width="1.7"/></svg>',
  clock:'<svg width="16" height="16" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="1.7"/><path d="M12 7v5l3 3" stroke="currentColor" stroke-width="1.7"/></svg>',
  chart:'<svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M4 20V10M12 20V4M20 20v-7" stroke="currentColor" stroke-width="1.7"/></svg>',
  users:'<svg width="16" height="16" viewBox="0 0 24 24" fill="none"><circle cx="8" cy="8" r="3" stroke="currentColor" stroke-width="1.7"/><circle cx="17" cy="9" r="2.5" stroke="currentColor" stroke-width="1.7"/><path d="M2 20c1-3.5 3.8-5.5 6-5.5s5 2 6 5.5M14 20c.7-2.5 2.4-4 4.3-4.5" stroke="currentColor" stroke-width="1.7"/></svg>',
  stetho:'<svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M6 3v6a4 4 0 008 0V3" stroke="currentColor" stroke-width="1.7"/><circle cx="18" cy="16" r="3" stroke="currentColor" stroke-width="1.7"/><path d="M10 9v3a4 4 0 004 4" stroke="currentColor" stroke-width="1.7"/></svg>',
  gear:'<svg width="16" height="16" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="1.7"/><path d="M19 12a7 7 0 00-.2-1.6l2-1.5-2-3.4-2.3.9a7 7 0 00-2.7-1.6L13.4 2h-2.8l-.4 2.8a7 7 0 00-2.7 1.6l-2.3-.9-2 3.4 2 1.5A7 7 0 005 12c0 .5 0 1.1.2 1.6l-2 1.5 2 3.4 2.3-.9c.8.7 1.7 1.3 2.7 1.6l.4 2.8h2.8l.4-2.8c1-.3 1.9-.9 2.7-1.6l2.3.9 2-3.4-2-1.5c.1-.5.2-1.1.2-1.6z" stroke="currentColor" stroke-width="1.3"/></svg>',
  search:'<svg width="16" height="16" viewBox="0 0 24 24" fill="none"><circle cx="10.5" cy="10.5" r="6.5" stroke="currentColor" stroke-width="1.7"/><path d="M20 20l-4.5-4.5" stroke="currentColor" stroke-width="1.7"/></svg>'
};

const NAV_CONFIG = {
  paciente: [
    { id:'agendar', label:'Buscar médicos', icon:'search' },
    { id:'mis-citas', label:'Mis citas', icon:'clock' },
    { id:'videoconsulta', label:'Videoconsulta', icon:'video' },
    { id:'documentos', label:'Documentos', icon:'doc' },
    { id:'perfil', label:'Mi perfil', icon:'user' }
  ],
  medico: [
    { id:'pendientes', label:'Pendientes', icon:'inbox' },
    { id:'agenda', label:'Mi agenda', icon:'cal' },
    { id:'consulta', label:'Iniciar consulta', icon:'video' },
    { id:'documentos', label:'Documentos', icon:'doc' },
    { id:'disponibilidad', label:'Disponibilidad', icon:'clock' }
  ],
  administrador: [
    { id:'panel', label:'Panel admin', icon:'home' },
    { id:'reportes', label:'Reportes', icon:'chart' },
    { id:'usuarios', label:'Usuarios', icon:'users' },
    { id:'medicos', label:'Médicos', icon:'stetho' },
    { id:'ajustes', label:'Ajustes', icon:'gear' }
  ]
};

let currentView = null;

function renderApp(){
  const session = getData(K_SESSION, null);
  if(!session){ logout(); return; }

  document.getElementById('authView').style.display = 'none';
  document.getElementById('appView').style.display = 'block';

  document.getElementById('userName').textContent = session.name;
  document.getElementById('userMail').textContent = session.email;
  document.getElementById('userAvatar').textContent = session.name.split(' ').map(w=>w[0]).slice(0,2).join('').toUpperCase();
  const roleLabel = { paciente:'Paciente', medico:'Médico', administrador:'Administrador' }[session.role];
  document.getElementById('roleBadge').textContent = roleLabel;
  document.getElementById('roleBadge').className = 'role-badge ' + session.role;
  document.getElementById('sidebarRoleSub').textContent = 'Panel de ' + roleLabel.toLowerCase();

  const nav = NAV_CONFIG[session.role] || [];
  currentView = currentView && nav.some(n=>n.id===currentView) ? currentView : nav[0].id;
  const navEl = document.getElementById('navItems');
  navEl.innerHTML = nav.map(n=>`
    <button class="nav-item ${n.id===currentView?'active':''}" onclick="goTo('${n.id}')">${NAV_ICONS[n.icon]}<span>${n.label}</span></button>
  `).join('');

  dispatchView(session);
}
function goTo(viewId){ currentView = viewId; renderApp(); }

function dispatchView(session){
  const main = document.getElementById('mainContent');
  if(session.role === 'paciente') main.innerHTML = renderPatientView(session, currentView);
  else if(session.role === 'medico') main.innerHTML = renderDoctorView(session, currentView);
  else main.innerHTML = renderAdminView(session, currentView);
}
function refresh(){ renderApp(); }

/* =====================================================================
   PANEL PACIENTE
   ===================================================================== */
function myFamily(session){ return getData(K_FAMILY, []).filter(f=>f.ownerId===session.id); }
function myAppointments(session){ return getData(K_APPTS, []).filter(a=>a.patientOwnerId===session.id).sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt)); }
function verifiedDoctors(){ return getData(K_DOCTORS, []).filter(d=>d.verified); }

function renderPatientView(session, view){
  if(view === 'agendar') return patientBuscarMedicos(session);
  if(view === 'mis-citas') return patientMisCitas(session);
  if(view === 'videoconsulta') return patientVideoconsulta(session);
  if(view === 'documentos') return patientDocumentos(session);
  if(view === 'perfil') return patientPerfil(session);
  return '';
}

function doctorCardHTML(d){
  const completed = completedCountFor(d.id);
  const ratingLine = completed > 0
    ? `⭐ ${hashRating(d.id)} · ${completed} consulta${completed===1?'':'s'} completada${completed===1?'':'s'}`
    : `Nuevo en Veris Consulta`;
  const available = d.availability && d.availability.some(a=>a);
  return `
  <div class="doctor-card">
    <div class="doctor-header">
      <div class="doctor-avatar">${d.name.split(' ').map(w=>w[0]).slice(0,2).join('')}</div>
      <div class="doctor-info">
        <h3>${d.name}</h3>
        <p class="doctor-specialty">${d.specialty}</p>
        <div class="doctor-rating">${ratingLine}</div>
      </div>
    </div>
    <div class="doctor-details">
      <p class="doctor-fee">Consulta: <strong>${money(d.rate)}</strong></p>
      <p class="doctor-availability">${available ? '✅ Con disponibilidad' : '⏸ Sin días configurados'}</p>
    </div>
    <button class="btn-primary small" style="width:100%;" onclick="startAppointmentBooking('${d.id}')">Agendar cita</button>
  </div>`;
}

function patientBuscarMedicos(session){
  const doctors = getData(K_DOCTORS, []).filter(d=>d.verified);
  const specialties = [...new Set(doctors.map(d=>d.specialty))];
  const filterChips = ['Todas', ...specialties].map(s=>
    `<button class="filter-btn ${s==='Todas'?'active':''}" data-spec="${s}" onclick="filterDoctorsBySpecialty('${s}', this)">${s}</button>`).join('');
  const cards = doctors.map(doctorCardHTML).join('') || `<div class="empty-state">Todavía no hay especialistas verificados.</div>`;

  return `
  <div class="main-head"><div><h1>Buscar médicos</h1><p>Encuentra al especialista que necesitas y agenda tu consulta.</p></div></div>
  <div class="section-card" style="margin-bottom:20px;">
    <h2 style="margin-bottom:12px;">Filtrar por especialidad</h2>
    <div class="filter-grid">${filterChips}</div>
  </div>
  <div id="doctorGrid" class="doctor-grid">${cards}</div>`;
}
function filterDoctorsBySpecialty(spec, btn){
  document.querySelectorAll('.filter-btn').forEach(b=>b.classList.remove('active'));
  if(btn) btn.classList.add('active');
  const doctors = getData(K_DOCTORS, []).filter(d=>d.verified && (spec==='Todas' || d.specialty===spec));
  document.getElementById('doctorGrid').innerHTML = doctors.map(doctorCardHTML).join('') || '<div class="empty-state">No hay médicos en esta especialidad.</div>';
}

function startAppointmentBooking(doctorId){
  const session = getData(K_SESSION, null);
  const doctor = getData(K_DOCTORS, []).find(d=>d.id===doctorId);
  const family = myFamily(session);
  const famOptions = [`<option value="__titular">${session.name} (titular)</option>`]
    .concat(family.map(f=>`<option value="${f.id}">${f.name} (${f.relation})</option>`)).join('');
  const today = new Date().toISOString().split('T')[0];
  const slots = ['09:00','10:00','11:00','14:00','15:00','16:00'];

  openModal('Agendar cita con ' + doctor.name, `
    <form onsubmit="submitBookingStep1(event, '${doctorId}')">
      <div class="field"><label>¿Para quién es la consulta?</label><div class="input-wrap"><select class="plain" id="bkPatient">${famOptions}</select></div></div>
      <div class="field"><label>Fecha de consulta</label><div class="input-wrap"><input type="date" class="plain" id="bkDate" min="${today}" required></div></div>
      <div class="field"><label>Hora disponible</label>
        <div class="time-grid">${slots.map(t=>`<button type="button" class="time-btn" onclick="selectTime('${t}', this)">${t}</button>`).join('')}</div>
        <input type="hidden" id="bkTime" required>
      </div>
      <div class="field"><label>Motivo de la consulta</label><div class="input-wrap"><textarea class="plain" id="bkReason" rows="3" placeholder="Ej. Chequeo anual, dolor de cabeza, seguimiento..." required></textarea></div></div>
      <div class="section-card" style="background:var(--bg);margin:0 0 18px;padding:14px 16px;">
        <div class="row-between" style="margin:0 0 6px;"><span class="hint">Médico</span><b>${doctor.name}</b></div>
        <div class="row-between" style="margin:0 0 6px;"><span class="hint">Especialidad</span><b>${doctor.specialty}</b></div>
        <div class="row-between" style="margin:0;"><span class="hint">Total a pagar</span><b style="color:var(--teal-dark);font-size:16px;">${money(doctor.rate)}</b></div>
      </div>
      <div class="inline-actions">
        <button type="button" class="btn-secondary" style="flex:1;" onclick="closeModal()">Cancelar</button>
        <button type="submit" class="btn-primary" style="flex:1;">Continuar a pago</button>
      </div>
    </form>
  `);
}
function selectTime(time, el){
  document.querySelectorAll('.time-btn').forEach(b=>b.classList.remove('selected'));
  el.classList.add('selected');
  document.getElementById('bkTime').value = time;
}
function submitBookingStep1(e, doctorId){
  e.preventDefault();
  const patientSel = document.getElementById('bkPatient').value;
  const date = document.getElementById('bkDate').value;
  const time = document.getElementById('bkTime').value;
  const reason = document.getElementById('bkReason').value.trim();
  if(!date || !time || !reason){ toast('Completa fecha, hora y motivo.', 'err'); return; }

  const session = getData(K_SESSION, null);
  const doctor = getData(K_DOCTORS, []).find(d=>d.id===doctorId);
  const family = myFamily(session);
  const patientName = patientSel === '__titular' ? session.name : (family.find(f=>f.id===patientSel)?.name || session.name);

  openModal('Confirmar pago', `
    <div style="text-align:center;margin-bottom:20px;">
      <div style="font-family:'Newsreader',serif;font-size:28px;font-weight:500;">${money(doctor.rate)}</div>
      <p class="hint" style="margin:2px 0 0;">Consulta con ${doctor.name}</p>
      <p class="hint" style="margin:2px 0 0;">${fmtDate(date)} a las ${time} · Paciente: ${patientName}</p>
    </div>
    <form onsubmit="confirmPayment(event, '${doctorId}', '${patientName.replace(/'/g,"\\'")}', '${date}', '${time}', '${reason.replace(/'/g,"\\'")}')">
      <label class="role-pill" style="display:flex;align-items:center;gap:10px;text-align:left;padding:12px 14px;margin-bottom:10px;cursor:pointer;">
        <input type="radio" name="payMethod" value="Tarjeta de crédito/débito" checked style="display:inline-block;width:auto;"> 💳 Tarjeta de crédito/débito
      </label>
      <label class="role-pill" style="display:flex;align-items:center;gap:10px;text-align:left;padding:12px 14px;margin-bottom:10px;cursor:pointer;">
        <input type="radio" name="payMethod" value="Transferencia bancaria" style="display:inline-block;width:auto;"> 🏦 Transferencia bancaria
      </label>
      <label class="role-pill" style="display:flex;align-items:center;gap:10px;text-align:left;padding:12px 14px;margin-bottom:16px;cursor:pointer;">
        <input type="radio" name="payMethod" value="Efectivo en clínica" style="display:inline-block;width:auto;"> 💵 Efectivo en clínica
      </label>
      <div class="field-msg show" style="color:var(--teal-dark);background:var(--teal-light);padding:10px 12px;border-radius:8px;margin-bottom:16px;">
        Después del pago, el médico revisará tu solicitud y te avisaremos cuando la apruebe.
      </div>
      <div class="inline-actions">
        <button type="button" class="btn-secondary" style="flex:1;" onclick="closeModal()">Cancelar</button>
        <button type="submit" class="btn-primary" style="flex:1;">Pagar ${money(doctor.rate)}</button>
      </div>
    </form>
  `);
}
function confirmPayment(e, doctorId, patientName, date, time, reason){
  e.preventDefault();
  const session = getData(K_SESSION, null);
  const doctor = getData(K_DOCTORS, []).find(d=>d.id===doctorId);
  const method = document.querySelector('input[name="payMethod"]:checked').value;

  const appts = getData(K_APPTS, []);
  const appt = {
    id: uid('ap'), patientOwnerId: session.id, patientName, doctorId, doctorName: doctor.name, specialty: doctor.specialty,
    date, time, insurance:'Particular', paymentMethod: method, reason, status:'confirmed', amount: doctor.rate,
    videoCallLink:null, videoCallRoomId:null, createdAt: nowISO()
  };
  appts.push(appt);
  setData(K_APPTS, appts);

  const pays = getData(K_PAYS, []);
  pays.push({ id:uid('pay'), appointmentId:appt.id, method, amount:doctor.rate, status:'completed', reference:uid('REF').toUpperCase(), createdAt: nowISO() });
  setData(K_PAYS, pays);

  closeModal();
  toast('Pago confirmado. El médico revisará tu solicitud en breve.', 'ok');
  currentView = 'mis-citas';
  renderApp();
}

function addFamily(){
  const session = getData(K_SESSION, null);
  const name = document.getElementById('famName').value.trim();
  const relation = document.getElementById('famRelation').value;
  if(name.length < 2){ toast('Escribe el nombre del familiar.', 'err'); return; }
  const list = getData(K_FAMILY, []);
  list.push({ id:uid('fam'), ownerId:session.id, name, relation });
  setData(K_FAMILY, list);
  toast('Familiar agregado.', 'ok');
  refresh();
}
function removeFamily(id){
  setData(K_FAMILY, getData(K_FAMILY, []).filter(f=>f.id!==id));
  toast('Familiar eliminado.', 'ok');
  refresh();
}

function patientMisCitas(session){
  const appts = myAppointments(session);
  if(!appts.length) return `<div class="main-head"><div><h1>Mis citas</h1><p>Aún no tienes citas reservadas.</p></div></div>
    <div class="section-card"><div class="empty-state">No hay citas todavía. Ve a <b>Buscar médicos</b> para crear la primera.</div></div>`;

  const rows = appts.map(a=>`
    <tr>
      <td><b>${a.patientName}</b><br><span class="hint" style="font-size:11.5px;">${a.reason}</span></td>
      <td>${a.doctorName}<br><span class="hint" style="font-size:11.5px;">${a.specialty}</span></td>
      <td>${fmtDate(a.date)}<br><span class="hint" style="font-size:11.5px;">${a.time}</span></td>
      <td>${money(a.amount)}</td>
      <td><span class="badge ${a.status}">${STATUS_LABEL[a.status]}</span></td>
      <td>${appointmentActionPatient(a)}</td>
    </tr>`).join('');

  return `<div class="main-head"><div><h1>Mis citas</h1><p>Estado de tus reservas y las de tu grupo familiar.</p></div></div>
  <div class="section-card"><div class="table-wrap"><table class="data-table">
    <thead><tr><th>Paciente</th><th>Médico</th><th>Fecha</th><th>Monto</th><th>Estado</th><th></th></tr></thead>
    <tbody>${rows}</tbody>
  </table></div></div>`;
}
function appointmentActionPatient(a){
  if(a.status === 'pending_payment') return `<button class="btn-primary small" onclick="payAppointment('${a.id}')">Pagar ahora</button>`;
  if(a.status === 'confirmed') return `<span class="hint">Esperando aprobación</span>`;
  if(a.status === 'approved') return `<button class="btn-primary small" onclick="openVideoRoom('${a.id}')">Entrar a consulta</button>`;
  if(a.status === 'completed') return `<button class="btn-secondary" onclick="goTo('documentos')">Ver documentos</button>`;
  return `<span class="hint">—</span>`;
}
function payAppointment(id){
  const appts = getData(K_APPTS, []);
  const appt = appts.find(a=>a.id===id);
  if(!appt) return;
  appt.status = 'confirmed';
  setData(K_APPTS, appts);
  const pays = getData(K_PAYS, []);
  pays.push({ id:uid('pay'), appointmentId:id, method:appt.paymentMethod, amount:appt.amount, status:'completed', reference:uid('REF').toUpperCase(), createdAt: nowISO() });
  setData(K_PAYS, pays);
  toast('Pago confirmado. Esperando aprobación del médico.', 'ok');
  refresh();
}

function patientVideoconsulta(session){
  const active = myAppointments(session).filter(a=>a.status==='approved');
  if(!active.length) return `<div class="main-head"><div><h1>Videoconsulta</h1><p>Aquí verás el acceso cuando una cita sea aprobada.</p></div></div>
    <div class="section-card"><div class="empty-state">No tienes videoconsultas listas todavía.</div></div>`;
  const cards = active.map(a=>`
    <div class="section-card">
      <h2>${a.doctorName} — ${a.specialty}</h2>
      <p class="hint">${fmtDate(a.date)} · ${a.time} · Paciente: ${a.patientName}</p>
      <button class="btn-primary small" onclick="openVideoRoom('${a.id}')">Entrar a la sala</button>
    </div>`).join('');
  return `<div class="main-head"><div><h1>Videoconsulta</h1><p>Citas aprobadas listas para conectarse.</p></div></div>${cards}`;
}

function patientDocumentos(session){
  const recs = getData(K_RECORDS, []).filter(r=>r.patientOwnerId===session.id).sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt));
  if(!recs.length) return `<div class="main-head"><div><h1>Documentos</h1><p>Recetas, recomendaciones y certificados aparecerán aquí.</p></div></div>
    <div class="section-card"><div class="empty-state">Todavía no tienes documentos clínicos.</div></div>`;
  const items = recs.map(r=>`
    <div class="doc-item"><div class="doc-top"><span class="doc-type">${DOC_TYPE_LABEL[r.type]}</span><span class="doc-date">${fmtDate(r.createdAt)}</span></div>
    <div class="doc-content">${r.content}</div><p class="hint" style="margin:6px 0 0;">Emitido por ${r.doctorName}</p></div>`).join('');
  return `<div class="main-head"><div><h1>Documentos</h1><p>Tu expediente clínico de Veris Consulta.</p></div></div><div class="section-card">${items}</div>`;
}

function patientPerfil(session){
  const family = myFamily(session);
  return `<div class="main-head"><div><h1>Mi perfil</h1><p>Información de tu cuenta y tu grupo familiar.</p></div></div>
  <div class="two-col">
    <div class="section-card">
      <h2>${session.name}</h2>
      <p class="hint">${session.email}</p>
      <div class="field" style="margin-top:16px;"><label>Rol</label><div class="input-wrap"><input class="plain" value="Paciente" disabled></div></div>
      <p class="hint">Para editar tu correo o contraseña, contacta a soporte en esta demo.</p>
    </div>
    <div class="section-card">
      <h2>Grupo familiar</h2>
      <p class="hint">Agrega familiares para agendar citas a su nombre desde Buscar médicos.</p>
      <div id="famChips">${family.length? family.map(f=>`<span class="fam-chip">${f.name} · ${f.relation} <button onclick="removeFamily('${f.id}')">×</button></span>`).join('') : '<p class="hint" style="margin:0;">Aún no agregas familiares.</p>'}</div>
      <div class="field" style="margin-top:14px;"><label>Nombre del familiar</label><div class="input-wrap"><input type="text" class="plain" id="famName" placeholder="Ej. Pedro Ruiz"></div></div>
      <div class="field"><label>Relación</label><div class="input-wrap"><select class="plain" id="famRelation"><option>Hijo/a</option><option>Cónyuge</option><option>Padre/Madre</option><option>Otro</option></select></div></div>
      <button class="btn-secondary" style="width:100%;" onclick="addFamily()">Agregar familiar</button>
    </div>
  </div>`;
}

/* =====================================================================
   PANEL MÉDICO
   ===================================================================== */
function doctorRecordForSession(session){
  const doctors = getData(K_DOCTORS, []);
  return doctors.find(d=>d.email && d.email===session.email) || doctors.find(d=>d.id==='doc-1');
}
function doctorAppointments(session){
  const doc = doctorRecordForSession(session);
  if(!doc) return [];
  return getData(K_APPTS, []).filter(a=>a.doctorId===doc.id).sort((a,b)=>new Date(a.date+'T'+a.time)-new Date(b.date+'T'+b.time));
}

function renderDoctorView(session, view){
  if(view === 'pendientes') return doctorPendientes(session);
  if(view === 'agenda') return doctorAgenda(session);
  if(view === 'consulta') return doctorConsulta(session);
  if(view === 'documentos') return doctorDocumentos(session);
  if(view === 'disponibilidad') return doctorDisponibilidad(session);
  return '';
}

function doctorPendientes(session){
  const appts = doctorAppointments(session).filter(a=>a.status==='confirmed');
  if(!appts.length) return `<div class="main-head"><div><h1>Pendientes</h1><p>Citas pagadas esperando tu aprobación.</p></div></div>
    <div class="section-card"><div class="empty-state">No tienes citas pendientes de aprobación.</div></div>`;
  const rows = appts.map(a=>`
    <tr><td><b>${a.patientName}</b><br><span class="hint" style="font-size:11.5px;">${a.reason}</span></td>
    <td>${fmtDate(a.date)} · ${a.time}</td><td>${money(a.amount)}</td>
    <td class="inline-actions">
      <button class="btn-primary small" onclick="setApptStatus('${a.id}','approved')">Aprobar</button>
      <button class="btn-danger-ghost" onclick="setApptStatus('${a.id}','rejected')">Rechazar</button>
    </td></tr>`).join('');
  return `<div class="main-head"><div><h1>Pendientes</h1><p>Aprueba o rechaza las citas ya pagadas.</p></div></div>
  <div class="section-card"><div class="table-wrap"><table class="data-table">
  <thead><tr><th>Paciente</th><th>Fecha</th><th>Monto</th><th></th></tr></thead><tbody>${rows}</tbody></table></div></div>`;
}
function setApptStatus(id, status){
  const appts = getData(K_APPTS, []);
  const appt = appts.find(a=>a.id===id);
  if(!appt) return;
  appt.status = status;
  if(status === 'approved'){
    appt.videoCallRoomId = 'VerisConsulta-' + appt.id.replace(/[^a-zA-Z0-9]/g,'');
    appt.videoCallLink = `https://meet.jit.si/${appt.videoCallRoomId}`;
  }
  setData(K_APPTS, appts);
  toast(status==='approved' ? 'Cita aprobada. Enlace de videoconsulta generado.' : 'Cita rechazada.', status==='approved'?'ok':'err');
  refresh();
}

function doctorAgenda(session){
  const appts = doctorAppointments(session).filter(a=>['approved','completed'].includes(a.status));
  if(!appts.length) return `<div class="main-head"><div><h1>Mi agenda</h1><p>Tus próximas consultas aprobadas.</p></div></div>
    <div class="section-card"><div class="empty-state">No tienes consultas agendadas todavía.</div></div>`;
  const rows = appts.map(a=>`
    <tr><td><b>${a.patientName}</b></td><td>${fmtDate(a.date)} · ${a.time}</td>
    <td><span class="badge ${a.status}">${STATUS_LABEL[a.status]}</span></td>
    <td>${a.status==='approved' ? `<button class="btn-primary small" onclick="openVideoRoom('${a.id}')">Iniciar consulta</button>` : '<span class="hint">Finalizada</span>'}</td></tr>`).join('');
  return `<div class="main-head"><div><h1>Mi agenda</h1><p>Consultas aprobadas, ordenadas por fecha.</p></div></div>
  <div class="section-card"><div class="table-wrap"><table class="data-table">
  <thead><tr><th>Paciente</th><th>Fecha</th><th>Estado</th><th></th></tr></thead><tbody>${rows}</tbody></table></div></div>`;
}

function doctorConsulta(session){
  const appts = doctorAppointments(session).filter(a=>a.status==='approved');
  if(!appts.length) return `<div class="main-head"><div><h1>Iniciar consulta</h1><p>Aquí aparecen las citas listas para conectarte.</p></div></div>
    <div class="section-card"><div class="empty-state">No tienes consultas listas para iniciar.</div></div>`;
  const cards = appts.map(a=>`
    <div class="section-card"><h2>${a.patientName}</h2><p class="hint">${fmtDate(a.date)} · ${a.time} · ${a.reason}</p>
    <button class="btn-primary small" onclick="openVideoRoom('${a.id}')">Entrar a la sala</button></div>`).join('');
  return `<div class="main-head"><div><h1>Iniciar consulta</h1><p>Selecciona una cita aprobada para comenzar.</p></div></div>${cards}`;
}

function doctorDocumentos(session){
  const doc = doctorRecordForSession(session);
  const recs = getData(K_RECORDS, []).filter(r=>r.doctorId===doc.id).sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt));
  const completed = doctorAppointments(session).filter(a=>a.status==='completed' || a.status==='approved');
  const apptOptions = completed.map(a=>`<option value="${a.id}">${a.patientName} — ${fmtDate(a.date)}</option>`).join('');

  const items = recs.length ? recs.map(r=>`
    <div class="doc-item"><div class="doc-top"><span class="doc-type">${DOC_TYPE_LABEL[r.type]}</span><span class="doc-date">${fmtDate(r.createdAt)}</span></div>
    <div class="doc-content">${r.content}</div><p class="hint" style="margin:6px 0 0;">Paciente: ${r.patientName}</p></div>`).join('')
    : `<div class="empty-state">Aún no has emitido documentos.</div>`;

  return `<div class="main-head"><div><h1>Documentos</h1><p>Recetas, recomendaciones y certificados que has emitido.</p></div></div>
  <div class="two-col">
    <div class="section-card">${items}</div>
    <div class="section-card">
      <h2>Emitir documento</h2>
      ${apptOptions ? `
      <form onsubmit="submitDocument(event)">
        <div class="field"><label>Cita</label><div class="input-wrap"><select class="plain" id="docAppt" required>${apptOptions}</select></div></div>
        <div class="field"><label>Tipo</label><div class="input-wrap"><select class="plain" id="docType">
          <option value="prescription">Receta</option><option value="recommendation">Recomendación</option><option value="certificate">Certificado</option>
        </select></div></div>
        <div class="field"><label>Contenido</label><div class="input-wrap"><textarea class="plain" id="docContent" rows="4" placeholder="Escribe el detalle del documento" required></textarea></div></div>
        <button class="btn-primary" type="submit">Emitir documento</button>
      </form>` : `<p class="hint">Necesitas una cita aprobada o completada para emitir un documento.</p>`}
    </div>
  </div>`;
}
function submitDocument(e){
  e.preventDefault();
  const session = getData(K_SESSION, null);
  const doc = doctorRecordForSession(session);
  const apptId = document.getElementById('docAppt').value;
  const type = document.getElementById('docType').value;
  const content = document.getElementById('docContent').value.trim();
  if(!content){ toast('Escribe el contenido del documento.', 'err'); return; }
  const appt = getData(K_APPTS, []).find(a=>a.id===apptId);

  const recs = getData(K_RECORDS, []);
  recs.push({ id:uid('rec'), appointmentId:apptId, patientOwnerId:appt.patientOwnerId, patientName:appt.patientName,
    doctorId:doc.id, doctorName:doc.name, type, content, createdAt: nowISO() });
  setData(K_RECORDS, recs);
  toast('Documento emitido.', 'ok');
  refresh();
}

function doctorDisponibilidad(session){
  const doc = doctorRecordForSession(session);
  const avail = doc.availability || [0,0,0,0,0,0,0];
  const days = WEEKDAYS.map((d,i)=>`<div class="avail-day ${avail[i]?'on':''}" onclick="toggleAvail(${i})">${d}</div>`).join('');
  return `<div class="main-head"><div><h1>Disponibilidad</h1><p>Marca los días en que atiendes consultas. Esto filtra tu perfil al momento de reservar.</p></div></div>
  <div class="section-card"><div class="avail-grid">${days}</div>
  <p class="hint" style="margin-top:16px;">Especialidad: <b>${doc.specialty}</b> · Tarifa por consulta: <b>${money(doc.rate)}</b> ${doc.verified?'':'· <span style="color:var(--danger);font-weight:700;">pendiente de validación por el administrador</span>'}</p>
  </div>`;
}
function toggleAvail(i){
  const session = getData(K_SESSION, null);
  const doctors = getData(K_DOCTORS, []);
  const doc = doctors.find(d=>d.id===doctorRecordForSession(session).id);
  doc.availability[i] = doc.availability[i] ? 0 : 1;
  setData(K_DOCTORS, doctors);
  refresh();
}

/* =====================================================================
   PANEL ADMINISTRADOR
   ===================================================================== */
function renderAdminView(session, view){
  if(view === 'panel') return adminPanel();
  if(view === 'reportes') return adminReportes();
  if(view === 'usuarios') return adminUsuarios();
  if(view === 'medicos') return adminMedicos();
  if(view === 'ajustes') return adminAjustes();
  return '';
}

function adminPanel(){
  const appts = getData(K_APPTS, []);
  const pays = getData(K_PAYS, []);
  const doctors = getData(K_DOCTORS, []);
  const users = getData(K_USERS, []);
  const ingresos = pays.reduce((s,p)=>s+Number(p.amount||0),0);

  const metrics = [
    { label:'Citas totales', value: appts.length, sub: appts.filter(a=>a.status==='completed').length + ' completadas' },
    { label:'Pendientes de pago', value: appts.filter(a=>a.status==='pending_payment').length, sub:'sin confirmar' },
    { label:'Por aprobar', value: appts.filter(a=>a.status==='confirmed').length, sub:'pagadas, sin revisar' },
    { label:'Ingresos totales', value: money(ingresos), sub: pays.length + ' pagos' },
    { label:'Médicos verificados', value: doctors.filter(d=>d.verified).length + '/' + doctors.length, sub:'en catálogo' },
    { label:'Usuarios registrados', value: users.length, sub:'pacientes y médicos' }
  ];
  const metricCards = metrics.map(m=>`<div class="metric-card"><div class="m-label">${m.label}</div><div class="m-value">${m.value}</div><div class="m-sub">${m.sub}</div></div>`).join('');

  const rows = appts.slice().sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt)).map(a=>`
    <tr><td><b>${a.patientName}</b></td><td>${a.doctorName}</td><td>${fmtDate(a.date)} · ${a.time}</td>
    <td><span class="badge ${a.status}">${STATUS_LABEL[a.status]}</span></td>
    <td class="inline-actions">
      ${a.status!=='cancelled' && a.status!=='completed' ? `<button class="btn-danger-ghost" onclick="adminCancel('${a.id}')">Cancelar</button>`:''}
      ${a.status==='confirmed' ? `<button class="btn-primary small" onclick="setApptStatus('${a.id}','approved')">Aprobar</button>`:''}
      <button class="btn-secondary" onclick="adminReassign('${a.id}')">Reasignar médico</button>
    </td></tr>`).join('');

  return `<div class="main-head"><div><h1>Panel admin</h1><p>Vista general de la operación de Veris Consulta.</p></div></div>
  <div class="metric-grid">${metricCards}</div>
  <div class="section-card"><h2>Todas las citas</h2><p class="hint">Gestión centralizada: aprobar, cancelar o reasignar médico.</p>
  <div class="table-wrap"><table class="data-table"><thead><tr><th>Paciente</th><th>Médico</th><th>Fecha</th><th>Estado</th><th></th></tr></thead>
  <tbody>${rows || '<tr><td colspan="5" class="empty-state">Sin citas todavía.</td></tr>'}</tbody></table></div></div>`;
}
function adminCancel(id){
  const appts = getData(K_APPTS, []);
  const appt = appts.find(a=>a.id===id);
  appt.status = 'cancelled';
  setData(K_APPTS, appts);
  toast('Cita cancelada.', 'err');
  refresh();
}
function adminReassign(id){
  const doctors = getData(K_DOCTORS, []);
  const options = doctors.map(d=>`<option value="${d.id}">${d.name} — ${d.specialty}</option>`).join('');
  openModal('Reasignar médico', `
    <div class="field"><label>Nuevo médico</label><div class="input-wrap"><select class="plain" id="reassignDoctor">${options}</select></div></div>
    <button class="btn-primary" onclick="confirmReassign('${id}')">Confirmar reasignación</button>
  `);
}
function confirmReassign(apptId){
  const doctorId = document.getElementById('reassignDoctor').value;
  const doctor = getData(K_DOCTORS, []).find(d=>d.id===doctorId);
  const appts = getData(K_APPTS, []);
  const appt = appts.find(a=>a.id===apptId);
  appt.doctorId = doctor.id; appt.doctorName = doctor.name; appt.specialty = doctor.specialty;
  setData(K_APPTS, appts);
  closeModal();
  toast('Médico reasignado.', 'ok');
  refresh();
}

function adminReportes(){
  const appts = getData(K_APPTS, []);
  const pays = getData(K_PAYS, []);
  const bySpecialty = {};
  appts.forEach(a=>{ bySpecialty[a.specialty] = (bySpecialty[a.specialty]||0) + 1; });
  const byDoctor = {};
  pays.forEach(p=>{
    const appt = appts.find(a=>a.id===p.appointmentId);
    if(!appt) return;
    byDoctor[appt.doctorName] = (byDoctor[appt.doctorName]||0) + Number(p.amount||0);
  });
  const specRows = Object.entries(bySpecialty).map(([k,v])=>`<tr><td>${k}</td><td>${v}</td></tr>`).join('') || '<tr><td colspan="2" class="empty-state">Sin datos aún.</td></tr>';
  const docRows = Object.entries(byDoctor).map(([k,v])=>`<tr><td>${k}</td><td>${money(v)}</td></tr>`).join('') || '<tr><td colspan="2" class="empty-state">Sin ingresos aún.</td></tr>';

  return `<div class="main-head"><div><h1>Reportes</h1><p>Resumen de actividad de la plataforma.</p></div></div>
  <div class="two-col">
    <div class="section-card"><h2>Citas por especialidad</h2>
    <div class="table-wrap"><table class="data-table"><thead><tr><th>Especialidad</th><th>Citas</th></tr></thead><tbody>${specRows}</tbody></table></div></div>
    <div class="section-card"><h2>Ingresos por médico</h2>
    <div class="table-wrap"><table class="data-table"><thead><tr><th>Médico</th><th>Ingresos</th></tr></thead><tbody>${docRows}</tbody></table></div></div>
  </div>`;
}

function adminUsuarios(){
  const users = getData(K_USERS, []);
  const rows = users.map(u=>`
    <tr><td><b>${u.name}</b></td><td>${u.email}</td><td>${u.role==='medico'?'Médico':'Paciente'}</td>
    <td><span class="badge ${u.active!==false?'active':'inactive'}">${u.active!==false?'Activo':'Inactivo'}</span></td>
    <td><button class="btn-secondary" onclick="toggleUserActive('${u.id}')">${u.active!==false?'Desactivar':'Activar'}</button></td></tr>`).join('');
  return `<div class="main-head"><div><h1>Usuarios</h1><p>Cuentas registradas manualmente (los accesos demo no aparecen aquí).</p></div></div>
  <div class="section-card"><div class="table-wrap"><table class="data-table">
  <thead><tr><th>Nombre</th><th>Correo</th><th>Rol</th><th>Estado</th><th></th></tr></thead>
  <tbody>${rows || '<tr><td colspan="5" class="empty-state">Nadie se ha registrado todavía.</td></tr>'}</tbody></table></div></div>`;
}
function toggleUserActive(id){
  const users = getData(K_USERS, []);
  const u = users.find(x=>x.id===id);
  u.active = u.active === false ? true : false;
  setData(K_USERS, users);
  toast(u.active ? 'Usuario activado.' : 'Usuario desactivado.', u.active?'ok':'err');
  refresh();
}

function adminMedicos(){
  const doctors = getData(K_DOCTORS, []);
  const rows = doctors.map(d=>`
    <tr><td><b>${d.name}</b>${d.email?`<br><span class="hint" style="font-size:11.5px;">${d.email}</span>`:''}</td>
    <td>${d.specialty}</td><td>${money(d.rate)}</td>
    <td><span class="badge ${d.verified?'verified':'unverified'}">${d.verified?'Verificado':'Sin verificar'}</span></td>
    <td><button class="btn-secondary" onclick="toggleDoctorVerified('${d.id}')">${d.verified?'Retirar validación':'Validar'}</button></td></tr>`).join('');
  return `<div class="main-head"><div><h1>Médicos</h1><p>Valida licencias antes de que aparezcan disponibles para pacientes.</p></div></div>
  <div class="section-card"><div class="table-wrap"><table class="data-table">
  <thead><tr><th>Nombre</th><th>Especialidad</th><th>Tarifa</th><th>Estado</th><th></th></tr></thead>
  <tbody>${rows}</tbody></table></div></div>`;
}
function toggleDoctorVerified(id){
  const doctors = getData(K_DOCTORS, []);
  const d = doctors.find(x=>x.id===id);
  d.verified = !d.verified;
  setData(K_DOCTORS, doctors);
  toast(d.verified ? 'Médico validado.' : 'Validación retirada.', d.verified?'ok':'err');
  refresh();
}

function adminAjustes(){
  return `<div class="main-head"><div><h1>Ajustes</h1><p>Configuración general de esta demostración.</p></div></div>
  <div class="section-card" style="max-width:480px;">
    <h2>Reiniciar datos de demostración</h2>
    <p class="hint">Borra usuarios, citas, pagos y documentos guardados en este navegador. Los accesos rápidos de demo no se ven afectados.</p>
    <button class="btn-danger-ghost" onclick="resetDemoData()">Reiniciar datos</button>
  </div>`;
}
function resetDemoData(){
  [K_USERS, K_FAMILY, K_APPTS, K_PAYS, K_RECORDS, K_DOCTORS].forEach(k=>localStorage.removeItem(k));
  seedIfEmpty();
  toast('Datos de demostración reiniciados.', 'ok');
  refresh();
}

/* =====================================================================
   SALA DE VIDEOCONSULTA REAL (Jitsi Meet, compartida paciente/médico)
   ===================================================================== */
let jitsiApi = null;

function openVideoRoom(apptId){
  const session = getData(K_SESSION, null);
  const appt = getData(K_APPTS, []).find(a=>a.id===apptId);
  if(!appt) return;
  const isDoctor = session.role === 'medico';
  const counterpart = isDoctor ? appt.patientName : appt.doctorName;

  document.getElementById('videoModalCounterpart').textContent = counterpart;
  document.getElementById('videoModalMeta').textContent = `${fmtDate(appt.date)} · ${appt.time}`;
  document.getElementById('videoFinishBtn').style.display = (isDoctor && appt.status==='approved') ? 'block' : 'none';
  document.getElementById('videoFinishBtn').setAttribute('onclick', `finishConsult('${appt.id}')`);
  document.getElementById('videoModalOverlay').classList.add('show');

  const container = document.getElementById('jitsiContainer');
  container.innerHTML = '';

  if(typeof JitsiMeetExternalAPI === 'undefined'){
    container.innerHTML = `<div class="empty-state" style="color:#fff;">No se pudo cargar el servicio de video (sin conexión a internet). Si abriste el archivo directo desde tu computadora, sube el proyecto a Netlify o corre <code>npx serve .</code> para probarlo.</div>`;
    return;
  }

  const roomName = 'VerisConsulta-' + appt.id.replace(/[^a-zA-Z0-9]/g,'');
  jitsiApi = new JitsiMeetExternalAPI('meet.jit.si', {
    roomName,
    parentNode: container,
    width: '100%',
    height: '100%',
    userInfo: { displayName: session.name },
    configOverwrite: { prejoinPageEnabled: false, disableDeepLinking: true },
    interfaceConfigOverwrite: { TOOLBAR_BUTTONS: ['microphone','camera','desktop','fullscreen','hangup','chat','tileview'] }
  });
  jitsiApi.addEventListener('videoConferenceLeft', closeVideoRoom);
}
function closeVideoRoom(){
  if(jitsiApi){ jitsiApi.dispose(); jitsiApi = null; }
  document.getElementById('videoModalOverlay').classList.remove('show');
  document.getElementById('jitsiContainer').innerHTML = '';
}
function finishConsult(apptId){
  closeVideoRoom();
  const session = getData(K_SESSION, null);
  openModal('Finalizar consulta', `
    <p class="hint">Emite un documento antes de cerrar la consulta (opcional pero recomendado).</p>
    <div class="field"><label>Tipo de documento</label><div class="input-wrap"><select class="plain" id="finishDocType">
      <option value="prescription">Receta</option><option value="recommendation">Recomendación</option><option value="certificate">Certificado</option>
    </select></div></div>
    <div class="field"><label>Contenido</label><div class="input-wrap"><textarea class="plain" id="finishDocContent" rows="3" placeholder="Ej. Paracetamol 500mg cada 8 horas por 3 días"></textarea></div></div>
    <div class="inline-actions">
      <button class="btn-secondary" style="flex:1;" onclick="closeModal()">Cerrar sin emitir</button>
      <button class="btn-primary" style="flex:1;" onclick="confirmFinish('${apptId}')">Completar consulta</button>
    </div>
  `);
}
function confirmFinish(apptId){
  const appts = getData(K_APPTS, []);
  const appt = appts.find(a=>a.id===apptId);
  appt.status = 'completed';
  setData(K_APPTS, appts);

  const content = document.getElementById('finishDocContent').value.trim();
  if(content){
    const session = getData(K_SESSION, null);
    const doc = doctorRecordForSession(session);
    const type = document.getElementById('finishDocType').value;
    const recs = getData(K_RECORDS, []);
    recs.push({ id:uid('rec'), appointmentId:apptId, patientOwnerId:appt.patientOwnerId, patientName:appt.patientName,
      doctorId:doc.id, doctorName:doc.name, type, content, createdAt: nowISO() });
    setData(K_RECORDS, recs);
  }
  closeModal();
  toast('Consulta completada.', 'ok');
  refresh();
}

/* =====================================================================
   INIT
   ===================================================================== */
(function init(){
  seedIfEmpty();
  const session = getData(K_SESSION, null);
  if(session) renderApp();
})();
