// =============================================================================
// CONFIGURACIÓN DE SUPABASE — TRANSNUPERSA S.A.
// =============================================================================
export const SUPABASE_URL = "https://caqnjoyktcwhwxlffkbp.supabase.co";
export const SUPABASE_ANON_KEY = "sb_publishable_3fptG0wua8SYp2ZhFlvkyw_cAvhcuPB";
