import { el } from "./utils.js";

// -----------------------------------------------------------------------
// Tabla de datos genérica
// columns: [{ key, label, render(row) }]
// -----------------------------------------------------------------------
export function dataTable({ columns, rows, actions, emptyText = "No hay registros todavía." }) {
  const wrap = el("div", { class: "table-wrap" });
  if (!rows || rows.length === 0) {
    wrap.appendChild(emptyState(emptyText));
    return wrap;
  }
  const table = el("table", { class: "data-table" });
  const thead = el("thead", {}, el("tr", {}, [
    ...columns.map(c => el("th", {}, c.label)),
    actions ? el("th", { class: "col-actions" }, "Acciones") : null
  ]));
  const tbody = el("tbody");
  rows.forEach(row => {
    const tr = el("tr");
    columns.forEach(c => {
      const td = el("td", {});
      const val = c.render ? c.render(row) : (row[c.key] ?? "—");
      if (val instanceof Node) td.appendChild(val);
      else td.innerHTML = (val === null || val === undefined || val === "") ? "—" : String(val);
      tr.appendChild(td);
    });
    if (actions) {
      const td = el("td", { class: "col-actions" });
      actions(row).forEach(btn => td.appendChild(btn));
      tr.appendChild(td);
    }
    tbody.appendChild(tr);
  });
  table.appendChild(thead);
  table.appendChild(tbody);
  wrap.appendChild(table);
  return wrap;
}

export function emptyState(text, icon = "▢") {
  return el("div", { class: "empty-state" }, [
    el("div", { class: "empty-state__icon" }, icon),
    el("p", {}, text)
  ]);
}

export function iconBtn(label, title, onClick, tone = "") {
  return el("button", { class: "icon-btn" + (tone ? ` icon-btn--${tone}` : ""), type: "button", title, onclick: onClick }, label);
}

// -----------------------------------------------------------------------
// Medidor circular estilo "tablero de instrumentos"
// value: 0-100, label, sublabel
// -----------------------------------------------------------------------
export function gauge({ value, label, sublabel, tone = "amber" }) {
  const v = Math.max(0, Math.min(100, value));
  const wrap = el("div", { class: "gauge" });
  const ring = el("div", {
    class: `gauge__ring gauge__ring--${tone}`,
    style: `--gauge-value:${v}`
  });
  const inner = el("div", { class: "gauge__inner" }, [
    el("span", { class: "gauge__value" }, Math.round(v) + (typeof value === "number" && label.includes("$") ? "" : "%")),
  ]);
  ring.appendChild(inner);
  wrap.appendChild(ring);
  wrap.appendChild(el("div", { class: "gauge__label" }, label));
  if (sublabel) wrap.appendChild(el("div", { class: "gauge__sublabel" }, sublabel));
  return wrap;
}

export function statCard({ value, label, tone = "" }) {
  return el("div", { class: "stat-card" + (tone ? ` stat-card--${tone}` : "") }, [
    el("div", { class: "stat-card__value" }, String(value)),
    el("div", { class: "stat-card__label" }, label)
  ]);
}

export function sectionHeader(kicker, title, actionsNode) {
  const head = el("div", { class: "section-header" }, [
    el("div", {}, [
      el("p", { class: "section-header__kicker" }, kicker),
      el("h2", { class: "section-header__title" }, title)
    ])
  ]);
  if (actionsNode) head.appendChild(el("div", { class: "section-header__actions" }, actionsNode));
  return head;
}
