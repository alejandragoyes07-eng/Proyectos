import { supabase } from "./supabaseClient.js";

export const ROLES = {
  administrador: "Administrador",
  jefe_mantenimiento: "Jefe de mantenimiento",
  tecnico: "Técnico / mecánico",
  supervisor: "Supervisor / gerente"
};

let currentSession = null;
let currentPerfil = null;

export async function initAuth() {
  const { data } = await supabase.auth.getSession();
  currentSession = data.session;
  if (currentSession) await loadPerfil();
  return currentSession;
}

export function onAuthChange(callback) {
  supabase.auth.onAuthStateChange(async (_event, session) => {
    currentSession = session;
    if (session) await loadPerfil(); else currentPerfil = null;
    callback(session);
  });
}

async function loadPerfil() {
  const { data, error } = await supabase
    .from("perfiles")
    .select("*")
    .eq("id", currentSession.user.id)
    .single();
  if (!error) currentPerfil = data;
}

export function getSession() { return currentSession; }
export function getPerfil() { return currentPerfil; }
export function hasRole(...roles) { return currentPerfil && roles.includes(currentPerfil.rol); }

export async function login(correo, password) {
  const { data, error } = await supabase.auth.signInWithPassword({ email: correo, password });
  if (error) throw error;
  currentSession = data.session;
  await loadPerfil();
  return data;
}

export async function registrar({ nombre, correo, password, rol }) {
  const { data, error } = await supabase.auth.signUp({
    email: correo,
    password,
    options: { data: { nombre, rol } }
  });
  if (error) throw error;
  return data;
}

export async function logout() {
  await supabase.auth.signOut();
  currentSession = null;
  currentPerfil = null;
}
