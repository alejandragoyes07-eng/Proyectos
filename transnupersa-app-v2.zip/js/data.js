import { supabase } from "./supabaseClient.js";

// Capa de acceso a datos: una función simple por tabla para mantener
// las vistas limpias y fáciles de leer.

async function list(table, opts = {}) {
  let q = supabase.from(table).select(opts.select || "*");
  if (opts.order) q = q.order(opts.order.col, { ascending: opts.order.asc !== false });
  if (opts.eq) for (const [k, v] of Object.entries(opts.eq)) q = q.eq(k, v);
  const { data, error } = await q;
  if (error) throw error;
  return data;
}
async function insert(table, row) {
  const { data, error } = await supabase.from(table).insert(row).select().single();
  if (error) throw error;
  return data;
}
async function update(table, id, row) {
  const { data, error } = await supabase.from(table).update(row).eq("id", id).select().single();
  if (error) throw error;
  return data;
}
async function remove(table, id) {
  const { error } = await supabase.from(table).delete().eq("id", id);
  if (error) throw error;
}

// ------------------------------------------------------------ Vehículos ---
export const Vehiculos = {
  list: () => list("vehiculos", { order: { col: "codigo" } }),
  get: async (id) => (await supabase.from("vehiculos").select("*").eq("id", id).single()).data,
  create: (row) => insert("vehiculos", row),
  update: (id, row) => update("vehiculos", id, row),
  remove: (id) => remove("vehiculos", id),
};

// --------------------------------------------------- Catálogos maestros ---
export const TiposMantenimiento = {
  list: () => list("tipos_mantenimiento", { order: { col: "codigo" } }),
  create: (row) => insert("tipos_mantenimiento", row),
  update: (id, row) => update("tipos_mantenimiento", id, row),
  remove: (id) => remove("tipos_mantenimiento", id),
};

export const TiposAveria = {
  list: () => list("tipos_averia", { order: { col: "nombre" } }),
  create: (row) => insert("tipos_averia", row),
  remove: (id) => remove("tipos_averia", id),
};

// ------------------------------------------------ Mantenimiento preventivo
export const Preventivo = {
  list: () => list("mantenimiento_preventivo", {
    select: "*, vehiculos(codigo,placa,marca,modelo), tipos_mantenimiento(codigo,nombre)",
    order: { col: "fecha_programada" }
  }),
  create: (row) => insert("mantenimiento_preventivo", row),
  update: (id, row) => update("mantenimiento_preventivo", id, row),
  remove: (id) => remove("mantenimiento_preventivo", id),
};

// ------------------------------------------------ Mantenimiento correctivo
export const Correctivo = {
  list: () => list("mantenimiento_correctivo", {
    select: "*, vehiculos(codigo,placa,marca,modelo), tipos_averia(nombre)",
    order: { col: "fecha_reporte", asc: false }
  }),
  create: (row) => insert("mantenimiento_correctivo", row),
  update: (id, row) => update("mantenimiento_correctivo", id, row),
  remove: (id) => remove("mantenimiento_correctivo", id),
};

// ------------------------------------------------------- Órdenes de trabajo
export const Ordenes = {
  list: () => list("ordenes_trabajo", {
    select: `*, vehiculos(codigo,placa,marca,modelo),
              perfiles(nombre),
              mantenimiento_preventivo(fecha_programada, tipos_mantenimiento(nombre)),
              mantenimiento_correctivo(diagnostico, tipos_averia(nombre))`,
    order: { col: "created_at", asc: false }
  }),
  update: (id, row) => update("ordenes_trabajo", id, row),
};

// ----------------------------------------------------------------- Perfiles
export const Perfiles = {
  list: () => list("perfiles", { order: { col: "nombre" } }),
  update: (id, row) => update("perfiles", id, row),
};
