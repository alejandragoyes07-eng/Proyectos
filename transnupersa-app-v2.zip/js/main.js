import { el, toast, buildForm } from "./utils.js";
import { initAuth, onAuthChange, getSession, getPerfil, login, registrar, logout, ROLES } from "./auth.js";
import { ROUTES, renderRoute, currentPath } from "./router.js";

const app = document.getElementById("app");

boot();

async function boot() {
  await initAuth();
  onAuthChange(() => render());
  render();
}

function render() {
  const session = getSession();
  app.innerHTML = "";
  if (!session) {
    app.appendChild(loginScreen());
  } else {
    app.appendChild(appShell());
    window.onhashchange = () => renderRoute(document.getElementById("view-content"), currentPath());
    renderRoute(document.getElementById("view-content"), currentPath());
  }
}

// ============================================================= LOGIN =====
function loginScreen() {
  const wrap = el("div", { class: "auth-screen" });

  const brand = el("div", { class: "auth-brand" }, [
    el("div", { class: "auth-brand__mark" }, "TN"),
    el("div", {}, [
      el("h1", {}, "TRANSNUPERSA S.A."),
      el("p", {}, "Sistema de Gestión del Mantenimiento Vehicular")
    ])
  ]);

  const card = el("div", { class: "auth-card" });
  const tabs = el("div", { class: "auth-tabs" });
  const tabLogin = el("button", { class: "auth-tab auth-tab--active", type: "button" }, "Iniciar sesión");
  const tabSignup = el("button", { class: "auth-tab", type: "button" }, "Crear cuenta");
  tabs.appendChild(tabLogin); tabs.appendChild(tabSignup);
  card.appendChild(tabs);

  const formHost = el("div", {});
  card.appendChild(formHost);
  showLogin();

  tabLogin.addEventListener("click", () => { setTab(tabLogin); showLogin(); });
  tabSignup.addEventListener("click", () => { setTab(tabSignup); showSignup(); });
  function setTab(tab) { [tabLogin, tabSignup].forEach(t => t.classList.remove("auth-tab--active")); tab.classList.add("auth-tab--active"); }

  function showLogin() {
    formHost.innerHTML = "";
    const form = buildForm([
      { name: "correo", label: "Correo electrónico", type: "email", required: true, placeholder: "nombre@transnupersa.com" },
      { name: "password", label: "Contraseña", type: "password", required: true },
    ], "Ingresar al sistema", async (data) => {
      try { await login(data.correo, data.password); toast("Bienvenido de nuevo.", "success"); render(); }
      catch (e) { toast("No se pudo iniciar sesión: " + e.message, "danger"); }
    });
    formHost.appendChild(form);
  }

  function showSignup() {
    formHost.innerHTML = "";
    const form = buildForm([
      { name: "nombre", label: "Nombre completo", required: true, full: true },
      { name: "correo", label: "Correo electrónico", type: "email", required: true, full: true },
      { name: "password", label: "Contraseña (mínimo 6 caracteres)", type: "password", required: true, full: true },
      { name: "rol", label: "Rol solicitado", type: "select", required: true, full: true,
        options: Object.entries(ROLES).map(([value, label]) => ({ value, label })) },
    ], "Crear cuenta", async (data) => {
      try {
        await registrar(data);
        toast("Cuenta creada. Ya puedes iniciar sesión.", "success");
        setTab(tabLogin); showLogin();
      } catch (e) { toast("No se pudo crear la cuenta: " + e.message, "danger"); }
    });
    formHost.appendChild(form);
    formHost.appendChild(el("p", { class: "auth-note" },
      "Nota: solo la primera cuenta creada en el sistema recibe el rol elegido aquí (pensado para el primer Administrador). Las siguientes cuentas ingresan como Técnico y deben ser promovidas desde el módulo de Usuarios."));
  }

  wrap.appendChild(brand);
  wrap.appendChild(card);
  return wrap;
}

// ========================================================== APP SHELL ====
function appShell() {
  const perfil = getPerfil();
  const shell = el("div", { class: "shell" });

  // --- Sidebar ---
  const sidebar = el("aside", { class: "sidebar" });
  sidebar.appendChild(el("div", { class: "sidebar__brand" }, [
    el("div", { class: "sidebar__mark" }, "TN"),
    el("div", {}, [el("strong", {}, "TRANSNUPERSA"), el("span", {}, "Mantenimiento vehicular")])
  ]));

  const nav = el("nav", { class: "sidebar__nav" });
  ROUTES.forEach(r => {
    if (r.roles && !r.roles.includes(perfil?.rol)) return;
    const link = el("a", { href: "#" + r.path, class: "nav-link" }, [
      el("span", { class: "nav-link__code" }, r.code),
      el("span", {}, r.label)
    ]);
    nav.appendChild(link);
  });
  sidebar.appendChild(nav);

  sidebar.appendChild(el("div", { class: "sidebar__footer" }, [
    el("div", { class: "user-chip" }, [
      el("div", { class: "user-chip__avatar" }, (perfil?.nombre || "?").slice(0,1).toUpperCase()),
      el("div", {}, [
        el("strong", {}, perfil?.nombre || "Usuario"),
        el("span", {}, ROLES[perfil?.rol] || perfil?.rol || "")
      ])
    ]),
    el("button", { class: "btn btn--ghost btn--small", type: "button", onclick: async () => { await logout(); render(); } }, "Cerrar sesión")
  ]));

  // --- Main content ---
  const main = el("main", { class: "main" });
  const content = el("div", { id: "view-content", class: "view-content" });
  main.appendChild(content);

  shell.appendChild(sidebar);
  shell.appendChild(main);

  // Highlight active nav on load / hash change
  function highlight() {
    const path = currentPath();
    nav.querySelectorAll(".nav-link").forEach(a => a.classList.toggle("nav-link--active", a.getAttribute("href") === "#" + path));
  }
  window.addEventListener("hashchange", highlight);
  setTimeout(highlight, 0);

  return shell;
}
