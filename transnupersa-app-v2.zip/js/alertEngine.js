import { Vehiculos, Preventivo, Correctivo, Ordenes } from "./data.js";

// Motor de reglas de alertas — RF-41 a RF-46 del SRS.
// No se guardan en una tabla propia: se calculan a partir de los datos
// existentes cada vez que se visita el panel o el módulo de alertas.
export async function computeAlerts() {
  const [vehiculos, preventivos, correctivos, ordenes] = await Promise.all([
    Vehiculos.list(), Preventivo.list(), Correctivo.list(), Ordenes.list()
  ]);

  const alerts = [];
  const today = new Date();

  // RF-42 / RF-43: mantenimiento próximo o vencido (por km o por fecha)
  preventivos.forEach(p => {
    if (p.estado === "completado" || p.estado === "cancelado") return;
    const veh = p.vehiculos;
    if (!veh) return;
    if (p.km_programado) {
      const restante = p.km_programado - veh.kilometraje;
      if (restante <= 0) {
        alerts.push({ nivel: "critico", tipo: "Mantenimiento vencido",
          mensaje: `${veh.codigo} (${veh.placa}) superó el kilometraje programado para "${p.tipos_mantenimiento?.nombre || 'mantenimiento'}" por ${Math.abs(restante).toLocaleString()} km.`,
          vehiculo: veh.codigo });
      } else if (restante <= 500) {
        alerts.push({ nivel: "advertencia", tipo: "Mantenimiento próximo",
          mensaje: `${veh.codigo} (${veh.placa}) — faltan ${restante.toLocaleString()} km para "${p.tipos_mantenimiento?.nombre || 'mantenimiento'}".`,
          vehiculo: veh.codigo });
      }
    }
    if (p.fecha_programada) {
      const dias = Math.round((new Date(p.fecha_programada) - today) / 86400000);
      if (dias < 0) {
        alerts.push({ nivel: "critico", tipo: "Mantenimiento retrasado",
          mensaje: `${veh.codigo} (${veh.placa}) tiene "${p.tipos_mantenimiento?.nombre || 'mantenimiento'}" retrasado ${Math.abs(dias)} día(s).`,
          vehiculo: veh.codigo });
      } else if (dias <= 7) {
        alerts.push({ nivel: "advertencia", tipo: "Mantenimiento próximo",
          mensaje: `${veh.codigo} (${veh.placa}) — "${p.tipos_mantenimiento?.nombre || 'mantenimiento'}" programado en ${dias} día(s).`,
          vehiculo: veh.codigo });
      }
    }
  });

  // RF-44: fallas críticas / unidades fuera de servicio
  vehiculos.forEach(v => {
    if (v.estado === "fuera_servicio") {
      alerts.push({ nivel: "critico", tipo: "Unidad fuera de servicio",
        mensaje: `${v.codigo} (${v.placa}) está marcada como fuera de servicio.`, vehiculo: v.codigo });
    }
  });
  correctivos.forEach(c => {
    if (c.estado !== "solucionado") {
      const veh = c.vehiculos;
      alerts.push({ nivel: c.estado === "reportado" ? "critico" : "advertencia", tipo: "Falla sin resolver",
        mensaje: `${veh?.codigo || ""} (${veh?.placa || ""}) tiene una falla "${c.tipos_averia?.nombre || ''}" en estado ${(c.estado || 'reportado').replace('_',' ')}.`,
        vehiculo: veh?.codigo });
    }
  });

  // RF-45: órdenes de trabajo pendientes o en proceso hace más de 5 días
  ordenes.forEach(o => {
    if (o.estado === "finalizado") return;
    const dias = Math.round((today - new Date(o.created_at)) / 86400000);
    if (dias >= 5) {
      alerts.push({ nivel: "advertencia", tipo: "Orden de trabajo demorada",
        mensaje: `OT de ${o.vehiculos?.codigo || ""} lleva ${dias} día(s) en estado "${(o.estado || 'pendiente').replace('_',' ')}".`,
        vehiculo: o.vehiculos?.codigo });
    }
  });

  // RF-46: vehículo sin mantenimiento reciente (más de 180 días sin ninguna intervención)
  vehiculos.forEach(v => {
    const relacionados = [...preventivos, ...correctivos].filter(m => m.vehiculo_id === v.id);
    if (relacionados.length === 0) {
      alerts.push({ nivel: "info", tipo: "Sin historial de mantenimiento",
        mensaje: `${v.codigo} (${v.placa}) no registra ningún mantenimiento todavía.`, vehiculo: v.codigo });
    }
  });

  const orden = { critico: 0, advertencia: 1, info: 2 };
  alerts.sort((a, b) => orden[a.nivel] - orden[b.nivel]);
  return alerts;
}
