import { renderDashboard } from "./views/dashboard.js";
import { renderVehiculos } from "./views/vehiculos.js";
import { renderCatalogos } from "./views/catalogos.js";
import { renderPreventivo } from "./views/preventivo.js";
import { renderCorrectivo } from "./views/correctivo.js";
import { renderOrdenes } from "./views/ordenes.js";
import { renderHistorial } from "./views/historial.js";
import { renderReportes } from "./views/reportes.js";
import { renderAlertas } from "./views/alertas.js";
import { renderUsuarios } from "./views/usuarios.js";
import { toast } from "./utils.js";

export const ROUTES = [
  { path: "dashboard", label: "Panel de control", code: "01", render: renderDashboard, roles: null },
  { path: "vehiculos", label: "Vehículos", code: "VH", render: renderVehiculos, roles: null },
  { path: "catalogos", label: "Catálogos", code: "TM", render: renderCatalogos, roles: ["administrador", "jefe_mantenimiento"] },
  { path: "preventivo", label: "Mant. preventivo", code: "MP", render: renderPreventivo, roles: null },
  { path: "correctivo", label: "Mant. correctivo", code: "MC", render: renderCorrectivo, roles: null },
  { path: "ordenes", label: "Órdenes de trabajo", code: "OT", render: renderOrdenes, roles: null },
  { path: "historial", label: "Historial", code: "HM", render: renderHistorial, roles: null },
  { path: "reportes", label: "Reportes", code: "RP", render: renderReportes, roles: null },
  { path: "alertas", label: "Alertas", code: "AL", render: renderAlertas, roles: null },
  { path: "usuarios", label: "Usuarios", code: "US", render: renderUsuarios, roles: ["administrador"] },
];

export async function renderRoute(contentEl, path) {
  const route = ROUTES.find(r => r.path === path) || ROUTES[0];
  contentEl.innerHTML = "";
  contentEl.classList.remove("view-enter");
  void contentEl.offsetWidth;
  contentEl.classList.add("view-enter");
  try {
    await route.render(contentEl);
  } catch (e) {
    console.error(e);
    contentEl.innerHTML = "";
    contentEl.appendChild(errorPanel(e));
  }
}

function errorPanel(e) {
  const div = document.createElement("div");
  div.className = "panel panel--error";
  div.innerHTML = `<h3>No se pudo cargar esta sección</h3>
    <p>Revisa que <code>js/config.js</code> tenga tu URL y clave de Supabase, y que hayas ejecutado <code>supabase/schema.sql</code> en tu proyecto.</p>
    <p class="mono" style="opacity:.7">${(e && e.message) || e}</p>`;
  return div;
}

export function currentPath() {
  return (location.hash || "#dashboard").replace("#", "");
}
