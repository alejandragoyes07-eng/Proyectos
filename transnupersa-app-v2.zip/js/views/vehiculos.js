import { el, fmtDate, fmtKm, toast, openModal, confirmDialog, buildForm, badge, ESTADO_TONE, estadoLabel } from "../utils.js";
import { dataTable, sectionHeader, iconBtn } from "../components.js";
import { Vehiculos } from "../data.js";

const ESTADOS = [
  { value: "activo", label: "Activo" },
  { value: "en_mantenimiento", label: "En mantenimiento" },
  { value: "fuera_servicio", label: "Fuera de servicio" },
];

export async function renderVehiculos(container) {
  container.appendChild(sectionHeader("MÓDULO · VH", "Vehículos de la flota",
    el("button", { class: "btn btn--primary", type: "button", onclick: () => openForm() }, "+ Registrar vehículo")
  ));
  container.appendChild(el("p", { class: "view-intro" }, "Información de identificación, técnica y operativa de cada unidad de carga pesada."));

  const tableHost = el("div", {});
  container.appendChild(tableHost);
  await refresh();

  async function refresh() {
    tableHost.innerHTML = "";
    tableHost.appendChild(el("p", { class: "loading" }, "Cargando vehículos…"));
    const rows = await Vehiculos.list();
    tableHost.innerHTML = "";
    tableHost.appendChild(dataTable({
      columns: [
        { label: "Código", render: r => `<span class="mono">${r.codigo}</span>` },
        { label: "Placa", render: r => `<span class="mono">${r.placa}</span>` },
        { label: "Marca / Modelo", render: r => `${r.marca || "—"} ${r.modelo || ""}` },
        { label: "Año", key: "anio" },
        { label: "Kilometraje", render: r => `<span class="mono">${fmtKm(r.kilometraje)}</span>` },
        { label: "Conductor", render: r => r.conductor_asignado || "—" },
        { label: "Estado", render: r => badge(estadoLabel(r.estado), ESTADO_TONE[r.estado]) },
      ],
      rows,
      emptyText: "No hay vehículos registrados todavía. Registra el primero de la flota.",
      actions: (row) => [
        iconBtn("✎", "Editar", () => openForm(row)),
        iconBtn("🗑", "Eliminar", () => onDelete(row), "danger"),
      ]
    }));
  }

  function openForm(row) {
    const isEdit = !!row;
    const fields = [
      { name: "codigo", label: "Código interno", required: true, value: row?.codigo, placeholder: "TR-005" },
      { name: "placa", label: "Placa", required: true, value: row?.placa, placeholder: "PBX-1234" },
      { name: "marca", label: "Marca", value: row?.marca },
      { name: "modelo", label: "Modelo", value: row?.modelo },
      { name: "anio", label: "Año", type: "number", value: row?.anio },
      { name: "tipo_vehiculo", label: "Tipo de vehículo", value: row?.tipo_vehiculo || "Tracto camión" },
      { name: "chasis", label: "N° de chasis", value: row?.chasis },
      { name: "motor", label: "N° de motor", value: row?.motor },
      { name: "capacidad_carga", label: "Capacidad de carga (ton)", type: "number", step: "0.1", value: row?.capacidad_carga },
      { name: "combustible", label: "Combustible", value: row?.combustible || "Diésel" },
      { name: "kilometraje", label: "Kilometraje actual", type: "number", required: true, value: row?.kilometraje ?? 0 },
      { name: "fecha_adquisicion", label: "Fecha de adquisición", type: "date", value: row?.fecha_adquisicion },
      { name: "estado", label: "Estado", type: "select", options: ESTADOS, value: row?.estado || "activo" },
      { name: "conductor_asignado", label: "Conductor asignado", value: row?.conductor_asignado },
      { name: "observaciones", label: "Observaciones", type: "textarea", full: true, value: row?.observaciones },
    ];
    const form = buildForm(fields, isEdit ? "Guardar cambios" : "Registrar vehículo", async (data) => {
      try {
        if (isEdit) { await Vehiculos.update(row.id, data); toast("Vehículo actualizado correctamente.", "success"); }
        else { await Vehiculos.create(data); toast("Vehículo registrado correctamente.", "success"); }
        modal.close();
        await refresh();
      } catch (e) {
        toast("Error: " + e.message, "danger");
      }
    });
    const modal = openModal({ title: isEdit ? `Editar ${row.codigo}` : "Registrar vehículo", bodyNode: form, wide: true });
  }

  async function onDelete(row) {
    const ok = await confirmDialog(`¿Eliminar el vehículo ${row.codigo} (${row.placa})? Esta acción no se puede deshacer.`);
    if (!ok) return;
    try {
      await Vehiculos.remove(row.id);
      toast("Vehículo eliminado.", "success");
      await refresh();
    } catch (e) {
      toast("Error: " + e.message, "danger");
    }
  }
}
