import { el, fmtDate, toast, openModal, confirmDialog, buildForm, badge, ESTADO_TONE, estadoLabel } from "../utils.js";
import { dataTable, sectionHeader, iconBtn } from "../components.js";
import { Correctivo, Vehiculos, TiposAveria } from "../data.js";

const ESTADOS = [
  { value: "reportado", label: "Reportado" },
  { value: "diagnosticado", label: "Diagnosticado" },
  { value: "en_reparacion", label: "En reparación" },
  { value: "solucionado", label: "Solucionado" },
];

export async function renderCorrectivo(container) {
  container.appendChild(sectionHeader("MÓDULO · MC", "Mantenimiento correctivo",
    el("button", { class: "btn btn--primary", type: "button", onclick: () => openForm() }, "+ Reportar falla")
  ));
  container.appendChild(el("p", { class: "view-intro" }, "Registro de fallas o averías, diagnóstico y solución aplicada. Genera automáticamente su orden de trabajo de reparación."));

  const tableHost = el("div", {});
  container.appendChild(tableHost);
  await refresh();

  async function refresh() {
    tableHost.innerHTML = "";
    tableHost.appendChild(el("p", { class: "loading" }, "Cargando reportes de falla…"));
    const rows = await Correctivo.list();
    tableHost.innerHTML = "";
    tableHost.appendChild(dataTable({
      columns: [
        { label: "Vehículo", render: r => `<span class="mono">${r.vehiculos?.codigo || "—"}</span> ${r.vehiculos?.placa || ""}` },
        { label: "Tipo de avería", render: r => r.tipos_averia?.nombre || "—" },
        { label: "Fecha de reporte", render: r => fmtDate(r.fecha_reporte) },
        { label: "Diagnóstico", render: r => r.diagnostico || "—" },
        { label: "Solución", render: r => r.solucion || "—" },
        { label: "Estado", render: r => badge(estadoLabel(r.estado), ESTADO_TONE[r.estado]) },
      ],
      rows,
      emptyText: "No se han reportado fallas. Buena señal, o falta registrar el historial.",
      actions: (row) => [
        iconBtn("✎", "Actualizar", () => openUpdateForm(row)),
        iconBtn("🗑", "Eliminar", () => onDelete(row), "danger"),
      ]
    }));
  }

  async function openForm() {
    const [vehiculos, tipos] = await Promise.all([Vehiculos.list(), TiposAveria.list()]);
    if (vehiculos.length === 0) { toast("Registra al menos un vehículo primero.", "danger"); return; }
    const fields = [
      { name: "vehiculo_id", label: "Vehículo", type: "select", required: true,
        options: vehiculos.map(v => ({ value: v.id, label: `${v.codigo} — ${v.placa}` })) },
      { name: "tipo_averia_id", label: "Tipo de avería", type: "select",
        options: tipos.map(t => ({ value: t.id, label: t.nombre })) },
      { name: "fecha_reporte", label: "Fecha del reporte", type: "date", value: new Date().toISOString().slice(0,10) },
      { name: "km_reporte", label: "Kilometraje al momento del reporte", type: "number" },
      { name: "diagnostico", label: "Diagnóstico inicial", type: "textarea", full: true },
    ];
    const form = buildForm(fields, "Reportar falla", async (data) => {
      try {
        await Correctivo.create({ ...data, estado: "reportado" });
        toast("Falla registrada. Orden de trabajo generada automáticamente.", "success");
        modal.close();
        await refresh();
      } catch (e) { toast("Error: " + e.message, "danger"); }
    });
    const modal = openModal({ title: "Reportar falla o avería", bodyNode: form, wide: true });
  }

  function openUpdateForm(row) {
    const fields = [
      { name: "estado", label: "Estado", type: "select", required: true, options: ESTADOS, value: row.estado },
      { name: "diagnostico", label: "Diagnóstico", type: "textarea", full: true, value: row.diagnostico },
      { name: "solucion", label: "Solución aplicada", type: "textarea", full: true, value: row.solucion },
    ];
    const form = buildForm(fields, "Guardar cambios", async (data) => {
      try { await Correctivo.update(row.id, data); toast("Registro actualizado.", "success"); modal.close(); await refresh(); }
      catch (e) { toast("Error: " + e.message, "danger"); }
    });
    const modal = openModal({ title: `Actualizar falla — ${row.vehiculos?.codigo || ""}`, bodyNode: form, wide: true });
  }

  async function onDelete(row) {
    if (!(await confirmDialog("¿Eliminar este reporte de falla?"))) return;
    try { await Correctivo.remove(row.id); toast("Eliminado.", "success"); await refresh(); }
    catch (e) { toast("Error: " + e.message, "danger"); }
  }
}
