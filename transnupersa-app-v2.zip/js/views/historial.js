import { el, fmtDate, fmtKm, fmtMoney } from "../utils.js";
import { sectionHeader, emptyState } from "../components.js";
import { Vehiculos, Preventivo, Correctivo, Ordenes } from "../data.js";

export async function renderHistorial(container) {
  container.appendChild(sectionHeader("MÓDULO · HM", "Historial de mantenimiento"));
  container.appendChild(el("p", { class: "view-intro" }, "Trazabilidad completa por vehículo: línea de tiempo, intervenciones y costos acumulados."));

  const vehiculos = await Vehiculos.list();
  const selectWrap = el("div", { class: "form__field", style: "max-width:360px" });
  selectWrap.appendChild(el("label", { for: "veh-select" }, "Selecciona un vehículo"));
  const select = el("select", { id: "veh-select" });
  select.appendChild(el("option", { value: "" }, "— Selecciona —"));
  vehiculos.forEach(v => select.appendChild(el("option", { value: v.id }, `${v.codigo} — ${v.placa} (${v.marca || ""} ${v.modelo || ""})`)));
  selectWrap.appendChild(select);
  container.appendChild(selectWrap);

  const host = el("div", { class: "historial-host" });
  container.appendChild(host);
  if (vehiculos.length === 0) host.appendChild(emptyState("Registra vehículos para poder ver su historial."));

  select.addEventListener("change", async () => {
    if (!select.value) { host.innerHTML = ""; return; }
    await loadHistorial(select.value);
  });

  async function loadHistorial(vehiculoId) {
    host.innerHTML = "";
    host.appendChild(el("p", { class: "loading" }, "Cargando historial…"));
    const veh = vehiculos.find(v => v.id === vehiculoId);
    const [preventivos, correctivos, ordenes] = await Promise.all([Preventivo.list(), Correctivo.list(), Ordenes.list()]);
    const prevVeh = preventivos.filter(p => p.vehiculo_id === vehiculoId);
    const corrVeh = correctivos.filter(c => c.vehiculo_id === vehiculoId);
    const otVeh = ordenes.filter(o => o.vehiculo_id === vehiculoId);
    const costoTotal = otVeh.reduce((s, o) => s + (Number(o.costo) || 0), 0);

    host.innerHTML = "";

    const summary = el("div", { class: "summary-strip" }, [
      summaryChip("Kilometraje actual", fmtKm(veh.kilometraje)),
      summaryChip("Intervenciones totales", String(prevVeh.length + corrVeh.length)),
      summaryChip("Costo acumulado", fmtMoney(costoTotal)),
      summaryChip("Estado actual", (veh.estado || "activo").replace("_", " ")),
    ]);
    host.appendChild(summary);

    const events = [];
    prevVeh.forEach(p => events.push({
      fecha: p.fecha_programada || p.created_at, tipo: "Preventivo",
      titulo: p.tipos_mantenimiento?.nombre || "Mantenimiento preventivo",
      detalle: `Estado: ${(p.estado || "pendiente").replace("_"," ")}${p.km_programado ? ` · Km objetivo: ${Number(p.km_programado).toLocaleString()}` : ""}`
    }));
    corrVeh.forEach(c => events.push({
      fecha: c.fecha_reporte || c.created_at, tipo: "Correctivo",
      titulo: c.tipos_averia?.nombre || "Falla reportada",
      detalle: `${c.diagnostico ? "Diagnóstico: " + c.diagnostico + ". " : ""}${c.solucion ? "Solución: " + c.solucion : "Sin solución registrada aún."}`
    }));
    events.sort((a, b) => new Date(b.fecha) - new Date(a.fecha));

    const timeline = el("div", { class: "timeline" });
    if (events.length === 0) {
      timeline.appendChild(emptyState("Este vehículo todavía no tiene intervenciones registradas."));
    } else {
      events.forEach(ev => {
        timeline.appendChild(el("div", { class: `timeline__item timeline__item--${ev.tipo === "Preventivo" ? "prev" : "corr"}` }, [
          el("div", { class: "timeline__dot" }),
          el("div", { class: "timeline__content" }, [
            el("span", { class: "timeline__date mono" }, fmtDate(ev.fecha)),
            el("strong", {}, `${ev.tipo} · ${ev.titulo}`),
            el("p", {}, ev.detalle)
          ])
        ]));
      });
    }
    host.appendChild(el("h3", { class: "panel__title" }, "Línea de tiempo"));
    host.appendChild(timeline);
  }
}

function summaryChip(label, value) {
  return el("div", { class: "summary-chip" }, [
    el("span", { class: "summary-chip__value" }, value),
    el("span", { class: "summary-chip__label" }, label)
  ]);
}
