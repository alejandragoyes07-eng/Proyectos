import { el, fmtDateTime, fmtMoney, toast, openModal, buildForm } from "../utils.js";
import { sectionHeader, emptyState } from "../components.js";
import { Ordenes, Perfiles } from "../data.js";

const COLUMNAS = [
  { key: "pendiente", label: "Pendiente" },
  { key: "en_proceso", label: "En proceso" },
  { key: "finalizado", label: "Finalizado" },
];

export async function renderOrdenes(container) {
  container.appendChild(sectionHeader("MÓDULO · OT", "Órdenes de trabajo"));
  container.appendChild(el("p", { class: "view-intro" }, "Generadas automáticamente desde mantenimiento preventivo o correctivo. Asigna un técnico, controla el avance y registra el costo."));

  const board = el("div", { class: "kanban" });
  container.appendChild(board);
  await refresh();

  async function refresh() {
    board.innerHTML = "";
    const [ordenes, tecnicos] = await Promise.all([Ordenes.list(), Perfiles.list()]);
    COLUMNAS.forEach(col => {
      const colEl = el("div", { class: "kanban__col" });
      colEl.appendChild(el("div", { class: "kanban__col-head" }, [
        el("span", {}, col.label),
        el("span", { class: "kanban__count" }, String(ordenes.filter(o => o.estado === col.key).length))
      ]));
      const cardsHost = el("div", { class: "kanban__cards" });
      const items = ordenes.filter(o => o.estado === col.key);
      if (items.length === 0) cardsHost.appendChild(emptyState("Sin órdenes aquí.", "—"));
      items.forEach(o => cardsHost.appendChild(otCard(o, tecnicos, refresh)));
      colEl.appendChild(cardsHost);
      board.appendChild(colEl);
    });
  }
}

function otCard(o, tecnicos, refresh) {
  const origenLabel = o.origen === "preventivo"
    ? (o.mantenimiento_preventivo?.tipos_mantenimiento?.nombre || "Mantenimiento preventivo")
    : (o.mantenimiento_correctivo?.tipos_averia?.nombre || "Mantenimiento correctivo");

  const card = el("div", { class: `ot-card ot-card--${o.origen}` }, [
    el("div", { class: "ot-card__top" }, [
      el("span", { class: "ot-card__tag" }, o.origen === "preventivo" ? "PREV" : "CORR"),
      el("span", { class: "ot-card__vehiculo mono" }, o.vehiculos?.codigo || "—")
    ]),
    el("p", { class: "ot-card__desc" }, origenLabel),
    el("p", { class: "ot-card__meta" }, `Técnico: ${o.perfiles?.nombre || "Sin asignar"}`),
    el("p", { class: "ot-card__meta" }, `Costo: ${fmtMoney(o.costo)}`),
    el("p", { class: "ot-card__date" }, fmtDateTime(o.created_at)),
    el("button", { class: "btn btn--ghost btn--small", type: "button", onclick: () => openManage(o, tecnicos, refresh) }, "Gestionar")
  ]);
  return card;
}

function openManage(o, tecnicos, refresh) {
  const fields = [
    { name: "tecnico_id", label: "Técnico asignado", type: "select",
      options: [{ value: "", label: "Sin asignar" }, ...tecnicos.map(t => ({ value: t.id, label: t.nombre }))],
      value: o.tecnico_id || "" },
    { name: "estado", label: "Estado", type: "select", required: true,
      options: [{ value: "pendiente", label: "Pendiente" }, { value: "en_proceso", label: "En proceso" }, { value: "finalizado", label: "Finalizado" }],
      value: o.estado },
    { name: "costo", label: "Costo del trabajo (USD)", type: "number", step: "0.01", value: o.costo },
    { name: "descripcion_trabajo", label: "Descripción del trabajo realizado", type: "textarea", full: true, value: o.descripcion_trabajo },
    { name: "fecha_finalizacion", label: "Fecha de finalización", type: "date", value: o.fecha_finalizacion },
  ];
  const form = buildForm(fields, "Guardar orden de trabajo", async (data) => {
    try {
      const payload = { ...data, tecnico_id: data.tecnico_id || null };
      await Ordenes.update(o.id, payload);
      toast("Orden de trabajo actualizada.", "success");
      modal.close();
      await refresh();
    } catch (e) { toast("Error: " + e.message, "danger"); }
  });
  const modal = openModal({ title: `Orden de trabajo — ${o.vehiculos?.codigo || ""}`, bodyNode: form, wide: true });
}
