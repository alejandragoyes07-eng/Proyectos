import { el } from "../utils.js";
import { sectionHeader, emptyState } from "../components.js";
import { computeAlerts } from "../alertEngine.js";

export async function renderAlertas(container) {
  container.appendChild(sectionHeader("MÓDULO · AL", "Alertas y notificaciones"));
  container.appendChild(el("p", { class: "view-intro" }, "Reglas evaluadas automáticamente sobre los datos de la flota: mantenimientos próximos o vencidos, fallas críticas y órdenes de trabajo demoradas."));

  const host = el("div", {}, el("p", { class: "loading" }, "Evaluando reglas de alerta…"));
  container.appendChild(host);

  const alerts = await computeAlerts();
  host.innerHTML = "";

  const filterBar = el("div", { class: "filter-bar" });
  const counts = { critico: alerts.filter(a => a.nivel === "critico").length, advertencia: alerts.filter(a => a.nivel === "advertencia").length, info: alerts.filter(a => a.nivel === "info").length };
  filterBar.appendChild(chip("Críticas", counts.critico, "critico"));
  filterBar.appendChild(chip("Advertencias", counts.advertencia, "advertencia"));
  filterBar.appendChild(chip("Informativas", counts.info, "info"));
  host.appendChild(filterBar);

  const list = el("div", { class: "alert-list" });
  if (alerts.length === 0) {
    list.appendChild(emptyState("No hay alertas activas en este momento. La flota está bajo control.", "✓"));
  } else {
    alerts.forEach(a => {
      list.appendChild(el("div", { class: `alert-item alert-item--${a.nivel}` }, [
        el("span", { class: "alert-item__dot" }),
        el("div", {}, [
          el("strong", {}, `${a.tipo}${a.vehiculo ? " · " + a.vehiculo : ""}`),
          el("p", {}, a.mensaje)
        ])
      ]));
    });
  }
  host.appendChild(list);
}

function chip(label, count, tone) {
  return el("div", { class: `filter-chip filter-chip--${tone}` }, [
    el("span", { class: "filter-chip__count" }, String(count)),
    el("span", {}, label)
  ]);
}
