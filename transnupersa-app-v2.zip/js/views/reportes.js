import { el, fmtMoney } from "../utils.js";
import { sectionHeader, statCard } from "../components.js";
import { Vehiculos, Preventivo, Correctivo, Ordenes } from "../data.js";

export async function renderReportes(container) {
  container.appendChild(sectionHeader("MÓDULO · RP", "Reportes y estadísticas"));
  container.appendChild(el("p", { class: "view-intro" }, "Indicadores de fallas, costos, cumplimiento y disponibilidad de la flota."));

  const host = el("div", { class: "reportes-grid" }, el("p", { class: "loading" }, "Procesando indicadores…"));
  container.appendChild(host);

  const [vehiculos, preventivos, correctivos, ordenes] = await Promise.all([
    Vehiculos.list(), Preventivo.list(), Correctivo.list(), Ordenes.list()
  ]);
  host.innerHTML = "";

  // --- KPIs superiores ---
  const activos = vehiculos.filter(v => v.estado === "activo").length;
  const enMant = vehiculos.filter(v => v.estado === "en_mantenimiento").length;
  const fuera = vehiculos.filter(v => v.estado === "fuera_servicio").length;
  const costoTotal = ordenes.reduce((s, o) => s + (Number(o.costo) || 0), 0);
  const cumplidos = preventivos.filter(p => p.estado === "completado").length;
  const cumplimiento = preventivos.length ? Math.round((cumplidos / preventivos.length) * 100) : 0;

  const kpis = el("div", { class: "stat-row" }, [
    statCard({ value: vehiculos.length, label: "Vehículos en flota" }),
    statCard({ value: cumplimiento + "%", label: "Cumplimiento de mantenimiento", tone: "amber" }),
    statCard({ value: fmtMoney(costoTotal), label: "Costo total de mantenimiento", tone: "steel" }),
    statCard({ value: correctivos.length, label: "Fallas reportadas", tone: "danger" }),
  ]);
  host.appendChild(kpis);

  const chartsRow = el("div", { class: "charts-row" });
  host.appendChild(chartsRow);

  chartsRow.appendChild(chartPanel("Disponibilidad de la flota", "donut-disponibilidad"));
  chartsRow.appendChild(chartPanel("Fallas por tipo de avería", "bar-fallas"));

  const chartsRow2 = el("div", { class: "charts-row" });
  host.appendChild(chartsRow2);
  chartsRow2.appendChild(chartPanel("Costo de mantenimiento por vehículo", "bar-costos"));
  chartsRow2.appendChild(chartPanel("Preventivo realizado vs. programado", "donut-cumplimiento"));

  // Espera a que los canvas existan en el DOM antes de graficar
  requestAnimationFrame(() => {
    const Chart = window.Chart;
    if (!Chart) return;

    new Chart(document.getElementById("donut-disponibilidad"), {
      type: "doughnut",
      data: {
        labels: ["Activos", "En mantenimiento", "Fuera de servicio"],
        datasets: [{ data: [activos, enMant, fuera], backgroundColor: ["#3E8368", "#F2A63D", "#C1443D"], borderWidth: 0 }]
      },
      options: baseOptions(true)
    });

    const fallasPorTipo = {};
    correctivos.forEach(c => {
      const nombre = c.tipos_averia?.nombre || "Sin clasificar";
      fallasPorTipo[nombre] = (fallasPorTipo[nombre] || 0) + 1;
    });
    new Chart(document.getElementById("bar-fallas"), {
      type: "bar",
      data: {
        labels: Object.keys(fallasPorTipo).length ? Object.keys(fallasPorTipo) : ["Sin datos"],
        datasets: [{ label: "Fallas", data: Object.keys(fallasPorTipo).length ? Object.values(fallasPorTipo) : [0], backgroundColor: "#4A6B7C" }]
      },
      options: baseOptions(false)
    });

    const costoPorVehiculo = {};
    ordenes.forEach(o => {
      const cod = o.vehiculos?.codigo || "—";
      costoPorVehiculo[cod] = (costoPorVehiculo[cod] || 0) + (Number(o.costo) || 0);
    });
    new Chart(document.getElementById("bar-costos"), {
      type: "bar",
      data: {
        labels: Object.keys(costoPorVehiculo).length ? Object.keys(costoPorVehiculo) : ["Sin datos"],
        datasets: [{ label: "Costo (USD)", data: Object.keys(costoPorVehiculo).length ? Object.values(costoPorVehiculo) : [0], backgroundColor: "#F2A63D" }]
      },
      options: baseOptions(false)
    });

    new Chart(document.getElementById("donut-cumplimiento"), {
      type: "doughnut",
      data: {
        labels: ["Completado", "Pendiente / en proceso", "Cancelado"],
        datasets: [{
          data: [
            preventivos.filter(p => p.estado === "completado").length,
            preventivos.filter(p => p.estado === "pendiente" || p.estado === "en_proceso").length,
            preventivos.filter(p => p.estado === "cancelado").length,
          ],
          backgroundColor: ["#3E8368", "#F2A63D", "#8b8f94"], borderWidth: 0
        }]
      },
      options: baseOptions(true)
    });
  });
}

function chartPanel(title, canvasId) {
  return el("div", { class: "panel panel--chart" }, [
    el("h3", { class: "panel__title" }, title),
    el("div", { class: "chart-wrap" }, el("canvas", { id: canvasId }))
  ]);
}

function baseOptions(isDonut) {
  return {
    responsive: true,
    maintainAspectRatio: false,
    plugins: { legend: { position: isDonut ? "bottom" : "top", labels: { font: { family: "Inter" } } } },
    scales: isDonut ? {} : { y: { beginAtZero: true, ticks: { precision: 0 } } }
  };
}
