import { el, toast, openModal, buildForm, badge } from "../utils.js";
import { dataTable, sectionHeader, iconBtn } from "../components.js";
import { Perfiles } from "../data.js";
import { ROLES } from "../auth.js";

const ROLE_TONE = { administrador: "danger", jefe_mantenimiento: "amber", tecnico: "info", supervisor: "success" };

export async function renderUsuarios(container) {
  container.appendChild(sectionHeader("MÓDULO · US", "Usuarios y roles"));
  container.appendChild(el("p", { class: "view-intro" },
    "Los usuarios se crean por autorregistro en la pantalla de acceso; desde aquí el administrador asigna su rol y estado dentro del sistema."));

  const host = el("div", {});
  container.appendChild(host);
  await refresh();

  async function refresh() {
    host.innerHTML = "";
    host.appendChild(el("p", { class: "loading" }, "Cargando usuarios…"));
    const rows = await Perfiles.list();
    host.innerHTML = "";
    host.appendChild(dataTable({
      columns: [
        { label: "Nombre", key: "nombre" },
        { label: "Correo", key: "correo" },
        { label: "Rol", render: r => badge(ROLES[r.rol] || r.rol, ROLE_TONE[r.rol] || "neutral") },
        { label: "Estado", render: r => badge(r.estado === "activo" ? "Activo" : "Inactivo", r.estado === "activo" ? "success" : "neutral") },
      ],
      rows,
      emptyText: "No hay usuarios registrados todavía.",
      actions: (row) => [iconBtn("✎", "Editar rol / estado", () => openForm(row))]
    }));
  }

  function openForm(row) {
    const fields = [
      { name: "rol", label: "Rol", type: "select", required: true,
        options: Object.entries(ROLES).map(([value, label]) => ({ value, label })), value: row.rol },
      { name: "estado", label: "Estado", type: "select", required: true,
        options: [{ value: "activo", label: "Activo" }, { value: "inactivo", label: "Inactivo" }], value: row.estado },
    ];
    const form = buildForm(fields, "Guardar cambios", async (data) => {
      try { await Perfiles.update(row.id, data); toast("Usuario actualizado.", "success"); modal.close(); await refresh(); }
      catch (e) { toast("Error: " + e.message, "danger"); }
    });
    const modal = openModal({ title: `Editar — ${row.nombre}`, bodyNode: form });
  }
}
