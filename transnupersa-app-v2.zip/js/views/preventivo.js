import { el, fmtDate, toast, openModal, confirmDialog, buildForm, badge, ESTADO_TONE, estadoLabel } from "../utils.js";
import { dataTable, sectionHeader, iconBtn } from "../components.js";
import { Preventivo, Vehiculos, TiposMantenimiento } from "../data.js";

const ESTADOS = [
  { value: "pendiente", label: "Pendiente" },
  { value: "en_proceso", label: "En proceso" },
  { value: "completado", label: "Completado" },
  { value: "cancelado", label: "Cancelado" },
];

export async function renderPreventivo(container) {
  container.appendChild(sectionHeader("MÓDULO · MP", "Mantenimiento preventivo",
    el("button", { class: "btn btn--primary", type: "button", onclick: () => openForm() }, "+ Programar mantenimiento")
  ));
  container.appendChild(el("p", { class: "view-intro" }, "Programación por fecha o kilometraje. Al crear un registro se genera automáticamente su orden de trabajo."));

  const tableHost = el("div", {});
  container.appendChild(tableHost);
  await refresh();

  async function refresh() {
    tableHost.innerHTML = "";
    tableHost.appendChild(el("p", { class: "loading" }, "Cargando programación…"));
    const rows = await Preventivo.list();
    tableHost.innerHTML = "";
    tableHost.appendChild(dataTable({
      columns: [
        { label: "Vehículo", render: r => `<span class="mono">${r.vehiculos?.codigo || "—"}</span> ${r.vehiculos?.placa || ""}` },
        { label: "Tipo de mantenimiento", render: r => r.tipos_mantenimiento?.nombre || "—" },
        { label: "Fecha programada", render: r => fmtDate(r.fecha_programada) },
        { label: "Km programado", render: r => r.km_programado ? Number(r.km_programado).toLocaleString() + " km" : "—" },
        { label: "Estado", render: r => badge(estadoLabel(r.estado), ESTADO_TONE[r.estado]) },
      ],
      rows,
      emptyText: "No hay mantenimientos preventivos programados. Programa el primero.",
      actions: (row) => [
        iconBtn("✎", "Cambiar estado", () => openEstadoForm(row)),
        iconBtn("🗑", "Eliminar", () => onDelete(row), "danger"),
      ]
    }));
  }

  async function openForm() {
    const [vehiculos, tipos] = await Promise.all([Vehiculos.list(), TiposMantenimiento.list()]);
    if (vehiculos.length === 0) { toast("Registra al menos un vehículo primero.", "danger"); return; }
    if (tipos.length === 0) { toast("Configura al menos un tipo de mantenimiento primero.", "danger"); return; }
    const fields = [
      { name: "vehiculo_id", label: "Vehículo", type: "select", required: true,
        options: vehiculos.map(v => ({ value: v.id, label: `${v.codigo} — ${v.placa}` })) },
      { name: "tipo_mantenimiento_id", label: "Tipo de mantenimiento", type: "select", required: true,
        options: tipos.map(t => ({ value: t.id, label: `${t.codigo} — ${t.nombre}` })) },
      { name: "fecha_programada", label: "Fecha programada", type: "date" },
      { name: "km_programado", label: "Kilometraje programado", type: "number" },
      { name: "observaciones", label: "Observaciones", type: "textarea", full: true },
    ];
    const form = buildForm(fields, "Programar mantenimiento", async (data) => {
      try {
        await Preventivo.create({ ...data, estado: "pendiente" });
        toast("Mantenimiento programado. Orden de trabajo generada automáticamente.", "success");
        modal.close();
        await refresh();
      } catch (e) { toast("Error: " + e.message, "danger"); }
    });
    const modal = openModal({ title: "Programar mantenimiento preventivo", bodyNode: form, wide: true });
  }

  function openEstadoForm(row) {
    const fields = [
      { name: "estado", label: "Estado", type: "select", required: true, options: ESTADOS, value: row.estado },
    ];
    const form = buildForm(fields, "Actualizar estado", async (data) => {
      try { await Preventivo.update(row.id, data); toast("Estado actualizado.", "success"); modal.close(); await refresh(); }
      catch (e) { toast("Error: " + e.message, "danger"); }
    });
    const modal = openModal({ title: `Actualizar — ${row.vehiculos?.codigo || ""}`, bodyNode: form });
  }

  async function onDelete(row) {
    if (!(await confirmDialog("¿Eliminar esta programación de mantenimiento?"))) return;
    try { await Preventivo.remove(row.id); toast("Eliminado.", "success"); await refresh(); }
    catch (e) { toast("Error: " + e.message, "danger"); }
  }
}
