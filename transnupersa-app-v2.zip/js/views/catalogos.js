import { el, toast, openModal, confirmDialog, buildForm } from "../utils.js";
import { dataTable, sectionHeader, iconBtn } from "../components.js";
import { TiposMantenimiento, TiposAveria } from "../data.js";

export async function renderCatalogos(container) {
  container.appendChild(sectionHeader("MÓDULO · TM", "Catálogos de mantenimiento"));
  container.appendChild(el("p", { class: "view-intro" }, "Tipos de mantenimiento preventivo y tipos de avería que la empresa utiliza regularmente."));

  const tabs = el("div", { class: "tabs" });
  const tabPrev = el("button", { class: "tab tab--active", type: "button" }, "Tipos de mantenimiento preventivo");
  const tabAveria = el("button", { class: "tab", type: "button" }, "Tipos de avería");
  tabs.appendChild(tabPrev); tabs.appendChild(tabAveria);
  container.appendChild(tabs);

  const host = el("div", {});
  container.appendChild(host);

  tabPrev.addEventListener("click", () => { setActive(tabPrev); renderPreventivo(); });
  tabAveria.addEventListener("click", () => { setActive(tabAveria); renderAveria(); });
  function setActive(tab) { [tabPrev, tabAveria].forEach(t => t.classList.remove("tab--active")); tab.classList.add("tab--active"); }

  await renderPreventivo();

  async function renderPreventivo() {
    host.innerHTML = "";
    const addBtn = el("button", { class: "btn btn--primary btn--small", type: "button", onclick: () => openFormPrev() }, "+ Nuevo tipo");
    host.appendChild(el("div", { class: "toolbar" }, addBtn));
    const rows = await TiposMantenimiento.list();
    host.appendChild(dataTable({
      columns: [
        { label: "Código", render: r => `<span class="mono">${r.codigo}</span>` },
        { label: "Nombre", key: "nombre" },
        { label: "Periodicidad por km", render: r => r.periodicidad_km ? `${Number(r.periodicidad_km).toLocaleString()} km` : "—" },
        { label: "Periodicidad por días", render: r => r.periodicidad_dias ? `${r.periodicidad_dias} días` : "—" },
        { label: "Descripción", key: "descripcion" },
      ],
      rows,
      emptyText: "Aún no se ha configurado ningún tipo de mantenimiento.",
      actions: (row) => [iconBtn("🗑", "Eliminar", () => onDeletePrev(row), "danger")]
    }));
  }

  function openFormPrev() {
    const fields = [
      { name: "codigo", label: "Código", required: true, placeholder: "MT006" },
      { name: "nombre", label: "Nombre del mantenimiento", required: true, full: true },
      { name: "periodicidad_km", label: "Periodicidad por kilometraje", type: "number" },
      { name: "periodicidad_dias", label: "Periodicidad por días", type: "number" },
      { name: "descripcion", label: "Descripción", type: "textarea", full: true },
    ];
    const form = buildForm(fields, "Guardar tipo de mantenimiento", async (data) => {
      try { await TiposMantenimiento.create(data); toast("Tipo de mantenimiento creado.", "success"); modal.close(); await renderPreventivo(); }
      catch (e) { toast("Error: " + e.message, "danger"); }
    });
    const modal = openModal({ title: "Nuevo tipo de mantenimiento", bodyNode: form });
  }

  async function onDeletePrev(row) {
    if (!(await confirmDialog(`¿Eliminar el tipo de mantenimiento "${row.nombre}"?`))) return;
    try { await TiposMantenimiento.remove(row.id); toast("Eliminado.", "success"); await renderPreventivo(); }
    catch (e) { toast("Error: " + e.message, "danger"); }
  }

  async function renderAveria() {
    host.innerHTML = "";
    const addBtn = el("button", { class: "btn btn--primary btn--small", type: "button", onclick: () => openFormAveria() }, "+ Nuevo tipo de avería");
    host.appendChild(el("div", { class: "toolbar" }, addBtn));
    const rows = await TiposAveria.list();
    host.appendChild(dataTable({
      columns: [
        { label: "Nombre", key: "nombre" },
        { label: "Descripción", key: "descripcion" },
      ],
      rows,
      emptyText: "Aún no se ha configurado ningún tipo de avería.",
      actions: (row) => [iconBtn("🗑", "Eliminar", () => onDeleteAveria(row), "danger")]
    }));
  }

  function openFormAveria() {
    const fields = [
      { name: "nombre", label: "Nombre de la avería", required: true },
      { name: "descripcion", label: "Descripción", type: "textarea", full: true },
    ];
    const form = buildForm(fields, "Guardar tipo de avería", async (data) => {
      try { await TiposAveria.create(data); toast("Tipo de avería creado.", "success"); modal.close(); await renderAveria(); }
      catch (e) { toast("Error: " + e.message, "danger"); }
    });
    const modal = openModal({ title: "Nuevo tipo de avería", bodyNode: form });
  }

  async function onDeleteAveria(row) {
    if (!(await confirmDialog(`¿Eliminar el tipo de avería "${row.nombre}"?`))) return;
    try { await TiposAveria.remove(row.id); toast("Eliminado.", "success"); await renderAveria(); }
    catch (e) { toast("Error: " + e.message, "danger"); }
  }
}
