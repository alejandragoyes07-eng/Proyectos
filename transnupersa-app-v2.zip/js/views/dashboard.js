import { el, fmtMoney, fmtDateTime } from "../utils.js";
import { gauge, sectionHeader, emptyState } from "../components.js";
import { Vehiculos, Preventivo, Ordenes } from "../data.js";
import { computeAlerts } from "../alertEngine.js";
import { getPerfil } from "../auth.js";

export async function renderDashboard(container) {
  container.appendChild(sectionHeader("PANEL · 01", `Hola, ${getPerfil()?.nombre?.split(" ")[0] || ""}`));
  const sub = el("p", { class: "view-intro" }, "Estado general de la flota de TRANSNUPERSA S.A. en tiempo real.");
  container.appendChild(sub);

  const gaugeRow = el("div", { class: "gauge-row" }, el("p", { class: "loading" }, "Cargando indicadores…"));
  container.appendChild(gaugeRow);

  const grid = el("div", { class: "dash-grid" });
  container.appendChild(grid);

  const [vehiculos, preventivos, ordenes, alerts] = await Promise.all([
    Vehiculos.list(), Preventivo.list(), Ordenes.list(), computeAlerts()
  ]);

  // --- KPIs ---
  const activos = vehiculos.filter(v => v.estado === "activo").length;
  const disponibilidad = vehiculos.length ? (activos / vehiculos.length) * 100 : 0;

  const cerrados = preventivos.filter(p => p.estado === "completado" || p.estado === "cancelado");
  const cumplimiento = preventivos.length
    ? (preventivos.filter(p => p.estado === "completado").length / preventivos.length) * 100
    : 0;

  const criticas = alerts.filter(a => a.nivel === "critico").length;

  const now = new Date();
  const costoMes = ordenes
    .filter(o => {
      const d = new Date(o.created_at);
      return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
    })
    .reduce((sum, o) => sum + (Number(o.costo) || 0), 0);

  gaugeRow.innerHTML = "";
  gaugeRow.appendChild(gauge({ value: disponibilidad, label: "Disponibilidad de flota", sublabel: `${activos} de ${vehiculos.length} unidades activas`, tone: "amber" }));
  gaugeRow.appendChild(gauge({ value: cumplimiento, label: "Cumplimiento preventivo", sublabel: `${preventivos.filter(p=>p.estado==='completado').length} de ${preventivos.length} completados`, tone: "steel" }));
  gaugeRow.appendChild(gauge({ value: Math.min(100, criticas * 20), label: "Alertas críticas", sublabel: `${criticas} activa(s) ahora mismo`, tone: criticas > 0 ? "danger" : "success" }));
  gaugeRow.appendChild(el("div", { class: "gauge gauge--money" }, [
    el("div", { class: "gauge__money-value" }, fmtMoney(costoMes)),
    el("div", { class: "gauge__label" }, "Costo de mantenimiento"),
    el("div", { class: "gauge__sublabel" }, "Acumulado del mes en curso")
  ]));

  // --- Actividad reciente (bitácora) ---
  const activityCard = el("div", { class: "panel" });
  activityCard.appendChild(el("h3", { class: "panel__title" }, "Bitácora de despacho — actividad reciente"));
  const log = el("div", { class: "activity-log" });
  const recientes = ordenes.slice(0, 8);
  if (recientes.length === 0) {
    log.appendChild(emptyState("Aún no se han generado órdenes de trabajo."));
  } else {
    recientes.forEach(o => {
      log.appendChild(el("div", { class: "activity-log__row" }, [
        el("span", { class: "activity-log__time" }, fmtDateTime(o.created_at)),
        el("span", { class: "activity-log__origin" }, o.origen === "preventivo" ? "PREV" : "CORR"),
        el("span", {}, `OT · ${o.vehiculos?.codigo || "—"} (${o.vehiculos?.placa || "—"}) · estado ${(o.estado || "pendiente").replace("_"," ")}`)
      ]));
    });
  }
  activityCard.appendChild(log);

  // --- Alertas destacadas ---
  const alertCard = el("div", { class: "panel" });
  alertCard.appendChild(el("h3", { class: "panel__title" }, "Alertas prioritarias"));
  const alertList = el("div", { class: "alert-list alert-list--compact" });
  if (alerts.length === 0) {
    alertList.appendChild(emptyState("No hay alertas activas. Flota bajo control.", "✓"));
  } else {
    alerts.slice(0, 6).forEach(a => {
      alertList.appendChild(el("div", { class: `alert-item alert-item--${a.nivel}` }, [
        el("span", { class: "alert-item__dot" }),
        el("div", {}, [
          el("strong", {}, a.tipo),
          el("p", {}, a.mensaje)
        ])
      ]));
    });
  }
  alertCard.appendChild(alertList);

  grid.appendChild(activityCard);
  grid.appendChild(alertCard);
}
