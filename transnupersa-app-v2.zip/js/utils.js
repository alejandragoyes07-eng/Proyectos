// =============================================================================
// UTILIDADES COMPARTIDAS
// =============================================================================

export function fmtDate(d) {
  if (!d) return "—";
  const date = new Date(d + (typeof d === "string" && d.length === 10 ? "T00:00:00" : ""));
  if (isNaN(date)) return d;
  return date.toLocaleDateString("es-EC", { year: "numeric", month: "short", day: "2-digit" });
}

export function fmtDateTime(d) {
  if (!d) return "—";
  const date = new Date(d);
  if (isNaN(date)) return d;
  return date.toLocaleString("es-EC", { year: "numeric", month: "short", day: "2-digit", hour: "2-digit", minute: "2-digit" });
}

export function fmtMoney(n) {
  if (n === null || n === undefined || isNaN(n)) return "$0.00";
  return "$" + Number(n).toLocaleString("es-EC", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

export function fmtKm(n) {
  if (n === null || n === undefined || isNaN(n)) return "—";
  return Number(n).toLocaleString("es-EC") + " km";
}

export function daysBetween(a, b) {
  const A = new Date(a), B = new Date(b);
  return Math.round((B - A) / 86400000);
}

export function uid(prefix = "id") {
  return prefix + "_" + Math.random().toString(36).slice(2, 10);
}

export function el(tag, attrs = {}, children = []) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === "class") node.className = v;
    else if (k === "html") node.innerHTML = v;
    else if (k.startsWith("on") && typeof v === "function") node.addEventListener(k.slice(2), v);
    else node.setAttribute(k, v);
  }
  (Array.isArray(children) ? children : [children]).forEach(c => {
    if (c === null || c === undefined) return;
    node.appendChild(typeof c === "string" ? document.createTextNode(c) : c);
  });
  return node;
}

// ---------------------------------------------------------------- Toasts ---
let toastHost = null;
export function toast(message, type = "info") {
  if (!toastHost) {
    toastHost = document.createElement("div");
    toastHost.className = "toast-host";
    document.body.appendChild(toastHost);
  }
  const t = el("div", { class: `toast toast--${type}` }, message);
  toastHost.appendChild(t);
  requestAnimationFrame(() => t.classList.add("toast--show"));
  setTimeout(() => {
    t.classList.remove("toast--show");
    setTimeout(() => t.remove(), 250);
  }, 3600);
}

// ----------------------------------------------------------------- Modal ---
export function openModal({ title, bodyNode, wide = false }) {
  const overlay = el("div", { class: "modal-overlay" });
  const modal = el("div", { class: "modal" + (wide ? " modal--wide" : "") });
  const header = el("div", { class: "modal__header" }, [
    el("h3", {}, title),
    el("button", { class: "modal__close", type: "button", "aria-label": "Cerrar", onclick: () => close() }, "✕")
  ]);
  modal.appendChild(header);
  const body = el("div", { class: "modal__body" });
  body.appendChild(bodyNode);
  modal.appendChild(body);
  overlay.appendChild(modal);
  document.body.appendChild(overlay);
  document.body.classList.add("no-scroll");
  function close() {
    overlay.remove();
    document.body.classList.remove("no-scroll");
  }
  overlay.addEventListener("click", (e) => { if (e.target === overlay) close(); });
  document.addEventListener("keydown", function onEsc(e) {
    if (e.key === "Escape") { close(); document.removeEventListener("keydown", onEsc); }
  });
  return { close, modal };
}

export function confirmDialog(message) {
  return new Promise((resolve) => {
    const body = el("div", { class: "confirm" }, [
      el("p", {}, message),
      el("div", { class: "confirm__actions" }, [
        el("button", { class: "btn btn--ghost", type: "button", onclick: () => { resolve(false); m.close(); } }, "Cancelar"),
        el("button", { class: "btn btn--danger", type: "button", onclick: () => { resolve(true); m.close(); } }, "Confirmar")
      ])
    ]);
    const m = openModal({ title: "Confirmar acción", bodyNode: body });
  });
}

// ------------------------------------------------------------ Form build ---
// fields: [{ name, label, type: 'text'|'number'|'date'|'select'|'textarea', options, required, value }]
export function buildForm(fields, submitLabel, onSubmit) {
  const form = el("form", { class: "form" });
  const inputs = {};
  fields.forEach(f => {
    const wrap = el("div", { class: "form__field" + (f.full ? " form__field--full" : "") });
    wrap.appendChild(el("label", { for: f.name }, f.label + (f.required ? " *" : "")));
    let input;
    if (f.type === "select") {
      input = el("select", { id: f.name, name: f.name });
      (f.options || []).forEach(opt => {
        const o = el("option", { value: opt.value }, opt.label);
        if (String(opt.value) === String(f.value)) o.setAttribute("selected", "selected");
        input.appendChild(o);
      });
    } else if (f.type === "textarea") {
      input = el("textarea", { id: f.name, name: f.name, rows: f.rows || 3 });
      input.value = f.value || "";
    } else {
      input = el("input", { id: f.name, name: f.name, type: f.type || "text" });
      if (f.step) input.setAttribute("step", f.step);
      if (f.value !== undefined && f.value !== null) input.value = f.value;
    }
    if (f.required) input.setAttribute("required", "required");
    if (f.placeholder) input.setAttribute("placeholder", f.placeholder);
    inputs[f.name] = input;
    wrap.appendChild(input);
    form.appendChild(wrap);
  });
  const actions = el("div", { class: "form__actions" }, [
    el("button", { type: "submit", class: "btn btn--primary" }, submitLabel)
  ]);
  form.appendChild(actions);
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const data = {};
    for (const [k, node] of Object.entries(inputs)) {
      data[k] = node.type === "number" ? (node.value === "" ? null : Number(node.value)) : node.value;
    }
    const btn = form.querySelector("button[type=submit]");
    btn.disabled = true;
    btn.textContent = "Guardando…";
    try {
      await onSubmit(data);
    } finally {
      btn.disabled = false;
      btn.textContent = submitLabel;
    }
  });
  return form;
}

export function badge(text, tone = "neutral") {
  return `<span class="badge badge--${tone}">${text}</span>`;
}

export const ESTADO_TONE = {
  activo: "success", en_mantenimiento: "warning", fuera_servicio: "danger",
  pendiente: "warning", en_proceso: "info", completado: "success", cancelado: "neutral",
  finalizado: "success", reportado: "warning", diagnosticado: "info", en_reparacion: "info", solucionado: "success"
};

export function estadoLabel(estado) {
  const map = {
    activo: "Activo", en_mantenimiento: "En mantenimiento", fuera_servicio: "Fuera de servicio",
    pendiente: "Pendiente", en_proceso: "En proceso", completado: "Completado", cancelado: "Cancelado",
    finalizado: "Finalizado", reportado: "Reportado", diagnosticado: "Diagnosticado",
    en_reparacion: "En reparación", solucionado: "Solucionado"
  };
  return map[estado] || estado;
}
