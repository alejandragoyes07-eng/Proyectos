# TRANSNUPERSA S.A. — Sistema de Gestión del Mantenimiento Vehicular

Aplicación web responsive para la gestión del mantenimiento vehicular de flotas de
transporte de carga pesada. Construida en HTML/CSS/JavaScript puro (sin paso de
build), con **Supabase** como backend y lista para publicarse en **Netlify**.

Implementa todos los módulos definidos en el SRS: autenticación y usuarios,
vehículos, catálogos de mantenimiento, mantenimiento preventivo, mantenimiento
correctivo, órdenes de trabajo (generadas automáticamente), historial,
reportes/estadísticas y alertas.

---

## 1. Configura Supabase (backend)

1. Crea una cuenta y un proyecto nuevo en [supabase.com](https://supabase.com).
2. En tu proyecto, ve a **SQL Editor → New query**.
3. Abre el archivo [`supabase/schema.sql`](supabase/schema.sql) de esta carpeta,
   copia **todo** su contenido y pégalo en el editor. Presiona **Run**.
   - Esto crea todas las tablas, las reglas de seguridad (RLS), los triggers
     que generan automáticamente las órdenes de trabajo, y algunos datos de
     ejemplo (vehículos y catálogos) que puedes borrar cuando quieras.
4. Ve a **Project Settings → API** y copia dos valores:
   - **Project URL**
   - **anon public key**
5. Abre el archivo [`js/config.js`](js/config.js) de este proyecto y reemplaza:

   ```js
   export const SUPABASE_URL = "https://TU-PROYECTO.supabase.co";
   export const SUPABASE_ANON_KEY = "TU_ANON_PUBLIC_KEY";
   ```

   con tus valores reales.

6. **Importante — confirmación de correo:** por defecto Supabase exige
   confirmar el correo antes de iniciar sesión. Para el entorno de tesis/demo
   puedes desactivarlo en **Authentication → Providers → Email → "Confirm
   email"** (desactívalo), o si prefieres mantenerlo activo, cada usuario
   deberá confirmar su correo desde el enlace que Supabase envía.

---

## 2. Crea tu primer usuario (Administrador)

La primera cuenta que se registre en el sistema puede elegir su propio rol —
pensado para crear al primer **Administrador**. Todas las cuentas posteriores
entran automáticamente como **Técnico** y deben ser promovidas por un
administrador desde el módulo **Usuarios** de la aplicación.

1. Abre la aplicación (ver pasos 3 o 4 más abajo).
2. Ve a la pestaña **"Crear cuenta"**, completa tus datos y elige el rol
   **Administrador**.
3. Inicia sesión. Desde el módulo **Usuarios** podrás gestionar el rol de
   cualquier persona que se registre después.

---

## 3. Prueba local (opcional, antes de publicar)

No requiere instalar nada adicional: es HTML/CSS/JS estático. Solo necesitas
servirlo con cualquier servidor local (no puede abrirse con doble clic porque
usa módulos de JavaScript). Por ejemplo, con Python instalado:

```bash
cd transnupersa-app
python3 -m http.server 8080
```

Y abre `http://localhost:8080` en tu navegador.

---

## 4. Publica en Netlify

**Opción A — arrastrar y soltar (la más simple):**

1. Ve a [app.netlify.com](https://app.netlify.com) e inicia sesión.
2. En el panel principal, arrastra la carpeta completa `transnupersa-app`
   (con tu `js/config.js` ya editado) al área que dice
   **"Drag and drop your site output folder here"**.
3. Netlify publicará el sitio y te dará una URL pública en segundos.

**Opción B — conectando un repositorio Git:**

1. Sube esta carpeta a un repositorio de GitHub/GitLab.
2. En Netlify: **Add new site → Import an existing project**.
3. Selecciona el repositorio. Como es un sitio estático no necesitas
   configurar comando de build; deja **Build command** vacío y
   **Publish directory** en `.` (ya está definido en `netlify.toml`).
4. Despliega. Cada vez que hagas `git push`, Netlify actualizará el sitio.

---

## 5. Estructura del proyecto

```
transnupersa-app/
├── index.html                 Página única (single-page app)
├── netlify.toml                Configuración de despliegue en Netlify
├── css/styles.css              Sistema de diseño completo
├── supabase/schema.sql         Script SQL a ejecutar en Supabase
└── js/
    ├── config.js                ← EDITA ESTO con tu URL y clave de Supabase
    ├── supabaseClient.js         Inicializa el cliente de Supabase
    ├── auth.js                   Login, registro, sesión y roles
    ├── data.js                   Funciones de acceso a cada tabla
    ├── alertEngine.js             Motor de reglas de alertas (RF-41 a RF-46)
    ├── router.js                  Enrutador (navegación por módulos)
    ├── utils.js / components.js   Utilidades de interfaz reutilizables
    ├── main.js                    Punto de entrada: login y estructura general
    └── views/                     Una vista por módulo del SRS
        ├── dashboard.js
        ├── vehiculos.js
        ├── catalogos.js
        ├── preventivo.js
        ├── correctivo.js
        ├── ordenes.js
        ├── historial.js
        ├── reportes.js
        ├── alertas.js
        └── usuarios.js
```

---

## 6. Notas sobre las reglas de seguridad (RLS)

El script `schema.sql` habilita *Row Level Security* en todas las tablas: para
simplificar la entrega, cualquier usuario autenticado puede leer y escribir en
las tablas operativas (vehículos, mantenimientos, órdenes de trabajo), y sólo
puede editar su propio perfil. Esto es suficiente para el alcance de un
proyecto de tesis; si se quisiera llevar a producción real, se recomienda
restringir cada política por rol específico (por ejemplo, que sólo el
Administrador pueda eliminar vehículos).

---

## 7. Cómo mapea esta app al SRS

| Módulo del SRS | Archivo de vista |
|---|---|
| Autenticación y gestión de usuarios | `js/auth.js`, `js/views/usuarios.js` |
| Gestión de vehículos | `js/views/vehiculos.js` |
| Gestión de tipos de mantenimiento | `js/views/catalogos.js` |
| Mantenimiento preventivo | `js/views/preventivo.js` |
| Mantenimiento correctivo | `js/views/correctivo.js` |
| Órdenes de trabajo | `js/views/ordenes.js` |
| Historial de mantenimiento | `js/views/historial.js` |
| Reportes y estadísticas | `js/views/reportes.js` |
| Alertas y notificaciones | `js/views/alertas.js`, `js/alertEngine.js` |

¿Dudas o algo no funciona? Revisa primero la consola del navegador (F12): la
mayoría de los errores en esta app ocurren por no haber editado
`js/config.js` o por no haber ejecutado `supabase/schema.sql`.
