-- =========================================================================
-- TRANSNUPERSA S.A. — Sistema de Gestión del Mantenimiento Vehicular
-- Script de base de datos para Supabase (PostgreSQL)
-- =========================================================================
-- Cómo usar:
-- 1. Entra a tu proyecto en https://app.supabase.com
-- 2. Ve a "SQL Editor" -> "New query"
-- 3. Pega TODO este archivo y presiona "Run"
-- =========================================================================

create extension if not exists "uuid-ossp";

-- -------------------------------------------------------------------------
-- 1. PERFILES (extiende auth.users con nombre y rol)
-- -------------------------------------------------------------------------
create table if not exists perfiles (
  id uuid references auth.users(id) on delete cascade primary key,
  nombre text not null,
  correo text not null,
  rol text not null default 'tecnico'
       check (rol in ('administrador','jefe_mantenimiento','tecnico','supervisor')),
  estado text not null default 'activo' check (estado in ('activo','inactivo')),
  created_at timestamptz not null default now()
);

-- Crea automáticamente un perfil cuando alguien se registra en auth.users.
-- Medida de seguridad: sólo la PRIMERA cuenta que se registre en todo el
-- sistema puede autoasignarse el rol elegido en el formulario (pensado para
-- crear al primer Administrador). Cualquier registro posterior entra
-- siempre como "tecnico" y debe ser promovido por un administrador desde
-- el módulo de Usuarios.
create or replace function public.handle_new_user()
returns trigger as $$
declare
  es_primero boolean;
begin
  select count(*) = 0 into es_primero from public.perfiles;
  insert into public.perfiles (id, nombre, correo, rol)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'nombre', split_part(new.email,'@',1)),
    new.email,
    case when es_primero then coalesce(new.raw_user_meta_data->>'rol', 'administrador') else 'tecnico' end
  );
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- -------------------------------------------------------------------------
-- 2. VEHÍCULOS
-- -------------------------------------------------------------------------
create table if not exists vehiculos (
  id uuid primary key default uuid_generate_v4(),
  codigo text unique not null,
  placa text unique not null,
  marca text,
  modelo text,
  anio int,
  chasis text,
  motor text,
  tipo_vehiculo text default 'Tracto camión',
  capacidad_carga numeric,
  combustible text default 'Diésel',
  kilometraje numeric not null default 0,
  fecha_adquisicion date,
  estado text not null default 'activo'
        check (estado in ('activo','en_mantenimiento','fuera_servicio')),
  conductor_asignado text,
  observaciones text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- -------------------------------------------------------------------------
-- 3. CATÁLOGOS: tipos de mantenimiento (preventivo) y tipos de avería (correctivo)
-- -------------------------------------------------------------------------
create table if not exists tipos_mantenimiento (
  id uuid primary key default uuid_generate_v4(),
  codigo text unique not null,
  nombre text not null,
  periodicidad_km numeric,
  periodicidad_dias int,
  descripcion text,
  created_at timestamptz not null default now()
);

create table if not exists tipos_averia (
  id uuid primary key default uuid_generate_v4(),
  nombre text not null,
  descripcion text,
  created_at timestamptz not null default now()
);

-- -------------------------------------------------------------------------
-- 4. MANTENIMIENTO PREVENTIVO
-- -------------------------------------------------------------------------
create table if not exists mantenimiento_preventivo (
  id uuid primary key default uuid_generate_v4(),
  vehiculo_id uuid not null references vehiculos(id) on delete cascade,
  tipo_mantenimiento_id uuid references tipos_mantenimiento(id),
  fecha_programada date,
  km_programado numeric,
  estado text not null default 'pendiente'
        check (estado in ('pendiente','en_proceso','completado','cancelado')),
  observaciones text,
  created_by uuid references perfiles(id),
  created_at timestamptz not null default now()
);

-- -------------------------------------------------------------------------
-- 5. MANTENIMIENTO CORRECTIVO
-- -------------------------------------------------------------------------
create table if not exists mantenimiento_correctivo (
  id uuid primary key default uuid_generate_v4(),
  vehiculo_id uuid not null references vehiculos(id) on delete cascade,
  tipo_averia_id uuid references tipos_averia(id),
  fecha_reporte date not null default current_date,
  km_reporte numeric,
  diagnostico text,
  solucion text,
  estado text not null default 'reportado'
        check (estado in ('reportado','diagnosticado','en_reparacion','solucionado')),
  created_by uuid references perfiles(id),
  created_at timestamptz not null default now()
);

-- -------------------------------------------------------------------------
-- 6. ÓRDENES DE TRABAJO (generadas automáticamente desde preventivo/correctivo)
-- -------------------------------------------------------------------------
create table if not exists ordenes_trabajo (
  id uuid primary key default uuid_generate_v4(),
  origen text not null check (origen in ('preventivo','correctivo')),
  mantenimiento_preventivo_id uuid references mantenimiento_preventivo(id) on delete cascade,
  mantenimiento_correctivo_id uuid references mantenimiento_correctivo(id) on delete cascade,
  vehiculo_id uuid not null references vehiculos(id) on delete cascade,
  tecnico_id uuid references perfiles(id),
  estado text not null default 'pendiente'
        check (estado in ('pendiente','en_proceso','finalizado')),
  costo numeric default 0,
  descripcion_trabajo text,
  fecha_finalizacion date,
  created_at timestamptz not null default now()
);

-- Trigger: al insertar un mantenimiento preventivo, genera automáticamente su OT
create or replace function public.crear_ot_preventivo()
returns trigger as $$
begin
  insert into ordenes_trabajo (origen, mantenimiento_preventivo_id, vehiculo_id, estado)
  values ('preventivo', new.id, new.vehiculo_id, 'pendiente');
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists trg_crear_ot_preventivo on mantenimiento_preventivo;
create trigger trg_crear_ot_preventivo
  after insert on mantenimiento_preventivo
  for each row execute procedure public.crear_ot_preventivo();

-- Trigger: al insertar un mantenimiento correctivo, genera automáticamente su OT
create or replace function public.crear_ot_correctivo()
returns trigger as $$
begin
  insert into ordenes_trabajo (origen, mantenimiento_correctivo_id, vehiculo_id, estado)
  values ('correctivo', new.id, new.vehiculo_id, 'pendiente');
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists trg_crear_ot_correctivo on mantenimiento_correctivo;
create trigger trg_crear_ot_correctivo
  after insert on mantenimiento_correctivo
  for each row execute procedure public.crear_ot_correctivo();

-- -------------------------------------------------------------------------
-- 7. ROW LEVEL SECURITY
-- Regla general del proyecto: cualquier usuario autenticado puede leer todo
-- (paneles de consulta) y crear/actualizar registros operativos; sólo el
-- administrador gestiona usuarios/perfiles.
-- -------------------------------------------------------------------------
alter table perfiles enable row level security;
alter table vehiculos enable row level security;
alter table tipos_mantenimiento enable row level security;
alter table tipos_averia enable row level security;
alter table mantenimiento_preventivo enable row level security;
alter table mantenimiento_correctivo enable row level security;
alter table ordenes_trabajo enable row level security;

-- Perfiles: todos los autenticados pueden ver perfiles; cada quien edita el suyo;
-- el administrador puede editar cualquiera (se valida también en la app).
-- Función auxiliar: ¿el usuario que hace la petición es Administrador?
-- security definer = se evalúa sin las restricciones de RLS, evitando así
-- una referencia circular al consultar la propia tabla "perfiles".
create or replace function public.is_admin()
returns boolean
language sql
security definer
stable
as $$
  select exists (
    select 1 from public.perfiles where id = auth.uid() and rol = 'administrador'
  );
$$;

create policy "perfiles_select" on perfiles for select using (auth.role() = 'authenticated');
create policy "perfiles_update_propio" on perfiles for update using (auth.uid() = id);
-- El Administrador puede además editar el rol/estado de cualquier usuario.
create policy "perfiles_update_admin" on perfiles for update using (public.is_admin());
create policy "perfiles_insert" on perfiles for insert with check (auth.uid() = id);

-- Resto de tablas operativas: lectura y escritura para cualquier usuario autenticado.
-- (Para un entorno productivo real se recomienda refinar por rol específico.)
create policy "vehiculos_all" on vehiculos for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');
create policy "tipos_mant_all" on tipos_mantenimiento for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');
create policy "tipos_averia_all" on tipos_averia for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');
create policy "prev_all" on mantenimiento_preventivo for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');
create policy "correc_all" on mantenimiento_correctivo for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');
create policy "ot_all" on ordenes_trabajo for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

-- -------------------------------------------------------------------------
-- 8. DATOS INICIALES (catálogos + vehículos de ejemplo) — opcional, puedes borrar
-- -------------------------------------------------------------------------
insert into tipos_mantenimiento (codigo, nombre, periodicidad_km, periodicidad_dias, descripcion) values
 ('MT001','Cambio de aceite y filtro', 10000, 90, 'Cambio de aceite de motor y filtro'),
 ('MT002','Revisión de frenos', 20000, 180, 'Inspección y ajuste del sistema de frenos'),
 ('MT003','Rotación de neumáticos', 15000, 120, 'Rotación y balanceo de neumáticos'),
 ('MT004','Revisión del sistema eléctrico', null, 365, 'Revisión de batería, alternador y luces'),
 ('MT005','Cambio de filtro de aire', 25000, null, 'Sustitución del filtro de aire del motor')
on conflict (codigo) do nothing;

insert into tipos_averia (nombre, descripcion) values
 ('Falla de motor','Averías relacionadas con el motor'),
 ('Falla de frenos','Averías del sistema de frenado'),
 ('Falla eléctrica','Averías del sistema eléctrico'),
 ('Falla de transmisión','Averías de caja o transmisión'),
 ('Falla de suspensión','Averías del sistema de suspensión'),
 ('Otro','Otro tipo de avería')
on conflict do nothing;

insert into vehiculos (codigo, placa, marca, modelo, anio, tipo_vehiculo, capacidad_carga, combustible, kilometraje, fecha_adquisicion, estado, conductor_asignado) values
 ('TR-001','PBX-1234','Kenworth','T800',2019,'Tracto camión',34, 'Diésel', 128500, '2019-03-15','activo','Luis Andrade'),
 ('TR-002','PCV-5566','Volvo','FH 460',2021,'Tracto camión',32, 'Diésel', 76200, '2021-07-02','activo','María Salazar'),
 ('TR-003','PDA-7788','International','ProStar',2018,'Tracto camión',34, 'Diésel', 165300, '2018-11-20','en_mantenimiento','Jorge Peña'),
 ('TR-004','PEB-9911','Freightliner','Cascadia',2022,'Tracto camión',30, 'Diésel', 42100, '2022-05-10','activo', null)
on conflict (codigo) do nothing;

-- =========================================================================
-- FIN DEL SCRIPT
-- =========================================================================
